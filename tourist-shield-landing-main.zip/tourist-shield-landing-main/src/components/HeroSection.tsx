import { Button } from "@/components/ui/button";
import { Shield, MapPin, Phone } from "lucide-react";
import heroBackground from "@/assets/hero-background.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBackground})` }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-hero" />
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <Shield className="w-16 h-16 text-hero-primary" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-heading font-bold text-hero-primary mb-6 leading-tight">
            YOUR SAFETY IS
            <br />
            <span className="text-hero-secondary">OUR PRIORITY</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-hero-secondary mb-8 max-w-3xl mx-auto leading-relaxed">
            Travel with confidence knowing Tourist Shield provides comprehensive protection, 
            emergency assistance, and peace of mind for every adventure around the globe.
          </p>
          
          {/* <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              size="lg" 
              className="bg-hero-primary text-primary hover:bg-hero-secondary shadow-elegant text-lg px-8 py-4"
            >
              Get Protected Now
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-hero-primary text-hero-primary hover:bg-hero-primary/10 text-lg px-8 py-4"
            >
              Learn More
            </Button>
          </div> */}
          
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-hero-primary mb-2">24/7</div>
              <div className="text-hero-secondary">Emergency Support</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-hero-primary mb-2">150+</div>
              <div className="text-hero-secondary">Countries Covered</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-hero-primary mb-2">1M+</div>
              <div className="text-hero-secondary">Travelers Protected</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-hero-primary rounded-full flex justify-center">
          <div className="w-1 h-3 bg-hero-primary rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;