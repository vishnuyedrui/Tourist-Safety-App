import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { MapPin, Shield, AlertTriangle, CheckCircle } from 'lucide-react';

interface GeofenceViolation {
  type: string;
  geofence_name: string;
  risk_level: string;
  location?: { latitude: number; longitude: number };
}

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy?: number;
}

export function GeofenceAlerts() {
  const [isTracking, setIsTracking] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [violations, setViolations] = useState<GeofenceViolation[]>([]);
  const [watchId, setWatchId] = useState<number | null>(null);
  const { toast } = useToast();

  // Start location tracking
  const startTracking = () => {
    if (!navigator.geolocation) {
      toast({
        title: 'Geolocation Error',
        description: 'Your device does not support location tracking.',
        variant: 'destructive',
      });
      return;
    }

    const options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 30000, // 30 seconds
    };

    const id = navigator.geolocation.watchPosition(
      (position) => {
        const locationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        };
        
        setCurrentLocation(locationData);
        sendLocationUpdate(locationData);
      },
      (error) => {
        console.error('Location error:', error);
        toast({
          title: 'Location Error',
          description: 'Unable to get your location. Please check permissions.',
          variant: 'destructive',
        });
      },
      options
    );

    setWatchId(id);
    setIsTracking(true);
    toast({
      title: 'Tracking Started',
      description: 'Location tracking is now active.',
    });
  };

  // Stop location tracking
  const stopTracking = () => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }
    setIsTracking(false);
    toast({
      title: 'Tracking Stopped',
      description: 'Location tracking has been disabled.',
    });
  };

  // Send location update to server
  const sendLocationUpdate = async (location: LocationData) => {
    try {
      const { data, error } = await supabase.functions.invoke('location-tracking', {
        body: {
          latitude: location.latitude,
          longitude: location.longitude,
          timestamp: new Date().toISOString(),
          accuracy: location.accuracy,
        },
      });

      if (error) throw error;

      // Handle violations from response
      if (data?.violations && data.violations.length > 0) {
        setViolations(prev => [...prev, ...data.violations]);
        
        // Show alert for each violation
        data.violations.forEach((violation: GeofenceViolation) => {
          toast({
            title: 'Geofence Alert!',
            description: `You have entered a ${violation.risk_level} area: ${violation.geofence_name}`,
            variant: violation.risk_level === 'restricted' ? 'destructive' : 'default',
          });
        });
      }

    } catch (error) {
      console.error('Location update error:', error);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [watchId]);

  const getRiskBadgeVariant = (riskLevel: string) => {
    switch (riskLevel) {
      case 'safe': return 'default';
      case 'caution': return 'secondary';
      case 'restricted': return 'destructive';
      default: return 'outline';
    }
  };

  const getRiskIcon = (riskLevel: string) => {
    switch (riskLevel) {
      case 'safe': return <CheckCircle className="h-4 w-4" />;
      case 'caution': return <Shield className="h-4 w-4" />;
      case 'restricted': return <AlertTriangle className="h-4 w-4" />;
      default: return <MapPin className="h-4 w-4" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Geofence Monitoring
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Tracking Controls */}
        <div className="flex gap-2">
          {!isTracking ? (
            <Button onClick={startTracking} className="flex-1">
              <MapPin className="h-4 w-4 mr-2" />
              Start Location Tracking
            </Button>
          ) : (
            <Button onClick={stopTracking} variant="outline" className="flex-1">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Stop Tracking
            </Button>
          )}
        </div>

        {/* Current Status */}
        {isTracking && (
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Location tracking is active. 
              {currentLocation && (
                <span className="block text-xs text-muted-foreground mt-1">
                  Current: {currentLocation.latitude.toFixed(6)}, {currentLocation.longitude.toFixed(6)}
                  {currentLocation.accuracy && ` (±${Math.round(currentLocation.accuracy)}m)`}
                </span>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Recent Violations */}
        {violations.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Recent Alerts</h4>
            {violations.slice(-3).map((violation, index) => (
              <Alert key={index} variant={violation.risk_level === 'restricted' ? 'destructive' : 'default'}>
                <div className="flex items-center gap-2">
                  {getRiskIcon(violation.risk_level)}
                  <AlertDescription className="flex-1">
                    <div className="flex items-center justify-between">
                      <span>{violation.geofence_name}</span>
                      <Badge variant={getRiskBadgeVariant(violation.risk_level)}>
                        {violation.risk_level}
                      </Badge>
                    </div>
                  </AlertDescription>
                </div>
              </Alert>
            ))}
          </div>
        )}

        {/* Info */}
        <div className="text-xs text-muted-foreground">
          <p>Geofence monitoring helps track your location relative to safe and restricted areas.</p>
          <p className="mt-1">Emergency contacts will be notified if you enter restricted zones.</p>
        </div>
      </CardContent>
    </Card>
  );
}