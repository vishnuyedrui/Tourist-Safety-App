import { useState } from 'react';
import { useTouristData } from '@/hooks/useTouristData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Calendar, MapPin, Edit, Plane, Clock, DollarSign } from 'lucide-react';
import TripForm from './TripForm';
import ItineraryBuilder from './ItineraryBuilder';
import type { Trip } from '@/hooks/useTouristData';

const TripManagement = () => {
  const { trips, loading } = useTouristData();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'completed': return 'secondary';
      case 'planned': return 'outline';
      case 'cancelled': return 'destructive';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Plane className="h-4 w-4" />;
      case 'completed': return <Calendar className="h-4 w-4" />;
      case 'planned': return <Clock className="h-4 w-4" />;
      default: return <MapPin className="h-4 w-4" />;
    }
  };

  const activeTrips = trips.filter(trip => trip.status === 'active');
  const plannedTrips = trips.filter(trip => trip.status === 'planned');
  const pastTrips = trips.filter(trip => trip.status === 'completed');

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (isCreating || isEditing) {
    return (
      <TripForm
        trip={isEditing ? selectedTrip : null}
        onClose={() => {
          setIsCreating(false);
          setIsEditing(false);
          setSelectedTrip(null);
        }}
        onSuccess={(trip) => {
          setIsCreating(false);
          setIsEditing(false);
          setSelectedTrip(trip);
          setActiveTab('itinerary');
        }}
      />
    );
  }

  if (selectedTrip && activeTab === 'itinerary') {
    return (
      <ItineraryBuilder
        trip={selectedTrip}
        onBack={() => {
          setSelectedTrip(null);
          setActiveTab('overview');
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Trip Management Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Trip Management</h2>
          <p className="text-muted-foreground">Plan, manage, and track your travels</p>
        </div>
        <Button 
          onClick={() => setIsCreating(true)}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Create New Trip
        </Button>
      </div>

      {/* Trip Overview Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Trips</p>
                <p className="text-2xl font-bold">{trips.length}</p>
              </div>
              <MapPin className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-primary">{activeTrips.length}</p>
              </div>
              <Plane className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Planned</p>
                <p className="text-2xl font-bold text-blue-600">{plannedTrips.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold text-green-600">{pastTrips.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Trip Categories */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="active">Active Trips</TabsTrigger>
          <TabsTrigger value="planned">Planned Trips</TabsTrigger>
          <TabsTrigger value="past">Past Trips</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {trips.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Plane className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No Trips Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start planning your next adventure by creating your first trip.
                </p>
                <Button onClick={() => setIsCreating(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Your First Trip
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* Active Trip Highlight */}
              {activeTrips.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Current Trip</h3>
                  {activeTrips.map((trip) => (
                    <Card key={trip.id} className="border-primary/50 bg-primary/5">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="w-3 h-3 bg-primary rounded-full animate-pulse"></div>
                            <h4 className="text-xl font-semibold">{trip.destination}</h4>
                            <Badge variant="default">Active</Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedTrip(trip);
                                setActiveTab('itinerary');
                              }}
                            >
                              View Itinerary
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedTrip(trip);
                                setIsEditing(true);
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Duration</p>
                            <p className="font-medium">
                              {Math.ceil((new Date(trip.end_date).getTime() - new Date(trip.start_date).getTime()) / (1000 * 60 * 60 * 24))} days
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Dates</p>
                            <p className="font-medium">
                              {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}
                            </p>
                          </div>
                          {trip.budget && (
                            <div>
                              <p className="text-muted-foreground">Budget</p>
                              <p className="font-medium flex items-center gap-1">
                                <DollarSign className="h-3 w-3" />
                                {Number(trip.budget).toLocaleString()}
                              </p>
                            </div>
                          )}
                          {trip.accommodation && (
                            <div>
                              <p className="text-muted-foreground">Accommodation</p>
                              <p className="font-medium">{trip.accommodation}</p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Recent Trips */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Recent Trips</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trips.slice(0, 6).map((trip) => (
                    <Card key={trip.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(trip.status)}
                            <h4 className="font-semibold">{trip.destination}</h4>
                          </div>
                          <Badge variant={getStatusColor(trip.status)}>
                            {trip.status}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}
                          </div>
                          
                          {trip.budget && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <DollarSign className="h-3 w-3" />
                              Budget: ${Number(trip.budget).toLocaleString()}
                            </div>
                          )}
                        </div>
                        
                        <div className="flex gap-2 mt-4">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1"
                            onClick={() => {
                              setSelectedTrip(trip);
                              setActiveTab('itinerary');
                            }}
                          >
                            Itinerary
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedTrip(trip);
                              setIsEditing(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="active">
          <TripGrid trips={activeTrips} onEdit={(trip) => {setSelectedTrip(trip); setIsEditing(true);}} onViewItinerary={(trip) => {setSelectedTrip(trip); setActiveTab('itinerary');}} />
        </TabsContent>

        <TabsContent value="planned">
          <TripGrid trips={plannedTrips} onEdit={(trip) => {setSelectedTrip(trip); setIsEditing(true);}} onViewItinerary={(trip) => {setSelectedTrip(trip); setActiveTab('itinerary');}} />
        </TabsContent>

        <TabsContent value="past">
          <TripGrid trips={pastTrips} onEdit={(trip) => {setSelectedTrip(trip); setIsEditing(true);}} onViewItinerary={(trip) => {setSelectedTrip(trip); setActiveTab('itinerary');}} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Trip Grid Component
const TripGrid = ({ trips, onEdit, onViewItinerary }: { 
  trips: Trip[]; 
  onEdit: (trip: Trip) => void;
  onViewItinerary: (trip: Trip) => void;
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'completed': return 'secondary';
      case 'planned': return 'outline';
      case 'cancelled': return 'destructive';
      default: return 'outline';
    }
  };

  if (trips.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No trips in this category yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {trips.map((trip) => (
        <Card key={trip.id} className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-3">
              <h4 className="font-semibold text-lg">{trip.destination}</h4>
              <Badge variant={getStatusColor(trip.status)}>
                {trip.status}
              </Badge>
            </div>
            
            <div className="space-y-2 text-sm text-muted-foreground mb-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-3 w-3" />
                {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}
              </div>
              
              {trip.budget && (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-3 w-3" />
                  Budget: ${Number(trip.budget).toLocaleString()}
                </div>
              )}

              {trip.accommodation && (
                <div className="flex items-center gap-2">
                  <MapPin className="h-3 w-3" />
                  {trip.accommodation}
                </div>
              )}
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1"
                onClick={() => onViewItinerary(trip)}
              >
                Itinerary
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(trip)}
              >
                <Edit className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TripManagement;