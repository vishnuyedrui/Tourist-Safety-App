import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Upload, ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useTouristData } from '@/hooks/useTouristData';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { generateBlockchainId } from '@/lib/blockchain';

interface ProfileRegistrationProps {
  onComplete: () => void;
}

interface FormData {
  // Step 1: Personal Information
  full_name: string;
  email: string;
  phone: string;
  nationality: string;
  trip_start_date: Date | null;
  trip_end_date: Date | null;
  
  // Step 2: KYC Documents
  document_name: string;
  document_number: string;
  kyc_document: File | null;
  
  // Step 3: Emergency & Medical
  emergency_contact_name: string;
  emergency_contact_phone: string;
  emergency_contact_relationship: string;
  emergency_contact_email: string;
  medical_conditions: string;
}

const STEPS = [
  { id: 1, title: 'Personal Information', description: 'Basic details and trip dates' },
  { id: 2, title: 'Identity Document', description: 'KYC document upload' },
  { id: 3, title: 'Emergency & Medical', description: 'Emergency contacts and medical info' },
  { id: 4, title: 'Review & Submit', description: 'Confirm and complete registration' }
];

export const ProfileRegistration: React.FC<ProfileRegistrationProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { createTouristProfile, addEmergencyContact } = useTouristData();
  
  const [formData, setFormData] = useState<FormData>({
    full_name: '',
    email: '',
    phone: '',
    nationality: '',
    trip_start_date: null,
    trip_end_date: null,
    document_name: '',
    document_number: '',
    kyc_document: null,
    emergency_contact_name: '',
    emergency_contact_phone: '',
    emergency_contact_relationship: '',
    emergency_contact_email: '',
    medical_conditions: ''
  });

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(formData.full_name && formData.email && formData.phone && 
                 formData.nationality && formData.trip_start_date && formData.trip_end_date);
      case 2:
        return !!(formData.document_name && formData.document_number && formData.kyc_document);
      case 3:
        return !!(formData.emergency_contact_name && formData.emergency_contact_phone && 
                 formData.emergency_contact_relationship);
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 4));
    } else {
      toast({
        title: "Incomplete Information",
        description: "Please fill in all required fields before proceeding.",
        variant: "destructive"
      });
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const uploadDocument = async (file: File): Promise<string | null> => {
    try {
      if (!user) {
        throw new Error('User not authenticated');
      }
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('kyc-documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('kyc-documents')
        .getPublicUrl(fileName);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading document:', error);
      return null;
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // Upload KYC document
      let documentUrl = null;
      if (formData.kyc_document) {
        documentUrl = await uploadDocument(formData.kyc_document);
        if (!documentUrl) {
          throw new Error('Failed to upload document');
        }
      }

      // Generate blockchain ID
      const blockchainId = generateBlockchainId();
      const blockchainIdExpires = formData.trip_end_date;

      // Create tourist profile
      const profileData = {
        full_name: formData.full_name,
        phone: formData.phone,
        nationality: formData.nationality,
        document_name: formData.document_name,
        document_number: formData.document_number,
        kyc_document_url: documentUrl,
        medical_conditions: formData.medical_conditions,
        blockchain_id: blockchainId,
        blockchain_id_expires: blockchainIdExpires?.toISOString(),
        registration_status: 'complete',
        kyc_status: 'pending'
      };

      const profile = await createTouristProfile(profileData);
      if (!profile) throw new Error('Failed to create profile');

      // Add emergency contact
      await addEmergencyContact({
        name: formData.emergency_contact_name,
        phone: formData.emergency_contact_phone,
        relationship: formData.emergency_contact_relationship,
        email: formData.emergency_contact_email
      });

      // Send confirmation email
      await supabase.functions.invoke('send-registration-confirmation', {
        body: {
          email: formData.email,
          name: formData.full_name,
          blockchain_id: blockchainId,
          trip_dates: {
            start: formData.trip_start_date?.toISOString(),
            end: formData.trip_end_date?.toISOString()
          }
        }
      });

      toast({
        title: "Registration Complete!",
        description: "Your profile has been created and a confirmation email has been sent."
      });

      onComplete();
    } catch (error: any) {
      console.error('Registration error:', error);
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to complete registration. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="full_name">Full Name *</Label>
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={(e) => updateFormData('full_name', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateFormData('email', e.target.value)}
                  placeholder="Enter your email"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => updateFormData('phone', e.target.value)}
                  placeholder="Enter your phone number"
                />
              </div>
              <div>
                <Label htmlFor="nationality">Nationality *</Label>
                <Input
                  id="nationality"
                  value={formData.nationality}
                  onChange={(e) => updateFormData('nationality', e.target.value)}
                  placeholder="Enter your nationality"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Trip Start Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.trip_start_date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.trip_start_date ? format(formData.trip_start_date, "PPP") : <span>Pick start date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.trip_start_date || undefined}
                      onSelect={(date) => updateFormData('trip_start_date', date || null)}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <Label>Trip End Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.trip_end_date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.trip_end_date ? format(formData.trip_end_date, "PPP") : <span>Pick end date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.trip_end_date || undefined}
                      onSelect={(date) => updateFormData('trip_end_date', date || null)}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="document_name">Document Type *</Label>
              <Select value={formData.document_name} onValueChange={(value) => updateFormData('document_name', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select document type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="passport">Passport</SelectItem>
                  <SelectItem value="aadhar">Aadhar Card</SelectItem>
                  <SelectItem value="driving_license">Driving License</SelectItem>
                  <SelectItem value="national_id">National ID</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="document_number">Document Number *</Label>
              <Input
                id="document_number"
                value={formData.document_number}
                onChange={(e) => updateFormData('document_number', e.target.value)}
                placeholder="Enter document number"
              />
            </div>
            <div>
              <Label htmlFor="kyc_document">Upload Document *</Label>
              <div className="mt-2 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed border-border rounded-md">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                  <div className="flex text-sm text-muted-foreground">
                    <label
                      htmlFor="kyc_document"
                      className="relative cursor-pointer bg-background rounded-md font-medium text-primary hover:text-primary/80"
                    >
                      <span>Upload a file</span>
                      <input
                        id="kyc_document"
                        name="kyc_document"
                        type="file"
                        className="sr-only"
                        accept="image/*,.pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) updateFormData('kyc_document', file);
                        }}
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-muted-foreground">PNG, JPG, PDF up to 10MB</p>
                  {formData.kyc_document && (
                    <p className="text-sm text-primary">{formData.kyc_document.name}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Emergency Contact</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="emergency_name">Contact Name *</Label>
                <Input
                  id="emergency_name"
                  value={formData.emergency_contact_name}
                  onChange={(e) => updateFormData('emergency_contact_name', e.target.value)}
                  placeholder="Emergency contact name"
                />
              </div>
              <div>
                <Label htmlFor="emergency_phone">Contact Phone *</Label>
                <Input
                  id="emergency_phone"
                  value={formData.emergency_contact_phone}
                  onChange={(e) => updateFormData('emergency_contact_phone', e.target.value)}
                  placeholder="Emergency contact phone"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="emergency_relationship">Relationship *</Label>
                <Select value={formData.emergency_contact_relationship} onValueChange={(value) => updateFormData('emergency_contact_relationship', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="spouse">Spouse</SelectItem>
                    <SelectItem value="sibling">Sibling</SelectItem>
                    <SelectItem value="friend">Friend</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="emergency_email">Contact Email (Optional)</Label>
                <Input
                  id="emergency_email"
                  type="email"
                  value={formData.emergency_contact_email}
                  onChange={(e) => updateFormData('emergency_contact_email', e.target.value)}
                  placeholder="Emergency contact email"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="medical_conditions">Medical Conditions & Allergies (Optional)</Label>
              <Textarea
                id="medical_conditions"
                value={formData.medical_conditions}
                onChange={(e) => updateFormData('medical_conditions', e.target.value)}
                placeholder="List any medical conditions, allergies, or important medical information..."
                rows={4}
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Review Your Information</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-sm text-muted-foreground">Personal Information</h4>
                <p><strong>Name:</strong> {formData.full_name}</p>
                <p><strong>Email:</strong> {formData.email}</p>
                <p><strong>Phone:</strong> {formData.phone}</p>
                <p><strong>Nationality:</strong> {formData.nationality}</p>
                <p><strong>Trip:</strong> {formData.trip_start_date ? format(formData.trip_start_date, 'PPP') : ''} - {formData.trip_end_date ? format(formData.trip_end_date, 'PPP') : ''}</p>
              </div>
              <div>
                <h4 className="font-medium text-sm text-muted-foreground">Identity Document</h4>
                <p><strong>Type:</strong> {formData.document_name}</p>
                <p><strong>Number:</strong> {formData.document_number}</p>
                <p><strong>File:</strong> {formData.kyc_document?.name}</p>
              </div>
              <div>
                <h4 className="font-medium text-sm text-muted-foreground">Emergency Contact</h4>
                <p><strong>Name:</strong> {formData.emergency_contact_name}</p>
                <p><strong>Phone:</strong> {formData.emergency_contact_phone}</p>
                <p><strong>Relationship:</strong> {formData.emergency_contact_relationship}</p>
                {formData.emergency_contact_email && <p><strong>Email:</strong> {formData.emergency_contact_email}</p>}
              </div>
              {formData.medical_conditions && (
                <div>
                  <h4 className="font-medium text-sm text-muted-foreground">Medical Information</h4>
                  <p>{formData.medical_conditions}</p>
                </div>
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Profile Registration</CardTitle>
        <CardDescription>Complete your profile registration to access all features</CardDescription>
        
        {/* Progress Steps */}
        <div className="flex items-center justify-between mt-6">
          {STEPS.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium border-2",
                currentStep >= step.id
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-muted-foreground border-border"
              )}>
                {currentStep > step.id ? <Check className="w-4 h-4" /> : step.id}
              </div>
              {index < STEPS.length - 1 && (
                <div className={cn(
                  "w-16 h-0.5 mx-2",
                  currentStep > step.id ? "bg-primary" : "bg-border"
                )} />
              )}
            </div>
          ))}
        </div>
        
        <div className="text-center mt-4">
          <h3 className="font-semibold">{STEPS[currentStep - 1].title}</h3>
          <p className="text-sm text-muted-foreground">{STEPS[currentStep - 1].description}</p>
        </div>
      </CardHeader>
      
      <CardContent>
        {renderStep()}
        
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 1}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          {currentStep < 4 ? (
            <Button onClick={handleNext}>
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={loading}>
              {loading ? "Completing..." : "Complete Registration"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};