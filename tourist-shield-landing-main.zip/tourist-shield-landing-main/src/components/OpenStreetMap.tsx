import React, { useEffect, useRef, useState, useCallback } from 'react';
import L from 'leaflet';
import { useLocationContext } from '@/contexts/LocationContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Shield, AlertTriangle, Crosshair, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLiveIncidents } from '@/hooks/useLiveIncidents';
import { useDangerousZones, GeofenceAlert } from '@/hooks/useDangerousZones';
import { useThrottle, useDebounce } from '@/hooks/usePerformanceOptimization';
import { OptimizedMapRenderer } from './OptimizedMapRenderer';

// Fix default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJDOC4xMyAyIDUgNS4xMyA1IDlDNSAxNC4yNSAxMiAyMiAxMiAyMkMxMiAyMiAxOSAxNC4yNSAxOSA5QzE5IDUuMTMgMTUuODcgMiAxMiAyWk0xMiAxMS41QzEwLjYyIDExLjUgOS41IDEwLjM4IDkuNSA5QzkuNSA3LjYyIDEwLjYyIDYuNSAxMiA2LjVDMTMuMzggNi41IDE0LjUgNy42MiAxNC41IDlDMTQuNSAxMC4zOCAxMy4zOCAxMS41IDEyIDExLjVaIiBmaWxsPSIjRkZENzAwIi8+Cjwvc3ZnPgo=',
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJDOC4xMyAyIDUgNS4xMyA1IDlDNSAxNC4yNSAxMiAyMiAxMiAyMkMxMiAyMiAxOSAxNC4yNSAxOSA5QzE5IDUuMTMgMTUuODcgMiAxMiAyWk0xMiAxMS41QzEwLjYyIDExLjUgOS41IDEwLjM4IDkuNSA5QzkuNSA3LjYyIDEwLjYyIDYuNSAxMiA2LjVDMTMuMzggNi41IDE0LjUgNy42MiAxNC41IDlDMTQuNSAxMC4zOCAxMy4zOCAxMS41IDEyIDExLjVaIiBmaWxsPSIjRkZENzAwIi8+Cjwvc3ZnPgo=',
  shadowUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDEiIGhlaWdodD0iNDEiIHZpZXdCb3g9IjAgMCA0MSA0MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGVsbGlwc2UgY3g9IjIwLjUiIGN5PSIzNy41IiByeD0iMTIuNSIgcnk9IjMuNSIgZmlsbD0iIzAwMDAwMCIgZmlsbC1vcGFjaXR5PSIwLjMiLz4KPC9zdmc+Cg==',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface DangerousZone {
  id: string;
  name: string;
  zone_type: string;
  risk_level: 'critical' | 'high' | 'medium' | 'low';
  geometry: {
    type: 'Polygon';
    coordinates: number[][][];
  };
  alert_message?: string;
  description?: string;
}

interface SafetyZone {
  id: string;
  latitude: number;
  longitude: number;
  title: string;
  type: 'police' | 'hospital' | 'shelter' | 'embassy';
  description: string;
}

interface OpenStreetMapProps {
  dangerousZones?: DangerousZone[];
  safetyZones?: SafetyZone[];
  onZoneEnter?: (zone: DangerousZone) => void;
}

const OpenStreetMap: React.FC<OpenStreetMapProps> = ({ 
  dangerousZones = [], 
  safetyZones = [], 
  onZoneEnter 
}) => {
  const { location, loading, error, getCurrentPosition, startTracking, stopTracking, isTracking } = useLocationContext();
  const { toast } = useToast();
  const [mapCenter, setMapCenter] = useState<[number, number]>([12.9716, 77.5946]); // Default to Bangalore
  const [isClient, setIsClient] = useState(false);
  useEffect(() => setIsClient(true), []);
  
  // Leaflet map refs
  const mapDivRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const accuracyCircleRef = useRef<L.Circle | null>(null);
  const shouldZoomToUserRef = useRef<boolean>(false);
  const userHasCenteredRef = useRef<boolean>(false);

  // Initialize map once on client
  useEffect(() => {
    if (!isClient || !mapDivRef.current || mapRef.current) return;

    const map = L.map(mapDivRef.current).setView(mapCenter, 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    mapRef.current = map;

    const onClick = (e: L.LeafletMouseEvent) => {
      checkGeofence(e.latlng.lat, e.latlng.lng);
    };
    map.on('click', onClick);

    return () => {
      map.off('click', onClick);
      map.remove();
      mapRef.current = null;
    };
  }, [isClient]);

  // Live incidents and dangerous zones
  const { incidents, fetchIncidents } = useLiveIncidents(false);
  const { zones: dbDangerousZones, checkGeofence } = useDangerousZones(
    location?.latitude, 
    location?.longitude, 
    (alert: GeofenceAlert) => {
    toast({
      title: "⚠ Caution: Dangerous Zone",
      description: alert.distance === 0 
        ? `You are inside ${alert.zone.name}. ${alert.zone.alert_message}`
        : `You are ${alert.distance}m from ${alert.zone.name}. ${alert.zone.alert_message}`,
      variant: "destructive",
      duration: 8000,
    });
  });

  // Combine dangerous zones from props and database
  const allDangerousZones = [...dangerousZones, ...dbDangerousZones];

  // Default safety zones (mock data)
  const defaultSafetyZones: SafetyZone[] = [
    {
      id: '1',
      latitude: 12.9716,
      longitude: 77.5946,
      title: 'Tourist Police Station',
      type: 'police',
      description: 'Specialized tourist assistance and safety services'
    },
    {
      id: '2', 
      latitude: 12.9722,
      longitude: 77.5951,
      title: 'Government Hospital',
      type: 'hospital',
      description: '24/7 emergency medical services'
    },
    {
      id: '3',
      latitude: 12.9710,
      longitude: 77.5940,
      title: 'Tourist Information Center',
      type: 'shelter',
      description: 'Safe zone with tourist assistance'
    },
    {
      id: '4',
      latitude: 12.9730,
      longitude: 77.5960,
      title: 'US Consulate',
      type: 'embassy',
      description: 'Embassy services and assistance'
    }
  ];

  const allSafetyZones = [...safetyZones, ...defaultSafetyZones];

  // Keep map centered with state updates
  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.setView(mapCenter);
    }
  }, [mapCenter]);

  // Create user location icon
  const createUserIcon = (): L.DivIcon => {
    return L.divIcon({
      className: 'custom-user-icon',
      html: `
        <div style="
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: linear-gradient(135deg, #FFD700, #FFA500);
          border: 4px solid white;
          box-shadow: 0 4px 12px rgba(255, 215, 0, 0.4), 0 0 0 8px rgba(255, 215, 0, 0.1);
          animation: pulse 2s infinite;
        "></div>
        <style>
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
          }
        </style>
      `,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
      popupAnchor: [0, -15]
    });
  };

  // Update or create user marker on location changes
  useEffect(() => {
    if (!mapRef.current || !location) return;

    const { latitude, longitude, accuracy } = location;

    if (!userMarkerRef.current) {
      userMarkerRef.current = L.marker([latitude, longitude], {
        icon: createUserIcon(),
      }).addTo(mapRef.current);

      userMarkerRef.current.bindPopup(
        `<div><strong>Your Location</strong><br/>
          <small>
            Lat: ${latitude.toFixed(6)}<br/>
            Lng: ${longitude.toFixed(6)}<br/>
            Accuracy: ±${accuracy?.toFixed(0) || 'unknown'}m
          </small>
        </div>`
      );
    } else {
      userMarkerRef.current.setLatLng([latitude, longitude]);
      userMarkerRef.current.setPopupContent(
        `<div><strong>Your Location</strong><br/>
          <small>
            Lat: ${latitude.toFixed(6)}<br/>
            Lng: ${longitude.toFixed(6)}<br/>
            Accuracy: ±${accuracy?.toFixed(0) || 'unknown'}m
          </small>
        </div>`
      );
    }

    // Update or create accuracy circle
    if (accuracyCircleRef.current) {
      accuracyCircleRef.current.setLatLng([latitude, longitude]);
      accuracyCircleRef.current.setRadius(Math.max(accuracy || 25, 10));
    } else {
      accuracyCircleRef.current = L.circle([latitude, longitude], {
        radius: Math.max(accuracy || 25, 10),
        color: '#2563eb',
        weight: 1,
        fillColor: '#3b82f6',
        fillOpacity: 0.15,
      }).addTo(mapRef.current);
    }
  }, [location]);

  const handleGetLocation = async () => {
    try {
      shouldZoomToUserRef.current = true;
      await getCurrentPosition();
      toast({
        title: "Location updated",
        description: "Map centered on your current location",
      });
    } catch (err) {
      toast({
        title: "Location error",
        description: "Failed to get your location",
        variant: "destructive",
      });
    }
  };

  const handleToggleTracking = () => {
    if (isTracking) {
      stopTracking();
      toast({
        title: "Tracking stopped",
        description: "Location tracking has been disabled",
      });
    } else {
      startTracking();
      toast({
        title: "Tracking started", 
        description: "Your location is now being tracked",
      });
    }
  };

  useEffect(() => {
    if (location && mapRef.current) {
      const { latitude, longitude } = location;
      const map = mapRef.current;

      const shouldCenter = shouldZoomToUserRef.current || !userHasCenteredRef.current;
      if (shouldCenter) {
        const targetZoom = Math.max(map.getZoom() || 13, 17);
        map.flyTo([latitude, longitude], targetZoom, { duration: 1.2 });
        userHasCenteredRef.current = true;
        shouldZoomToUserRef.current = false;
      }

      checkGeofence(latitude, longitude);
      fetchIncidents(latitude, longitude);
    }
  }, [location, checkGeofence, fetchIncidents]);

  return (
    <div className="space-y-4">
      {/* Location Controls */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Live Safety Map</h2>
          <Badge variant={isTracking ? "default" : "secondary"} className="flex items-center">
            <Navigation className="w-3 h-3 mr-1" />
            {isTracking ? 'Tracking' : 'Idle'}
          </Badge>
        </div>
        
        <div className="flex space-x-2">
          <Button
            onClick={handleGetLocation}
            disabled={loading}
            variant="outline"
            className="flex-1"
          >
            <Crosshair className="w-4 h-4 mr-2" />
            {loading ? 'Getting...' : 'Get Location'}
          </Button>
          
          <Button
            onClick={handleToggleTracking}
            variant={isTracking ? "destructive" : "default"}
            className="flex-1"
          >
            <Navigation className="w-4 h-4 mr-2" />
            {isTracking ? 'Stop Tracking' : 'Start Tracking'}
          </Button>
        </div>

        {location && (
          <div className="mt-3 p-2 bg-accent/50 rounded-lg">
            <p className="text-xs text-muted-foreground">Current Location:</p>
            <p className="text-sm font-mono">
              {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}
            </p>
            <p className="text-xs text-muted-foreground">
              Accuracy: ±{location.accuracy?.toFixed(0) || 'unknown'}m
            </p>
          </div>
        )}

        {error && (
          <p className="text-sm text-destructive mt-2">{error}</p>
        )}
      </Card>

      {/* OpenStreetMap */}
      <Card className="overflow-hidden">
        <div className="h-64 w-full relative">
          {isClient ? (
            <>
              <div
                ref={mapDivRef}
                style={{ height: '100%', width: '100%', minHeight: '256px' }}
                className="rounded-lg z-0"
              />
              <OptimizedMapRenderer
                map={mapRef.current}
                dangerousZones={allDangerousZones}
                safetyZones={allSafetyZones}
                incidents={incidents}
                userLocation={location}
                viewport={mapRef.current?.getBounds()}
              />
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
              Loading map...
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default OpenStreetMap;
