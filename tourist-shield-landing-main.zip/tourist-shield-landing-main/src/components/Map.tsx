// import { useEffect, useRef, useState } from 'react';
// import L, { Map as LeafletMap, Marker as LeafletMarker, LayerGroup } from 'leaflet';
// import 'leaflet/dist/leaflet.css';
// import { useTouristData } from '@/hooks/useTouristData';
// import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// import { Button } from '@/components/ui/button';
// import { MapPin, Navigation, Loader2, User, Plane } from 'lucide-react';
// import { useToast } from '@/hooks/use-toast';
// import { GeofenceAlerts } from './GeofenceAlerts';

// // Fix default marker icons for Leaflet
// // (Required when importing Leaflet via bundlers)
// const DefaultIcon = L.Icon.Default as any;
// delete DefaultIcon.prototype._getIconUrl;
// DefaultIcon.mergeOptions({
//   iconRetinaUrl:
//     'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
//   iconUrl:
//     'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
//   shadowUrl:
//     'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
// });

// const Map = () => {
//   const { trips, loading } = useTouristData();
//   const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
//   const [locationLoading, setLocationLoading] = useState(false);
//   const { toast } = useToast();

//   // Leaflet map refs
//   const mapRef = useRef<LeafletMap | null>(null);
//   const mapElRef = useRef<HTMLDivElement | null>(null);
//   const userMarkerRef = useRef<LeafletMarker | null>(null);
//   const tripsLayerRef = useRef<LayerGroup | null>(null);

//   // Initialize Leaflet map once
//   useEffect(() => {
//     if (mapRef.current || !mapElRef.current) return;

//     // Delay map initialization to ensure DOM is ready
//     const initializeMap = () => {
//       try {
//         const map = L.map(mapElRef.current!, {
//           center: [20, 0], // world view default
//           zoom: 2,
//           zoomControl: true,
//           attributionControl: true,
//         });

//         L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//           attribution:
//             '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
//           maxZoom: 19,
//           minZoom: 1,
//         }).addTo(map);

//         tripsLayerRef.current = L.layerGroup().addTo(map);
//         mapRef.current = map;

//         // Force map to resize after initialization
//         setTimeout(() => {
//           map.invalidateSize();
//         }, 500);

//         // Set up resize observer to handle container size changes
//         const resizeObserver = new ResizeObserver(() => {
//           if (mapRef.current) {
//             mapRef.current.invalidateSize();
//           }
//         });

//         if (mapElRef.current) {
//           resizeObserver.observe(mapElRef.current);
//         }

//         // Set up intersection observer to handle visibility changes
//         const intersectionObserver = new IntersectionObserver((entries) => {
//           entries.forEach((entry) => {
//             if (entry.isIntersecting && mapRef.current) {
//               setTimeout(() => {
//                 mapRef.current?.invalidateSize();
//               }, 10);
//             }
//           });
//         });

//         if (mapElRef.current) {
//           intersectionObserver.observe(mapElRef.current);
//         }

//         // Handle window resize
//         const handleResize = () => {
//           if (mapRef.current) {
//             mapRef.current.invalidateSize();
//           }
//         };

//         window.addEventListener('resize', handleResize);

//         // Store observers for cleanup
//         (map as any)._resizeObserver = resizeObserver;
//         (map as any)._intersectionObserver = intersectionObserver;
//         (map as any)._resizeHandler = handleResize;

//       } catch (err) {
//         console.error('Failed to initialize map:', err);
//         toast({
//           title: 'Map Error',
//           description: 'Unable to load map. Please check your connection and refresh.',
//           variant: 'destructive',
//         });
//       }
//     };

//     // Use requestAnimationFrame to ensure DOM is painted
//     requestAnimationFrame(() => {
//       setTimeout(initializeMap, 50);
//     });

//     // Cleanup function to properly dispose of map and observers
//     return () => {
//       if (mapRef.current) {
//         const map = mapRef.current;
        
//         // Clean up observers
//         if ((map as any)._resizeObserver) {
//           (map as any)._resizeObserver.disconnect();
//         }
//         if ((map as any)._intersectionObserver) {
//           (map as any)._intersectionObserver.disconnect();
//         }
//         if ((map as any)._resizeHandler) {
//           window.removeEventListener('resize', (map as any)._resizeHandler);
//         }

//         // Clean up markers
//         if (userMarkerRef.current) {
//           userMarkerRef.current.remove();
//           userMarkerRef.current = null;
//         }
//         if (tripsLayerRef.current) {
//           tripsLayerRef.current.clearLayers();
//           tripsLayerRef.current = null;
//         }

//         // Remove and nullify map
//         map.remove();
//         mapRef.current = null;
//       }
//     };
//   }, []);

//   // Update user marker when location changes
//   useEffect(() => {
//     const map = mapRef.current;
//     if (!map) return;

//     if (currentLocation) {
//       const { lat, lng } = currentLocation;
//       const position: [number, number] = [lat, lng];

//       // Create or move the user marker
//       if (!userMarkerRef.current) {
//         userMarkerRef.current = L.marker(position, {
//           icon: new L.Icon({
//             iconUrl:
//               'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
//             shadowUrl:
//               'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
//             iconSize: [25, 41],
//             iconAnchor: [12, 41],
//             popupAnchor: [1, -34],
//             shadowSize: [41, 41],
//           }),
//         })
//           .addTo(map)
//           .bindPopup(
//             `<div style="text-align:center">
//               <strong>Your Current Location</strong><br/>
//               <small>${lat.toFixed(6)}, ${lng.toFixed(6)}</small>
//             </div>`
//           );
//       } else {
//         userMarkerRef.current.setLatLng(position);
//       }

//       map.setView(position, Math.max(map.getZoom(), 13));
//     }
//   }, [currentLocation]);

//   // Update trip markers whenever trips change
//   useEffect(() => {
//     const map = mapRef.current;
//     const layer = tripsLayerRef.current;
//     if (!map || !layer) return;

//     layer.clearLayers();

//     if (!trips || trips.length === 0) return;

//     const bounds: L.LatLngBoundsExpression[] = [];

//     trips.forEach((trip) => {
//       if (!trip.current_location_lat || !trip.current_location_lng) return;
//       const lat = Number(trip.current_location_lat);
//       const lng = Number(trip.current_location_lng);
//       if (isNaN(lat) || isNaN(lng)) return;
//       const pos: [number, number] = [lat, lng];

//       const marker = L.marker(pos, {
//         icon: new L.Icon({
//           iconUrl:
//             'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
//           shadowUrl:
//             'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
//           iconSize: [25, 41],
//           iconAnchor: [12, 41],
//           popupAnchor: [1, -34],
//           shadowSize: [41, 41],
//         }),
//       }).bindPopup(
//         `<div style="text-align:center; min-width:200px">
//             <strong>${trip.destination}</strong><br/>
//             <span style="display:inline-block;margin-top:4px;padding:2px 6px;border-radius:9999px;font-size:12px;background:rgba(16,185,129,0.12);color:#065f46;">
//               ${trip.status}
//             </span><br/>
//             <small style="color:var(--muted-foreground)">${trip.start_date} - ${trip.end_date}</small>
//             ${trip.accommodation ? `<br/><small style="color:var(--muted-foreground)">📍 ${trip.accommodation}</small>` : ''}
//         </div>`
//       );

//       marker.addTo(layer);
//       bounds.push(pos);
//     });

//     // Fit map to show all trip markers if no currentLocation
//     if (bounds.length && !currentLocation) {
//       const latLngBounds = L.latLngBounds(bounds as any);
//       map.fitBounds(latLngBounds.pad(0.2));
//     }
//   }, [trips]);

//   const getCurrentLocation = () => {
//     setLocationLoading(true);
    
//     if (!navigator.geolocation) {
//       toast({
//         title: 'Geolocation not supported',
//         description: "Your browser doesn't support geolocation.",
//         variant: 'destructive',
//       });
//       setLocationLoading(false);
//       return;
//     }

//     navigator.geolocation.getCurrentPosition(
//       (position) => {
//         const newLocation = {
//           lat: position.coords.latitude,
//           lng: position.coords.longitude,
//         };
//         setCurrentLocation(newLocation);
//         setLocationLoading(false);
//         toast({
//           title: 'Location updated',
//           description: `Accuracy: ${position.coords.accuracy ? Math.round(position.coords.accuracy) + 'm' : 'Unknown'}`,
//         });
//       },
//       (error) => {
//         console.error('Error getting location:', error);
//         let errorMessage = 'Unable to get your current location.';
//         switch (error.code) {
//           case error.PERMISSION_DENIED:
//             errorMessage = 'Location access denied. Please enable location permissions.';
//             break;
//           case error.POSITION_UNAVAILABLE:
//             errorMessage = 'Location information unavailable.';
//             break;
//           case error.TIMEOUT:
//             errorMessage = 'Location request timed out.';
//             break;
//         }
//         toast({
//           title: 'Location error',
//           description: errorMessage,
//           variant: 'destructive',
//         });
//         setLocationLoading(false);
//       },
//       { enableHighAccuracy: true, timeout: 15000, maximumAge: 300000 }
//     );
//   };

//   useEffect(() => {
//     // Try to get user location on mount
//     getCurrentLocation();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center h-96">
//         <Loader2 className="h-8 w-8 animate-spin text-primary" />
//         <span className="ml-2 text-muted-foreground">Loading map...</span>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-4">
//       {/* Map Controls */}
//       <Card>
//         <CardHeader>
//           <CardTitle className="flex items-center gap-2">
//             <MapPin className="h-5 w-5" />
//             Interactive Map
//           </CardTitle>
//         </CardHeader>
//         <CardContent>
//           <div className="flex flex-wrap gap-2">
//             <Button onClick={getCurrentLocation} disabled={locationLoading} variant="outline" size="sm">
//               {locationLoading ? (
//                 <Loader2 className="h-4 w-4 animate-spin mr-2" />
//               ) : (
//                 <Navigation className="h-4 w-4 mr-2" />
//               )}
//               {locationLoading ? 'Finding Location...' : 'Get Current Location'}
//             </Button>

//             {currentLocation && (
//               <div className="text-sm text-muted-foreground flex items-center gap-1">
//                 <MapPin className="h-3 w-3" />
//                 Current: {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
//               </div>
//             )}
//           </div>
//         </CardContent>
//       </Card>

//       {/* Leaflet Map */}
//       <Card>
//         <CardContent className="p-0">
//            <div 
//             ref={mapElRef} 
//             className="w-full rounded-lg overflow-hidden bg-muted/20"
//             style={{ 
//               height: '400px',
//               width: '100%',
//               position: 'relative',
//               minHeight: '400px'
//            }}
//           />
//         </CardContent>
//       </Card>

//       {/* Geofence Monitoring */}
//       <GeofenceAlerts />

//       {/* Trip Summary */}
//       {trips && trips.length > 0 && (
//         <Card>
//           <CardHeader>
//             <CardTitle>Trip Locations</CardTitle>
//           </CardHeader>
//           <CardContent>
//             <div className="space-y-2">
//               {trips.map((trip) => (
//                 <div key={trip.id} className="flex items-center justify-between p-4 bg-muted rounded-lg border">
//                   <div className="flex items-center gap-3">
//                     <MapPin className="h-4 w-4 text-primary" />
//                     <div>
//                       <span className="font-medium">{trip.destination}</span>
//                       <span
//                         className={`ml-2 px-2 py-1 text-xs rounded-full ${
//                           trip.status === 'active'
//                             ? 'bg-primary/10 text-primary'
//                             : trip.status === 'completed'
//                             ? 'bg-green-500/10 text-green-600'
//                             : 'bg-muted-foreground/10 text-muted-foreground'
//                         }`}
//                       >
//                         {trip.status}
//                       </span>
//                       {trip.current_location_lat && trip.current_location_lng && (
//                         <div className="text-xs text-muted-foreground mt-1">
//                           Last known: {Number(trip.current_location_lat).toFixed(4)},
//                           {Number(trip.current_location_lng).toFixed(4)}
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                   <div className="text-sm text-muted-foreground text-right">
//                     <div>
//                       {trip.start_date} - {trip.end_date}
//                     </div>
//                     {trip.accommodation && <div className="text-xs">{trip.accommodation}</div>}
//                   </div>
//                 </div>
//               ))}

//               {trips.filter((trip) => !trip.current_location_lat || !trip.current_location_lng).length > 0 && (
//                 <div className="text-sm text-muted-foreground mt-4 p-3 bg-muted/50 rounded-lg">
//                   💡 Tip: Some trips don't have location data yet. Add coordinates to see them on the map!
//                 </div>
//               )}
//             </div>
//           </CardContent>
//         </Card>
//       )}

//       {(!trips || trips.length === 0) && (
//         <Card>
//           <CardContent className="text-center py-8">
//             <MapPin className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
//             <h3 className="text-lg font-semibold mb-2">No Trips Yet</h3>
//             <p className="text-muted-foreground">Create your first trip to see it displayed on the interactive map!</p>
//           </CardContent>
//         </Card>
//       )}
//     </div>
//   );
// };

// export default Map;



import { useEffect, useRef, useState } from 'react';
import L, { Map as LeafletMap, Marker as LeafletMarker, LayerGroup } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useTouristData } from '@/hooks/useTouristData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { GeofenceAlerts } from './GeofenceAlerts';

// Fix default Leaflet marker icons
const DefaultIcon = L.Icon.Default as any;
delete DefaultIcon.prototype._getIconUrl;
DefaultIcon.mergeOptions({
  iconRetinaUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const Map = () => {
  const { trips, loading } = useTouristData();
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const { toast } = useToast();

  const mapRef = useRef<LeafletMap | null>(null);
  const mapElRef = useRef<HTMLDivElement | null>(null);
  const userMarkerRef = useRef<LeafletMarker | null>(null);
  const tripsLayerRef = useRef<LayerGroup | null>(null);

  // Initialize Leaflet map
  useEffect(() => {
    if (mapRef.current || !mapElRef.current) return;

    try {
      const map = L.map(mapElRef.current, {
        center: [20, 0],
        zoom: 2,
        zoomControl: true,
        attributionControl: true,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
        minZoom: 1,
      }).addTo(map);

      tripsLayerRef.current = L.layerGroup().addTo(map);
      mapRef.current = map;

      map.invalidateSize();

      // Handle window resize
      const handleResize = () => map.invalidateSize();
      window.addEventListener('resize', handleResize);

      return () => {
        if (userMarkerRef.current) {
          userMarkerRef.current.remove();
        }
        if (tripsLayerRef.current) {
          tripsLayerRef.current.clearLayers();
        }
        map.remove();
        window.removeEventListener('resize', handleResize);
      };
    } catch (err) {
      console.error('Failed to initialize map:', err);
      toast({
        title: 'Map Error',
        description: 'Unable to load map. Please check your connection and refresh.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  // Update user marker
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !currentLocation) return;

    const { lat, lng } = currentLocation;
    const position: [number, number] = [lat, lng];

    if (!userMarkerRef.current) {
      userMarkerRef.current = L.marker(position, {
        icon: new L.Icon({
          iconUrl:
            'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
          shadowUrl:
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
          iconSize: [25, 41],
          iconAnchor: [12, 41],
          popupAnchor: [1, -34],
          shadowSize: [41, 41],
        }),
      })
        .addTo(map)
        .bindPopup(
          `<div style="text-align:center">
            <strong>Your Current Location</strong><br/>
            <small>${lat.toFixed(6)}, ${lng.toFixed(6)}</small>
          </div>`
        );
    } else {
      userMarkerRef.current.setLatLng(position);
    }

    map.setView(position, Math.max(map.getZoom(), 13));
  }, [currentLocation]);

  // Update trip markers
  useEffect(() => {
    const map = mapRef.current;
    const layer = tripsLayerRef.current;
    if (!map || !layer || !trips) return;

    layer.clearLayers();
    const bounds: L.LatLngExpression[] = [];

    trips.forEach((trip) => {
      if (!trip.current_location_lat || !trip.current_location_lng) return;
      const lat = Number(trip.current_location_lat);
      const lng = Number(trip.current_location_lng);
      if (isNaN(lat) || isNaN(lng)) return;

      const marker = L.marker([lat, lng], {
        icon: new L.Icon({
          iconUrl:
            'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
          shadowUrl:
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
          iconSize: [25, 41],
          iconAnchor: [12, 41],
          popupAnchor: [1, -34],
          shadowSize: [41, 41],
        }),
      }).bindPopup(
        `<div style="text-align:center; min-width:200px">
            <strong>${trip.destination}</strong><br/>
            <span style="display:inline-block;margin-top:4px;padding:2px 6px;border-radius:9999px;font-size:12px;background:rgba(16,185,129,0.12);color:#065f46;">
              ${trip.status}
            </span><br/>
            <small style="color:var(--muted-foreground)">${trip.start_date} - ${trip.end_date}</small>
            ${trip.accommodation ? `<br/><small style="color:var(--muted-foreground)">📍 ${trip.accommodation}</small>` : ''}
        </div>`
      );

      marker.addTo(layer);
      bounds.push([lat, lng]);
    });

    if (bounds.length && !currentLocation) {
      map.fitBounds(L.latLngBounds(bounds).pad(0.2));
    }
  }, [trips, currentLocation]);

  // Get current location
  const getCurrentLocation = () => {
    setLocationLoading(true);

    if (!navigator.geolocation) {
      toast({
        title: 'Geolocation not supported',
        description: "Your browser doesn't support geolocation.",
        variant: 'destructive',
      });
      setLocationLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCurrentLocation({ lat: position.coords.latitude, lng: position.coords.longitude });
        toast({
          title: 'Location updated',
          description: `Accuracy: ${position.coords.accuracy ? Math.round(position.coords.accuracy) + 'm' : 'Unknown'}`,
        });
        setLocationLoading(false);
      },
      (error) => {
        console.error('Error getting location:', error);
        let errorMessage = 'Unable to get your current location.';
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Location access denied. Please enable location permissions.';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information unavailable.';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location request timed out.';
            break;
        }
        toast({ title: 'Location error', description: errorMessage, variant: 'destructive' });
        setLocationLoading(false);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 300000 }
    );
  };

  useEffect(() => {
    getCurrentLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-muted-foreground">Loading map...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Map Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Interactive Map
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            <Button onClick={getCurrentLocation} disabled={locationLoading} variant="outline" size="sm">
              {locationLoading ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Navigation className="h-4 w-4 mr-2" />
              )}
              {locationLoading ? 'Finding Location...' : 'Get Current Location'}
            </Button>

            {currentLocation && (
              <div className="text-sm text-muted-foreground flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                Current: {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Leaflet Map */}
      <Card>
        <CardContent className="p-0">
          <div
            ref={mapElRef}
            className="w-full rounded-lg bg-muted/20"
            style={{ height: '400px', minHeight: '400px', width: '100%' }}
          />
        </CardContent>
      </Card>

      {/* Geofence Alerts */}
      <GeofenceAlerts />
    </div>
  );
};

export default Map;

