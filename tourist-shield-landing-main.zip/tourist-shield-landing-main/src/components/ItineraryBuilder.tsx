import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Plus, 
  Calendar, 
  Clock, 
  MapPin, 
  Edit2, 
  Trash2, 
  Save,
  X
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Trip } from '@/hooks/useTouristData';

interface ItineraryItem {
  id: string;
  trip_id: string;
  day_number: number;
  activity: string;
  location: string;
  time_start?: string;
  time_end?: string;
  notes?: string;
  created_at: string;
}

interface ItineraryBuilderProps {
  trip: Trip;
  onBack: () => void;
}

const ItineraryBuilder = ({ trip, onBack }: ItineraryBuilderProps) => {
  const [itineraryItems, setItineraryItems] = useState<ItineraryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState<string | null>(null);
  const [newItem, setNewItem] = useState<Partial<ItineraryItem>>({});
  const [activeDay, setActiveDay] = useState(1);
  const { toast } = useToast();

  // Calculate trip duration and generate days
  const tripDuration = Math.ceil((new Date(trip.end_date).getTime() - new Date(trip.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1;
  const days = Array.from({ length: tripDuration }, (_, i) => i + 1);

  useEffect(() => {
    fetchItineraryItems();
  }, [trip.id]);

  const fetchItineraryItems = async () => {
    try {
      const { data, error } = await supabase
        .from('itinerary_items')
        .select('*')
        .eq('trip_id', trip.id)
        .order('day_number', { ascending: true })
        .order('time_start', { ascending: true });

      if (error) throw error;
      setItineraryItems(data || []);
    } catch (error) {
      console.error('Error fetching itinerary:', error);
      toast({
        title: "Error",
        description: "Failed to load itinerary items",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const addItineraryItem = async (dayNumber: number) => {
    if (!newItem.activity || !newItem.location) {
      toast({
        title: "Missing Information",
        description: "Please provide activity and location",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data, error } = await supabase
        .from('itinerary_items')
        .insert({
          trip_id: trip.id,
          day_number: dayNumber,
          activity: newItem.activity,
          location: newItem.location,
          time_start: newItem.time_start || null,
          time_end: newItem.time_end || null,
          notes: newItem.notes || null,
        })
        .select()
        .single();

      if (error) throw error;
      
      setItineraryItems(prev => [...prev, data]);
      setNewItem({});
      toast({
        title: "Success",
        description: "Itinerary item added successfully",
      });
    } catch (error) {
      console.error('Error adding item:', error);
      toast({
        title: "Error",
        description: "Failed to add itinerary item",
        variant: "destructive",
      });
    }
  };

  const updateItineraryItem = async (itemId: string, updates: Partial<ItineraryItem>) => {
    try {
      const { data, error } = await supabase
        .from('itinerary_items')
        .update(updates)
        .eq('id', itemId)
        .select()
        .single();

      if (error) throw error;

      setItineraryItems(prev => prev.map(item => 
        item.id === itemId ? { ...item, ...data } : item
      ));
      setEditingItem(null);
      toast({
        title: "Success",
        description: "Itinerary item updated successfully",
      });
    } catch (error) {
      console.error('Error updating item:', error);
      toast({
        title: "Error",
        description: "Failed to update itinerary item",
        variant: "destructive",
      });
    }
  };

  const deleteItineraryItem = async (itemId: string) => {
    try {
      const { error } = await supabase
        .from('itinerary_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;

      setItineraryItems(prev => prev.filter(item => item.id !== itemId));
      toast({
        title: "Success",
        description: "Itinerary item deleted successfully",
      });
    } catch (error) {
      console.error('Error deleting item:', error);
      toast({
        title: "Error",
        description: "Failed to delete itinerary item",
        variant: "destructive",
      });
    }
  };

  const getDateForDay = (dayNumber: number) => {
    const startDate = new Date(trip.start_date);
    const targetDate = new Date(startDate);
    targetDate.setDate(startDate.getDate() + dayNumber - 1);
    return targetDate;
  };

  const getItemsForDay = (dayNumber: number) => {
    return itineraryItems.filter(item => item.day_number === dayNumber);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Trips
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Itinerary Builder</h2>
          <p className="text-muted-foreground">
            {trip.destination} • {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}
          </p>
        </div>
      </div>

      {/* Trip Overview */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <h3 className="font-semibold text-lg">{trip.destination}</h3>
                <p className="text-sm text-muted-foreground">
                  {tripDuration} days • {itineraryItems.length} activities planned
                </p>
              </div>
            </div>
            <Badge variant="outline">{trip.status}</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Day Tabs */}
      <Tabs value={activeDay.toString()} onValueChange={(value) => setActiveDay(parseInt(value))}>
        <TabsList className="w-full overflow-x-auto">
          {days.map(day => (
            <TabsTrigger key={day} value={day.toString()} className="flex-shrink-0">
              <div className="text-center">
                <div className="text-xs">Day {day}</div>
                <div className="text-xs text-muted-foreground">
                  {getDateForDay(day).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </div>
              </div>
            </TabsTrigger>
          ))}
        </TabsList>

        {days.map(day => (
          <TabsContent key={day} value={day.toString()} className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">
                  Day {day} - {getDateForDay(day).toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {getItemsForDay(day).length} activities planned
                </p>
              </div>
              <Button 
                onClick={() => {
                  setNewItem({ day_number: day });
                  setEditingItem('new');
                }}
                size="sm"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Activity
              </Button>
            </div>

            {/* Add New Item Form */}
            {editingItem === 'new' && (
              <Card className="border-primary/50 bg-primary/5">
                <CardContent className="p-4 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      placeholder="Activity name"
                      value={newItem.activity || ''}
                      onChange={(e) => setNewItem(prev => ({ ...prev, activity: e.target.value }))}
                    />
                    <Input
                      placeholder="Location"
                      value={newItem.location || ''}
                      onChange={(e) => setNewItem(prev => ({ ...prev, location: e.target.value }))}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-muted-foreground">Start Time</label>
                      <Input
                        type="time"
                        value={newItem.time_start || ''}
                        onChange={(e) => setNewItem(prev => ({ ...prev, time_start: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">End Time</label>
                      <Input
                        type="time"
                        value={newItem.time_end || ''}
                        onChange={(e) => setNewItem(prev => ({ ...prev, time_end: e.target.value }))}
                      />
                    </div>
                  </div>

                  <Textarea
                    placeholder="Notes (optional)"
                    value={newItem.notes || ''}
                    onChange={(e) => setNewItem(prev => ({ ...prev, notes: e.target.value }))}
                    className="min-h-[60px]"
                  />

                  <div className="flex gap-2">
                    <Button 
                      onClick={() => addItineraryItem(day)}
                      size="sm"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Activity
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setEditingItem(null);
                        setNewItem({});
                      }}
                      size="sm"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Existing Items */}
            <div className="space-y-3">
              {getItemsForDay(day).map((item) => (
                <Card key={item.id} className="hover:shadow-md transition-shadow">
                  {editingItem === item.id ? (
                    <CardContent className="p-4 space-y-4">
                      <EditItemForm
                        item={item}
                        onSave={(updates) => updateItineraryItem(item.id, updates)}
                        onCancel={() => setEditingItem(null)}
                      />
                    </CardContent>
                  ) : (
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            {item.time_start && (
                              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {item.time_start}
                                {item.time_end && ` - ${item.time_end}`}
                              </div>
                            )}
                          </div>
                          
                          <h4 className="font-semibold text-lg mb-1">{item.activity}</h4>
                          
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                            <MapPin className="h-3 w-3" />
                            {item.location}
                          </div>
                          
                          {item.notes && (
                            <p className="text-sm text-muted-foreground mt-2">{item.notes}</p>
                          )}
                        </div>
                        
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingItem(item.id)}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteItineraryItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}

              {getItemsForDay(day).length === 0 && editingItem !== 'new' && (
                <Card className="border-dashed">
                  <CardContent className="text-center py-8">
                    <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-4">No activities planned for this day yet</p>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setNewItem({ day_number: day });
                        setEditingItem('new');
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add First Activity
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

// Edit Item Form Component
const EditItemForm = ({ 
  item, 
  onSave, 
  onCancel 
}: { 
  item: ItineraryItem;
  onSave: (updates: Partial<ItineraryItem>) => void;
  onCancel: () => void;
}) => {
  const [editData, setEditData] = useState({
    activity: item.activity,
    location: item.location,
    time_start: item.time_start || '',
    time_end: item.time_end || '',
    notes: item.notes || '',
  });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Input
          placeholder="Activity name"
          value={editData.activity}
          onChange={(e) => setEditData(prev => ({ ...prev, activity: e.target.value }))}
        />
        <Input
          placeholder="Location"
          value={editData.location}
          onChange={(e) => setEditData(prev => ({ ...prev, location: e.target.value }))}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm text-muted-foreground">Start Time</label>
          <Input
            type="time"
            value={editData.time_start}
            onChange={(e) => setEditData(prev => ({ ...prev, time_start: e.target.value }))}
          />
        </div>
        <div>
          <label className="text-sm text-muted-foreground">End Time</label>
          <Input
            type="time"
            value={editData.time_end}
            onChange={(e) => setEditData(prev => ({ ...prev, time_end: e.target.value }))}
          />
        </div>
      </div>

      <Textarea
        placeholder="Notes (optional)"
        value={editData.notes}
        onChange={(e) => setEditData(prev => ({ ...prev, notes: e.target.value }))}
        className="min-h-[60px]"
      />

      <div className="flex gap-2">
        <Button onClick={() => onSave(editData)} size="sm">
          <Save className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
        <Button variant="outline" onClick={onCancel} size="sm">
          <X className="h-4 w-4 mr-2" />
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default ItineraryBuilder;
