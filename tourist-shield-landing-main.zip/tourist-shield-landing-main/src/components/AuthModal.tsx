import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { useTouristData } from '@/hooks/useTouristData';
import { supabase } from '@/integrations/supabase/client';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: "signin" | "signup";
}

export const AuthModal = ({ isOpen, onClose, mode }: AuthModalProps) => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Registration form data
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    dateOfBirth: '',
    nationality: '',
    passportNumber: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    emergencyContactRelationship: '',
    emergencyContactEmail: '',
    destination: '',
    startDate: '',
    endDate: '',
    accommodation: '',
    transportation: '',
    budget: ''
  });
  
  const [kycFile, setKycFile] = useState<File | null>(null);
  const { signIn, signUp } = useAuth();
  const { createTouristProfile, addEmergencyContact, createTrip } = useTouristData();

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error } = await signIn(email, password);
      if (!error) {
        onClose();
      }
    } catch (error) {
      console.error('Auth error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignUpStep1 = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !email || !password) return;
    
    setLoading(true);
    try {
      const { error } = await signUp(email, password, formData.fullName);
      if (!error) {
        setStep(2);
      }
    } catch (error) {
      console.error('Signup error:', error);
    } finally {
      setLoading(false);
    }
  };

  const uploadKycDocument = async (file: File, userId: string) => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/kyc_document.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from('kyc-documents')
      .upload(fileName, file, {
        upsert: true
      });

    if (error) throw error;
    return data.path;
  };

  const completeRegistration = async () => {
    setLoading(true);
    try {
      // Wait for auth user to be available
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      let kycDocumentUrl = '';
      if (kycFile) {
        kycDocumentUrl = await uploadKycDocument(kycFile, user.id);
      }

      // Create tourist profile
      const tourist = await createTouristProfile({
        full_name: formData.fullName,
        phone: formData.phone,
        date_of_birth: formData.dateOfBirth,
        nationality: formData.nationality,
        passport_number: formData.passportNumber,
        kyc_document_url: kycDocumentUrl,
        kyc_status: 'pending'
      });

      if (!tourist) throw new Error('Failed to create profile');

      // Add emergency contact
      if (formData.emergencyContactName && formData.emergencyContactPhone) {
        await addEmergencyContact({
          name: formData.emergencyContactName,
          phone: formData.emergencyContactPhone,
          relationship: formData.emergencyContactRelationship,
          email: formData.emergencyContactEmail
        });
      }

      // Create trip
      if (formData.destination && formData.startDate && formData.endDate) {
        await createTrip({
          destination: formData.destination,
          start_date: formData.startDate,
          end_date: formData.endDate,
          accommodation: formData.accommodation,
          transportation: formData.transportation,
          budget: formData.budget ? parseFloat(formData.budget) : undefined,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      }

      onClose();
    } catch (error) {
      console.error('Registration completion error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (mode === 'signin') {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center">
              Welcome Back
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSignIn} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full"
              disabled={loading}
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            Join Tourist Shield - Step {step} of 3
          </DialogTitle>
        </DialogHeader>
        
        {step === 1 && (
          <form onSubmit={handleSignUpStep1} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="Your full name"
                  value={formData.fullName}
                  onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+1 234 567 8900"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <Input
                id="password"
                type="password"
                placeholder="Create a strong password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="nationality">Nationality</Label>
                <Input
                  id="nationality"
                  type="text"
                  placeholder="e.g., American, Indian, British"
                  value={formData.nationality}
                  onChange={(e) => setFormData(prev => ({ ...prev, nationality: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="passportNumber">Passport Number</Label>
              <Input
                id="passportNumber"
                type="text"
                placeholder="Passport or ID number"
                value={formData.passportNumber}
                onChange={(e) => setFormData(prev => ({ ...prev, passportNumber: e.target.value }))}
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full"
              disabled={loading}
            >
              {loading ? 'Creating Account...' : 'Next: Emergency Contact'}
            </Button>
          </form>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="kycFile">KYC Document (Passport/Aadhaar)</Label>
              <Input
                id="kycFile"
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => setKycFile(e.target.files?.[0] || null)}
              />
              <p className="text-sm text-muted-foreground">
                Upload a clear photo of your passport or Aadhaar card for identity verification
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="emergencyContactName">Emergency Contact Name</Label>
                <Input
                  id="emergencyContactName"
                  type="text"
                  placeholder="Contact person name"
                  value={formData.emergencyContactName}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergencyContactName: e.target.value }))}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="emergencyContactPhone">Emergency Contact Phone</Label>
                <Input
                  id="emergencyContactPhone"
                  type="tel"
                  placeholder="+1 234 567 8900"
                  value={formData.emergencyContactPhone}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergencyContactPhone: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="emergencyContactRelationship">Relationship</Label>
                <Select 
                  value={formData.emergencyContactRelationship} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, emergencyContactRelationship: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="spouse">Spouse</SelectItem>
                    <SelectItem value="sibling">Sibling</SelectItem>
                    <SelectItem value="friend">Friend</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="emergencyContactEmail">Emergency Contact Email</Label>
                <Input
                  id="emergencyContactEmail"
                  type="email"
                  placeholder="contact@example.com"
                  value={formData.emergencyContactEmail}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergencyContactEmail: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setStep(1)}
                className="flex-1"
              >
                Back
              </Button>
              <Button 
                type="button"
                onClick={() => setStep(3)}
                className="flex-1"
              >
                Next: Trip Planning
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="destination">Destination</Label>
                <Input
                  id="destination"
                  type="text"
                  placeholder="e.g., Kerala, India"
                  value={formData.destination}
                  onChange={(e) => setFormData(prev => ({ ...prev, destination: e.target.value }))}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="budget">Budget (USD)</Label>
                <Input
                  id="budget"
                  type="number"
                  placeholder="1000"
                  value={formData.budget}
                  onChange={(e) => setFormData(prev => ({ ...prev, budget: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endDate">End Date</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="accommodation">Accommodation</Label>
              <Input
                id="accommodation"
                type="text"
                placeholder="Hotel, Airbnb, Hostel, etc."
                value={formData.accommodation}
                onChange={(e) => setFormData(prev => ({ ...prev, accommodation: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="transportation">Transportation</Label>
              <Input
                id="transportation"
                type="text"
                placeholder="Flight, Train, Bus, Car, etc."
                value={formData.transportation}
                onChange={(e) => setFormData(prev => ({ ...prev, transportation: e.target.value }))}
              />
            </div>
            
            <div className="flex gap-2">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setStep(2)}
                className="flex-1"
              >
                Back
              </Button>
              <Button 
                type="button"
                onClick={completeRegistration}
                disabled={loading}
                className="flex-1"
              >
                {loading ? 'Completing Registration...' : 'Complete Registration'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};