// import { useState } from 'react';
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
// import { Button } from '@/components/ui/button';
// import { Badge } from '@/components/ui/badge';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
// import { 
//   MapPin, 
//   Shield, 
//   Hospital, 
//   Phone, 
//   AlertTriangle, 
//   Navigation, 
//   Users, 
//   Clock,
//   ExternalLink
// } from 'lucide-react';

// export const MapEnhancements = () => {
//   const [selectedFeature, setSelectedFeature] = useState<string | null>(null);

//   const emergencyLocations = [
//     { id: '1', name: 'Central Hospital', type: 'hospital', distance: '0.8 km', phone: '+1-555-0101' },
//     { id: '2', name: 'Police Station', type: 'police', distance: '1.2 km', phone: '+1-555-0102' },
//     { id: '3', name: 'Fire Department', type: 'fire', distance: '0.9 km', phone: '+1-555-0103' },
//     { id: '4', name: 'Tourist Help Center', type: 'tourist', distance: '0.5 km', phone: '+1-555-0104' }
//   ];

//   const safeZones = [
//     { id: '1', name: 'Hotel District', status: 'safe', level: 'high' },
//     { id: '2', name: 'Shopping Center', status: 'safe', level: 'medium' },
//     { id: '3', name: 'Tourist Quarter', status: 'safe', level: 'high' }
//   ];

//   const restrictedZones = [
//     { id: '1', name: 'Construction Site', status: 'restricted', level: 'medium' },
//     { id: '2', name: 'Industrial Area', status: 'avoid', level: 'high' }
//   ];

//   const getLocationIcon = (type: string) => {
//     switch (type) {
//       case 'hospital': return <Hospital className="h-4 w-4 text-red-500" />;
//       case 'police': return <Shield className="h-4 w-4 text-blue-500" />;
//       case 'fire': return <AlertTriangle className="h-4 w-4 text-orange-500" />;
//       case 'tourist': return <MapPin className="h-4 w-4 text-green-500" />;
//       default: return <MapPin className="h-4 w-4" />;
//     }
//   };

//   const getStatusColor = (status: string, level: string) => {
//     if (status === 'safe') return level === 'high' ? 'bg-green-500' : 'bg-green-400';
//     if (status === 'restricted') return 'bg-yellow-500';
//     if (status === 'avoid') return 'bg-red-500';
//     return 'bg-gray-500';
//   };

//   return (
//     <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
//       {/* Map Control Panel */}
//       <div className="lg:col-span-1 space-y-4">
//         <Card>
//           <CardHeader>
//             <CardTitle className="flex items-center gap-2">
//               <Navigation className="h-5 w-5" />
//               Map Controls
//             </CardTitle>
//             <CardDescription>Interactive map features and overlays</CardDescription>
//           </CardHeader>
//           <CardContent>
//             <Tabs defaultValue="emergency" className="w-full">
//               <TabsList className="grid w-full grid-cols-3">
//                 <TabsTrigger value="emergency">Emergency</TabsTrigger>
//                 <TabsTrigger value="zones">Zones</TabsTrigger>
//                 <TabsTrigger value="sharing">Sharing</TabsTrigger>
//               </TabsList>
              
//               <TabsContent value="emergency" className="space-y-3">
//                 <h4 className="font-medium text-sm">Nearby Emergency Services</h4>
//                 {emergencyLocations.map((location) => (
//                   <div key={location.id} className="flex items-center justify-between p-2 border rounded">
//                     <div className="flex items-center gap-2">
//                       {getLocationIcon(location.type)}
//                       <div>
//                         <p className="text-sm font-medium">{location.name}</p>
//                         <p className="text-xs text-muted-foreground">{location.distance}</p>
//                       </div>
//                     </div>
//                     <Button variant="ghost" size="sm" asChild>
//                       <a href={`tel:${location.phone}`}>
//                         <Phone className="h-3 w-3" />
//                       </a>
//                     </Button>
//                   </div>
//                 ))}
//               </TabsContent>
              
//               <TabsContent value="zones" className="space-y-3">
//                 <div>
//                   <h4 className="font-medium text-sm mb-2 text-green-700">Safe Zones</h4>
//                   {safeZones.map((zone) => (
//                     <div key={zone.id} className="flex items-center justify-between p-2 border rounded">
//                       <div className="flex items-center gap-2">
//                         <div className={`w-2 h-2 rounded-full ${getStatusColor(zone.status, zone.level)}`} />
//                         <span className="text-sm">{zone.name}</span>
//                       </div>
//                       <Badge variant="outline" className="text-xs">
//                         {zone.level} safety
//                       </Badge>
//                     </div>
//                   ))}
//                 </div>
                
//                 <div>
//                   <h4 className="font-medium text-sm mb-2 text-red-700">Restricted Areas</h4>
//                   {restrictedZones.map((zone) => (
//                     <div key={zone.id} className="flex items-center justify-between p-2 border rounded">
//                       <div className="flex items-center gap-2">
//                         <div className={`w-2 h-2 rounded-full ${getStatusColor(zone.status, zone.level)}`} />
//                         <span className="text-sm">{zone.name}</span>
//                       </div>
//                       <Badge variant="destructive" className="text-xs">
//                         {zone.status}
//                       </Badge>
//                     </div>
//                   ))}
//                 </div>
//               </TabsContent>
              
//               <TabsContent value="sharing" className="space-y-3">
//                 <div className="space-y-3">
//                   <div className="flex items-center justify-between p-3 border rounded">
//                     <div>
//                       <h4 className="font-medium text-sm">Real-time Location</h4>
//                       <p className="text-xs text-muted-foreground">Share with emergency contacts</p>
//                     </div>
//                     <Badge variant="outline">Active</Badge>
//                   </div>
                  
//                   <div className="flex items-center justify-between p-3 border rounded">
//                     <div>
//                       <h4 className="font-medium text-sm">Trip Route Sharing</h4>
//                       <p className="text-xs text-muted-foreground">Share planned route</p>
//                     </div>
//                     <Button variant="outline" size="sm">Enable</Button>
//                   </div>
                  
//                   <div className="bg-muted/50 rounded-lg p-3">
//                     <div className="flex items-center gap-2 mb-2">
//                       <Users className="h-4 w-4 text-blue-500" />
//                       <span className="text-sm font-medium">Shared With</span>
//                     </div>
//                     <div className="space-y-1 text-xs">
//                       <div className="flex justify-between">
//                         <span>Emergency Contact 1</span>
//                         <span className="text-muted-foreground">2 min ago</span>
//                       </div>
//                       <div className="flex justify-between">
//                         <span>Emergency Contact 2</span>
//                         <span className="text-muted-foreground">5 min ago</span>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </TabsContent>
//             </Tabs>
//           </CardContent>
//         </Card>
        
//         {/* Quick Actions */}
//         <Card>
//           <CardHeader>
//             <CardTitle className="text-lg">Quick Actions</CardTitle>
//           </CardHeader>
//           <CardContent className="space-y-2">
//             <Button variant="outline" className="w-full justify-start" size="sm">
//               <MapPin className="h-4 w-4 mr-2" />
//               Add Waypoint
//             </Button>
//             <Button variant="outline" className="w-full justify-start" size="sm">
//               <Navigation className="h-4 w-4 mr-2" />
//               Get Directions
//             </Button>
//             <Button variant="outline" className="w-full justify-start" size="sm">
//               <ExternalLink className="h-4 w-4 mr-2" />
//               Open in Maps App
//             </Button>
//           </CardContent>
//         </Card>
//       </div>
      
//       {/* Location History */}
//       <div className="lg:col-span-2">
//         <Card>
//           <CardHeader>
//             <CardTitle className="flex items-center gap-2">
//               <Clock className="h-5 w-5" />
//               Recent Locations
//             </CardTitle>
//             <CardDescription>Your location history for this trip</CardDescription>
//           </CardHeader>
//           <CardContent>
//             <div className="space-y-3">
//               {[
//                 { time: '2 hours ago', location: 'Tourist Information Center', type: 'visit' },
//                 { time: '4 hours ago', location: 'Central Hotel', type: 'stay' },
//                 { time: '6 hours ago', location: 'Airport Terminal', type: 'arrival' },
//               ].map((entry, index) => (
//                 <div key={index} className="flex items-center gap-3 p-3 border rounded">
//                   <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
//                     <MapPin className="h-4 w-4 text-primary" />
//                   </div>
//                   <div className="flex-1">
//                     <p className="font-medium text-sm">{entry.location}</p>
//                     <p className="text-xs text-muted-foreground">{entry.time}</p>
//                   </div>
//                   <Badge variant="outline" className="text-xs">
//                     {entry.type}
//                   </Badge>
//                 </div>
//               ))}
//             </div>
//           </CardContent>
//         </Card>
//       </div>
//     </div>
//   );
// };


import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  MapPin,
  Shield,
  Hospital,
  Phone,
  AlertTriangle,
  Navigation,
  Users,
  Clock,
  ExternalLink
} from 'lucide-react';

export const MapEnhancements = () => {
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);

  const emergencyLocations = [
    { id: '1', name: 'Central Hospital', type: 'hospital', distance: '0.8 km', phone: '+1-555-0101' },
    { id: '2', name: 'Police Station', type: 'police', distance: '1.2 km', phone: '+1-555-0102' },
    { id: '3', name: 'Fire Department', type: 'fire', distance: '0.9 km', phone: '+1-555-0103' },
    { id: '4', name: 'Tourist Help Center', type: 'tourist', distance: '0.5 km', phone: '+1-555-0104' }
  ];

  const safeZones = [
    { id: '1', name: 'Hotel District', status: 'safe', level: 'high' },
    { id: '2', name: 'Shopping Center', status: 'safe', level: 'medium' },
    { id: '3', name: 'Tourist Quarter', status: 'safe', level: 'high' }
  ];

  const restrictedZones = [
    { id: '1', name: 'Construction Site', status: 'restricted', level: 'medium' },
    { id: '2', name: 'Industrial Area', status: 'avoid', level: 'high' }
  ];

  const getLocationIcon = (type: string) => {
    switch (type) {
      case 'hospital':
        return <Hospital className="h-4 w-4 text-red-500" />;
      case 'police':
        return <Shield className="h-4 w-4 text-blue-500" />;
      case 'fire':
        return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      case 'tourist':
        return <MapPin className="h-4 w-4 text-green-500" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string, level: string) => {
    if (status === 'safe') return level === 'high' ? 'bg-green-500' : 'bg-green-400';
    if (status === 'restricted') return 'bg-yellow-500';
    if (status === 'avoid') return 'bg-red-500';
    return 'bg-gray-500';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
      {/* Map Control Panel */}
      <div className="lg:col-span-1 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5" />
              Map Controls
            </CardTitle>
            <CardDescription>Interactive map features and overlays</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="emergency" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="emergency">Emergency</TabsTrigger>
                <TabsTrigger value="zones">Zones</TabsTrigger>
                <TabsTrigger value="sharing">Sharing</TabsTrigger>
              </TabsList>

              {/* Emergency Services */}
              <TabsContent value="emergency" className="space-y-3">
                <h4 className="font-medium text-sm">Nearby Emergency Services</h4>
                {emergencyLocations.map((location) => (
                  <div key={location.id} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center gap-2">
                      {getLocationIcon(location.type)}
                      <div>
                        <p className="text-sm font-medium">{location.name}</p>
                        <p className="text-xs text-muted-foreground">{location.distance}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <a href={`tel:${location.phone}`}>
                        <Phone className="h-3 w-3" />
                      </a>
                    </Button>
                  </div>
                ))}
              </TabsContent>

              {/* Zones */}
              <TabsContent value="zones" className="space-y-3">
                <div>
                  <h4 className="font-medium text-sm mb-2 text-green-700">Safe Zones</h4>
                  {safeZones.map((zone) => (
                    <div key={zone.id} className="flex items-center justify-between p-2 border rounded">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(zone.status, zone.level)}`} />
                        <span className="text-sm">{zone.name}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {zone.level} safety
                      </Badge>
                    </div>
                  ))}
                </div>

                <div>
                  <h4 className="font-medium text-sm mb-2 text-red-700">Restricted Areas</h4>
                  {restrictedZones.map((zone) => (
                    <div key={zone.id} className="flex items-center justify-between p-2 border rounded">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(zone.status, zone.level)}`} />
                        <span className="text-sm">{zone.name}</span>
                      </div>
                      <Badge variant="destructive" className="text-xs">
                        {zone.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* Sharing */}
              <TabsContent value="sharing" className="space-y-3">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <h4 className="font-medium text-sm">Real-time Location</h4>
                      <p className="text-xs text-muted-foreground">Share with emergency contacts</p>
                    </div>
                    <Badge variant="outline">Active</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <h4 className="font-medium text-sm">Trip Route Sharing</h4>
                      <p className="text-xs text-muted-foreground">Share planned route</p>
                    </div>
                    <Button variant="outline" size="sm">Enable</Button>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">Shared With</span>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>Emergency Contact 1</span>
                        <span className="text-muted-foreground">2 min ago</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Emergency Contact 2</span>
                        <span className="text-muted-foreground">5 min ago</span>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start" size="sm">
              <MapPin className="h-4 w-4 mr-2" />
              Add Waypoint
            </Button>
            <Button variant="outline" className="w-full justify-start" size="sm">
              <Navigation className="h-4 w-4 mr-2" />
              Get Directions
            </Button>
            <Button variant="outline" className="w-full justify-start" size="sm">
              <ExternalLink className="h-4 w-4 mr-2" />
              Open in Maps App
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Location History */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Recent Locations
            </CardTitle>
            <CardDescription>Your location history for this trip</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { time: '2 hours ago', location: 'Tourist Information Center', type: 'visit' },
                { time: '4 hours ago', location: 'Central Hotel', type: 'stay' },
                { time: '6 hours ago', location: 'Airport Terminal', type: 'arrival' },
              ].map((entry, index) => (
                <div key={index} className="flex items-center gap-3 p-3 border rounded">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{entry.location}</p>
                    <p className="text-xs text-muted-foreground">{entry.time}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">{entry.type}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
