import React, { useMemo, memo, useCallback } from 'react';
import L from 'leaflet';

interface DangerousZone {
  id: string;
  name: string;
  zone_type: string;
  risk_level: 'critical' | 'high' | 'medium' | 'low';
  geometry: {
    type: 'Polygon';
    coordinates: number[][][];
  };
  alert_message?: string;
  description?: string;
}

interface SafetyZone {
  id: string;
  latitude: number;
  longitude: number;
  title: string;
  type: 'police' | 'hospital' | 'shelter' | 'embassy';
  description: string;
}

interface LiveIncident {
  id: string;
  latitude: number;
  longitude: number;
  title: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  incident_type: string;
}

interface OptimizedMapRendererProps {
  map: L.Map | null;
  dangerousZones: DangerousZone[];
  safetyZones: SafetyZone[];
  incidents: LiveIncident[];
  userLocation: { latitude: number; longitude: number } | null;
  viewport?: L.LatLngBounds;
}

// Memoized polygon renderer for dangerous zones
const DangerousZoneRenderer = memo(({ zone, map }: { zone: DangerousZone; map: L.Map }) => {
  const polygon = useMemo(() => {
    if (!map || !zone.geometry?.coordinates?.[0]) return null;

    const coordinates = zone.geometry.coordinates[0].map(coord => [coord[1], coord[0]] as [number, number]);
    
    const riskColors = {
      critical: '#DC2626',
      high: '#EA580C', 
      medium: '#D97706',
      low: '#65A30D'
    };

    return L.polygon(coordinates, {
      color: riskColors[zone.risk_level],
      weight: 2,
      opacity: 0.8,
      fillColor: riskColors[zone.risk_level],
      fillOpacity: 0.2,
      className: `dangerous-zone-${zone.risk_level}`
    });
  }, [zone, map]);

  React.useEffect(() => {
    if (polygon && map) {
      polygon.addTo(map);
      
      polygon.bindPopup(`
        <div class="font-sans">
          <h3 class="font-bold text-destructive">${zone.name}</h3>
          <p class="text-sm text-muted-foreground mb-2">${zone.description || ''}</p>
          <div class="flex items-center gap-2">
            <span class="text-xs px-2 py-1 rounded bg-destructive/20 text-destructive">
              ${zone.risk_level.toUpperCase()} RISK
            </span>
          </div>
          <p class="text-sm mt-2">${zone.alert_message}</p>
        </div>
      `);

      return () => {
        map.removeLayer(polygon);
      };
    }
  }, [polygon, map]);

  return null;
});

// Memoized marker renderer for safety zones
const SafetyZoneRenderer = memo(({ zone, map }: { zone: SafetyZone; map: L.Map }) => {
  const marker = useMemo(() => {
    if (!map) return null;

    const iconMap = {
      police: '🚔',
      hospital: '🏥', 
      shelter: '🏠',
      embassy: '🏛'
    };
    
    const colorMap = {
      police: '#3B82F6',
      hospital: '#EF4444',
      shelter: '#10B981',
      embassy: '#8B5CF6'
    };

    const icon = L.divIcon({
      className: 'custom-safety-icon',
      html: `
        <div style="
          width: 30px;
          height: 30px;
          background-color: ${colorMap[zone.type]};
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
          font-size: 14px;
        ">
          ${iconMap[zone.type]}
        </div>
      `,
      iconSize: [30, 30],
      iconAnchor: [15, 15],
      popupAnchor: [0, -15]
    });

    return L.marker([zone.latitude, zone.longitude], { icon });
  }, [zone, map]);

  React.useEffect(() => {
    if (marker && map) {
      marker.addTo(map);
      
      marker.bindPopup(`
        <div class="font-sans">
          <h3 class="font-bold text-primary">${zone.title}</h3>
          <p class="text-sm text-muted-foreground mb-2">${zone.description}</p>
          <span class="text-xs px-2 py-1 rounded bg-primary/20 text-primary capitalize">
            ${zone.type.replace('_', ' ')}
          </span>
        </div>
      `);

      return () => {
        map.removeLayer(marker);
      };
    }
  }, [marker, map]);

  return null;
});

// Memoized incident renderer with clustering for performance
const IncidentRenderer = memo(({ incidents, map }: { incidents: LiveIncident[]; map: L.Map }) => {
  const markers = useMemo(() => {
    if (!map || incidents.length === 0) return null;

    // Simple clustering: group incidents within 100m radius
    const clustered = incidents.reduce((acc, incident) => {
      const existing = acc.find(cluster => {
        const distance = L.latLng(incident.latitude, incident.longitude)
          .distanceTo(L.latLng(cluster.lat, cluster.lng));
        return distance < 100; // 100m clustering radius
      });

      if (existing) {
        existing.incidents.push(incident);
      } else {
        acc.push({
          lat: incident.latitude,
          lng: incident.longitude,
          incidents: [incident]
        });
      }

      return acc;
    }, [] as Array<{ lat: number; lng: number; incidents: LiveIncident[] }>);

    return clustered.map(cluster => {
      const severityColors = {
        critical: '#DC2626',
        high: '#EA580C',
        medium: '#D97706', 
        low: '#65A30D'
      };

      const maxSeverity = cluster.incidents.reduce((max, incident) => {
        const severityOrder = { low: 1, medium: 2, high: 3, critical: 4 };
        return severityOrder[incident.severity] > severityOrder[max.severity] ? incident : max;
      });

      const icon = L.divIcon({
        className: 'custom-incident-icon',
        html: `
          <div style="
            width: ${cluster.incidents.length > 1 ? 35 : 25}px;
            height: ${cluster.incidents.length > 1 ? 35 : 25}px;
            background-color: ${severityColors[maxSeverity.severity]};
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
            box-shadow: 0 2px 6px rgba(0,0,0,0.4);
            color: white;
            font-weight: bold;
            font-size: ${cluster.incidents.length > 1 ? 12 : 10}px;
          ">
            ${cluster.incidents.length > 1 ? cluster.incidents.length : '⚠'}
          </div>
        `,
        iconSize: [cluster.incidents.length > 1 ? 35 : 25, cluster.incidents.length > 1 ? 35 : 25],
        iconAnchor: [cluster.incidents.length > 1 ? 17 : 12, cluster.incidents.length > 1 ? 17 : 12]
      });

      const marker = L.marker([cluster.lat, cluster.lng], { icon });
      
      const popupContent = cluster.incidents.length > 1 
        ? `
          <div class="font-sans">
            <h3 class="font-bold text-destructive">${cluster.incidents.length} Incidents</h3>
            ${cluster.incidents.slice(0, 3).map(incident => `
              <div class="border-b border-border pb-2 mb-2 last:border-0">
                <p class="font-medium">${incident.title}</p>
                <span class="text-xs px-2 py-1 rounded bg-destructive/20 text-destructive">
                  ${incident.severity.toUpperCase()}
                </span>
              </div>
            `).join('')}
            ${cluster.incidents.length > 3 ? `<p class="text-sm text-muted-foreground">+${cluster.incidents.length - 3} more...</p>` : ''}
          </div>
        `
        : `
          <div class="font-sans">
            <h3 class="font-bold text-destructive">${cluster.incidents[0].title}</h3>
            <p class="text-sm text-muted-foreground mb-2">${cluster.incidents[0].incident_type}</p>
            <span class="text-xs px-2 py-1 rounded bg-destructive/20 text-destructive">
              ${cluster.incidents[0].severity.toUpperCase()}
            </span>
          </div>
        `;

      marker.bindPopup(popupContent);
      
      return marker;
    });
  }, [incidents, map]);

  React.useEffect(() => {
    if (markers && map) {
      markers.forEach(marker => marker.addTo(map));

      return () => {
        markers.forEach(marker => map.removeLayer(marker));
      };
    }
  }, [markers, map]);

  return null;
});

// Main optimized map renderer
export const OptimizedMapRenderer = memo<OptimizedMapRendererProps>(({ 
  map, 
  dangerousZones, 
  safetyZones, 
  incidents, 
  userLocation,
  viewport 
}) => {
  // Filter zones and incidents based on viewport for performance
  const visibleDangerousZones = useMemo(() => {
    if (!viewport || dangerousZones.length === 0) return dangerousZones;
    
    return dangerousZones.filter(zone => {
      if (!zone.geometry?.coordinates?.[0]) return false;
      
      // Quick bounds check
      const bounds = zone.geometry.coordinates[0].reduce((acc, coord) => ({
        minLng: Math.min(acc.minLng, coord[0]),
        maxLng: Math.max(acc.maxLng, coord[0]),
        minLat: Math.min(acc.minLat, coord[1]),
        maxLat: Math.max(acc.maxLat, coord[1])
      }), { minLng: Infinity, maxLng: -Infinity, minLat: Infinity, maxLat: -Infinity });
      
      return viewport.intersects(L.latLngBounds(
        [bounds.minLat, bounds.minLng],
        [bounds.maxLat, bounds.maxLng]
      ));
    });
  }, [dangerousZones, viewport]);

  const visibleSafetyZones = useMemo(() => {
    if (!viewport || safetyZones.length === 0) return safetyZones;
    
    return safetyZones.filter(zone => 
      viewport.contains([zone.latitude, zone.longitude])
    );
  }, [safetyZones, viewport]);

  const visibleIncidents = useMemo(() => {
    if (!viewport || incidents.length === 0) return incidents;
    
    return incidents.filter(incident => 
      viewport.contains([incident.latitude, incident.longitude])
    );
  }, [incidents, viewport]);

  if (!map) return null;

  return (
    <>
      {/* Render dangerous zones */}
      {visibleDangerousZones.map(zone => (
        <DangerousZoneRenderer key={zone.id} zone={zone} map={map} />
      ))}
      
      {/* Render safety zones */}
      {visibleSafetyZones.map(zone => (
        <SafetyZoneRenderer key={zone.id} zone={zone} map={map} />
      ))}
      
      {/* Render incidents */}
      <IncidentRenderer incidents={visibleIncidents} map={map} />
    </>
  );
});

OptimizedMapRenderer.displayName = 'OptimizedMapRenderer';