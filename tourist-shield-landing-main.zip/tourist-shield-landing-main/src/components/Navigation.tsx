import { useState } from "react";
import { Button } from "@/components/ui/button";
import { AuthModal } from "./AuthModal";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";

const Navigation = () => {
  const [showSignIn, setShowSignIn] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-heading font-bold text-primary">
                Tourist Shield
              </h1>
              <div className="hidden md:flex space-x-6">
                <a href="#services" className="text-foreground hover:text-primary transition-smooth">
                  Services
                </a>
                <a href="#about" className="text-foreground hover:text-primary transition-smooth">
                  About
                </a>
                <a href="#contact" className="text-foreground hover:text-primary transition-smooth">
                  Contact
                </a>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {user ? (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={() => navigate('/dashboard')}
                    className="text-foreground hover:text-primary hover:bg-accent/50"
                  >
                    Dashboard
                  </Button>
                  <Button 
                    variant="ghost" 
                    onClick={signOut}
                    className="text-foreground hover:text-primary hover:bg-accent/50"
                  >
                    Sign Out
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={() => setShowSignIn(true)}
                    className="text-foreground hover:text-primary hover:bg-accent/50"
                  >
                    Sign In
                  </Button>
                  <Button 
                    onClick={() => setShowSignUp(true)}
                    className="bg-primary hover:bg-primary-glow text-primary-foreground shadow-elegant"
                  >
                    Sign Up
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      <AuthModal 
        isOpen={showSignIn} 
        onClose={() => setShowSignIn(false)} 
        mode="signin" 
      />
      <AuthModal 
        isOpen={showSignUp} 
        onClose={() => setShowSignUp(false)} 
        mode="signup" 
      />
    </>
  );
};

export default Navigation;