import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Phone, MapPin, Heart, Plane, AlertTriangle } from "lucide-react";

const services = [
  {
    icon: Shield,
    title: "Travel Insurance",
    description: "Comprehensive coverage for medical emergencies, trip cancellations, and lost luggage protection."
  },
  {
    icon: Phone,
    title: "24/7 Emergency Hotline",
    description: "Round-the-clock assistance in multiple languages for any emergency or urgent situation."
  },
  {
    icon: MapPin,
    title: "Location Tracking",
    description: "Real-time location sharing with emergency contacts and instant alerts for safety zones."
  },
  {
    icon: Heart,
    title: "Medical Assistance",
    description: "Access to vetted medical facilities, prescription assistance, and medical evacuation services."
  },
  {
    icon: Plane,
    title: "Travel Alerts",
    description: "Live updates on weather, political situations, and safety advisories for your destinations."
  },
  {
    icon: AlertTriangle,
    title: "Crisis Management",
    description: "Expert coordination during natural disasters, political unrest, or other emergency situations."
  }
];

const ServicesSection = () => {
  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-6">
            Complete Protection Coverage
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our comprehensive suite of services ensures you're protected every step of your journey, 
            from planning to safe return home.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="bg-gradient-card border-border shadow-card hover:shadow-elegant transition-all duration-300 hover:scale-105"
            >
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 p-3 bg-gradient-accent rounded-full w-fit">
                  <service.icon className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-heading text-foreground">
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center leading-relaxed">
                  {service.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;