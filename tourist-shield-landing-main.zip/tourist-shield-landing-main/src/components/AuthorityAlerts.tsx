import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, MapPin, Clock, User, Phone, CheckCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AlertData {
  id: string;
  title: string;
  description: string;
  alert_type: string;
  priority: string;
  status: string;
  location_lat?: number;
  location_lng?: number;
  location_address?: string;
  created_at: string;
  updated_at: string;
  handled_by?: string;
  tourist: {
    id: string;
    full_name: string;
    phone?: string;
    nationality?: string;
    passport_number?: string;
  };
}

export const AuthorityAlerts = () => {
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingAlert, setProcessingAlert] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchAlerts = async () => {
    try {
      const { data, error } = await supabase
        .from('alerts')
        .select(`
          *,
          tourist:tourists(
            id,
            full_name,
            phone,
            nationality,
            passport_number
          )
        `)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        console.error('Error fetching alerts:', error);
        toast({
          title: "Error",
          description: "Failed to load alerts",
          variant: "destructive",
        });
        return;
      }

      setAlerts(data || []);
    } catch (error) {
      console.error('Error fetching alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAlert = async (alertId: string, action: 'acknowledge' | 'resolve') => {
    setProcessingAlert(alertId);
    
    try {
      const updates: any = {
        updated_at: new Date().toISOString(),
      };

      if (action === 'acknowledge') {
        updates.handled_by = (await supabase.auth.getUser()).data.user?.id;
        updates.status = 'acknowledged';
      } else if (action === 'resolve') {
        updates.status = 'resolved';
        updates.resolved_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('alerts')
        .update(updates)
        .eq('id', alertId);

      if (error) {
        throw error;
      }

      // Create alert log
      const { data: authorities } = await supabase
        .from('authorities')
        .select('id')
        .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
        .single();

      if (authorities) {
        await supabase
          .from('alert_logs')
          .insert({
            alert_id: alertId,
            authority_id: authorities.id,
            action: action,
            notes: `Alert ${action === 'acknowledge' ? 'acknowledged' : 'resolved'} by authority`,
          });
      }

      toast({
        title: "Success",
        description: `Alert ${action === 'acknowledge' ? 'acknowledged' : 'resolved'} successfully`,
      });

      // Refresh alerts
      fetchAlerts();

    } catch (error: any) {
      console.error('Error handling alert:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update alert",
        variant: "destructive",
      });
    } finally {
      setProcessingAlert(null);
    }
  };

  useEffect(() => {
    fetchAlerts();

    // Set up real-time subscription for new alerts
    const channel = supabase
      .channel('alerts-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'alerts'
        },
        (payload) => {
          console.log('New alert received:', payload);
          fetchAlerts(); // Refresh the list
          
          // Show notification for new emergency alerts
          if (payload.new.priority === 'critical') {
            toast({
              title: "🚨 NEW EMERGENCY ALERT",
              description: `${payload.new.title}`,
              duration: 8000,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'alerts'
        },
        (payload) => {
          console.log('Alert updated:', payload);
          fetchAlerts(); // Refresh the list
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'destructive';
      case 'acknowledged': return 'secondary';
      case 'resolved': return 'outline';
      default: return 'secondary';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading alerts...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Emergency Alerts</h2>
        <Button onClick={fetchAlerts} variant="outline" size="sm">
          Refresh
        </Button>
      </div>

      {alerts.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Active Alerts</h3>
            <p className="text-muted-foreground">All quiet on the watch. New alerts will appear here.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {alerts.map((alert) => (
            <Card key={alert.id} className={`border-l-4 ${alert.priority === 'critical' ? 'border-l-red-500' : alert.priority === 'high' ? 'border-l-orange-500' : 'border-l-yellow-500'}`}>
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className={`h-5 w-5 ${alert.priority === 'critical' ? 'text-red-500' : 'text-orange-500'}`} />
                      <CardTitle className="text-lg">{alert.title}</CardTitle>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getPriorityColor(alert.priority)} variant="secondary">
                        {alert.priority.toUpperCase()}
                      </Badge>
                      <Badge variant={getStatusColor(alert.status)}>
                        {alert.status.toUpperCase()}
                      </Badge>
                      <Badge variant="outline">
                        {alert.alert_type.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(alert.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm">{alert.description}</p>
                
                <Separator />
                
                {/* Tourist Information */}
                <div className="bg-muted/50 rounded-lg p-3">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Tourist Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="font-medium">Name:</span> {alert.tourist.full_name}
                    </div>
                    {alert.tourist.phone && (
                      <div>
                        <span className="font-medium">Phone:</span> {alert.tourist.phone}
                      </div>
                    )}
                    {alert.tourist.nationality && (
                      <div>
                        <span className="font-medium">Nationality:</span> {alert.tourist.nationality}
                      </div>
                    )}
                    {alert.tourist.passport_number && (
                      <div>
                        <span className="font-medium">Passport:</span> {alert.tourist.passport_number}
                      </div>
                    )}
                  </div>
                </div>

                {/* Location Information */}
                {alert.location_lat && alert.location_lng && (
                  <div className="bg-muted/50 rounded-lg p-3">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      Location
                    </h4>
                    <div className="text-sm space-y-1">
                      <div>
                        <span className="font-medium">Coordinates:</span> {alert.location_lat.toFixed(6)}, {alert.location_lng.toFixed(6)}
                      </div>
                      {alert.location_address && (
                        <div>
                          <span className="font-medium">Address:</span> {alert.location_address}
                        </div>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`https://maps.google.com/?q=${alert.location_lat},${alert.location_lng}`, '_blank')}
                      >
                        Open in Maps
                      </Button>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  {alert.status === 'active' && (
                    <Button
                      onClick={() => handleAlert(alert.id, 'acknowledge')}
                      disabled={processingAlert === alert.id}
                      variant="outline"
                      size="sm"
                    >
                      {processingAlert === alert.id ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      )}
                      Acknowledge
                    </Button>
                  )}
                  
                  {(alert.status === 'active' || alert.status === 'acknowledged') && (
                    <Button
                      onClick={() => handleAlert(alert.id, 'resolve')}
                      disabled={processingAlert === alert.id}
                      size="sm"
                    >
                      {processingAlert === alert.id ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      )}
                      Resolve
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};