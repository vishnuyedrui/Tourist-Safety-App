import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { CalendarIcon, ArrowLeft, MapPin, DollarSign, Plane, Building2 } from 'lucide-react';
import { useTouristData } from '@/hooks/useTouristData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import type { Trip } from '@/hooks/useTouristData';

const tripSchema = z.object({
  destination: z.string().min(2, 'Destination must be at least 2 characters'),
  start_date: z.date(),
  end_date: z.date(),
  budget: z.number().optional(),
  accommodation: z.string().optional(),
  transportation: z.string().optional(),
  notes: z.string().optional(),
}).refine((data) => data.end_date > data.start_date, {
  message: "End date must be after start date",
  path: ["end_date"],
});

type TripFormData = z.infer<typeof tripSchema>;

interface TripFormProps {
  trip?: Trip | null;
  onClose: () => void;
  onSuccess: (trip: Trip) => void;
}

const TripForm = ({ trip, onClose, onSuccess }: TripFormProps) => {
  const { createTrip, updateProfile } = useTouristData();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<TripFormData>({
    resolver: zodResolver(tripSchema),
    defaultValues: {
      destination: trip?.destination || '',
      start_date: trip?.start_date ? new Date(trip.start_date) : new Date(),
      end_date: trip?.end_date ? new Date(trip.end_date) : new Date(),
      budget: trip?.budget ? Number(trip.budget) : undefined,
      accommodation: trip?.accommodation || '',
      transportation: trip?.transportation || '',
      notes: '',
    },
  });

  const onSubmit = async (data: TripFormData) => {
    setIsSubmitting(true);
    
    try {
      const tripData = {
        destination: data.destination,
        start_date: data.start_date.toISOString().split('T')[0],
        end_date: data.end_date.toISOString().split('T')[0],
        budget: data.budget,
        accommodation: data.accommodation,
        transportation: data.transportation,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const result = await createTrip(tripData);
      
      if (result) {
        toast({
          title: "Success",
          description: `Trip to ${data.destination} created successfully!`,
        });
        onSuccess(result as Trip);
      }
    } catch (error) {
      console.error('Error creating trip:', error);
      toast({
        title: "Error",
        description: "Failed to create trip. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onClose}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Trips
        </Button>
        <div>
          <h2 className="text-2xl font-bold">
            {trip ? 'Edit Trip' : 'Create New Trip'}
          </h2>
          <p className="text-muted-foreground">
            {trip ? 'Update your trip details' : 'Plan your next adventure'}
          </p>
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Trip Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="destination">Destination *</Label>
                <Input
                  id="destination"
                  placeholder="e.g., Dubai, UAE"
                  {...form.register('destination')}
                  className={form.formState.errors.destination ? 'border-destructive' : ''}
                />
                {form.formState.errors.destination && (
                  <p className="text-sm text-destructive">{form.formState.errors.destination.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !form.watch('start_date') && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {form.watch('start_date') ? format(form.watch('start_date'), "PPP") : "Pick a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={form.watch('start_date')}
                        onSelect={(date) => date && form.setValue('start_date', date)}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  {form.formState.errors.start_date && (
                    <p className="text-sm text-destructive">{form.formState.errors.start_date.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>End Date *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !form.watch('end_date') && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {form.watch('end_date') ? format(form.watch('end_date'), "PPP") : "Pick a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={form.watch('end_date')}
                        onSelect={(date) => date && form.setValue('end_date', date)}
                        disabled={(date) => date <= form.watch('start_date')}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  {form.formState.errors.end_date && (
                    <p className="text-sm text-destructive">{form.formState.errors.end_date.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="budget">Budget (USD)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="budget"
                    type="number"
                    placeholder="5000"
                    className="pl-10"
                    {...form.register('budget', { valueAsNumber: true })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Logistics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Logistics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="accommodation">Accommodation</Label>
                <Input
                  id="accommodation"
                  placeholder="e.g., Burj Al Arab Hotel"
                  {...form.register('accommodation')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="transportation">Transportation</Label>
                <Select onValueChange={(value) => form.setValue('transportation', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select transportation method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="flight">Flight</SelectItem>
                    <SelectItem value="car">Car</SelectItem>
                    <SelectItem value="train">Train</SelectItem>
                    <SelectItem value="bus">Bus</SelectItem>
                    <SelectItem value="cruise">Cruise</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Additional trip notes, special requirements, etc."
                  className="min-h-[100px]"
                  {...form.register('notes')}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trip Preview */}
        {form.watch('destination') && form.watch('start_date') && form.watch('end_date') && (
          <Card>
            <CardHeader>
              <CardTitle>Trip Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center gap-3">
                  <Plane className="h-8 w-8 text-primary" />
                  <div>
                    <h4 className="font-semibold text-lg">{form.watch('destination')}</h4>
                    <p className="text-sm text-muted-foreground">
                      {format(form.watch('start_date'), "MMM d")} - {format(form.watch('end_date'), "MMM d, yyyy")}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {Math.ceil((form.watch('end_date').getTime() - form.watch('start_date').getTime()) / (1000 * 60 * 60 * 24))} days
                    </p>
                  </div>
                </div>
                {form.watch('budget') && (
                  <div className="text-right">
                    <p className="text-lg font-semibold">${form.watch('budget')?.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Total Budget</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Form Actions */}
        <div className="flex items-center justify-end gap-4">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={isSubmitting || !form.formState.isValid}
            className="min-w-[120px]"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                Creating...
              </>
            ) : (
              <>
                <Plane className="h-4 w-4 mr-2" />
                {trip ? 'Update Trip' : 'Create Trip'}
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default TripForm;