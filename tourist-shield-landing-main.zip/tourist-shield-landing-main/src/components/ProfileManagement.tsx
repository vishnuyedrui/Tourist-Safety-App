import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useTouristData } from '@/hooks/useTouristData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { 
  User, 
  FileText, 
  Phone, 
  Heart, 
  Shield, 
  CalendarIcon, 
  Upload, 
  Edit, 
  Plus, 
  Trash2, 
  Save,
  AlertCircle,
  Check,
  Camera
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/integrations/supabase/client';

const personalInfoSchema = z.object({
  full_name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  nationality: z.string().min(2, 'Please enter your nationality'),
  date_of_birth: z.date().optional(),
  medical_conditions: z.string().optional()
});

const emergencyContactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  relationship: z.string().min(1, 'Please select a relationship'),
  email: z.string().email('Please enter a valid email').optional().or(z.literal(''))
});

export const ProfileManagement = () => {
  const { user } = useAuth();
  const { profile, emergencyContacts, updateProfile, addEmergencyContact, loading, refetch } = useTouristData();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('personal');
  const [editingContact, setEditingContact] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const personalForm = useForm({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      full_name: profile?.full_name || '',
      phone: profile?.phone || '',
      nationality: profile?.nationality || '',
      date_of_birth: profile?.date_of_birth ? new Date(profile.date_of_birth) : undefined,
      medical_conditions: profile?.medical_conditions || ''
    }
  });

  const emergencyForm = useForm({
    resolver: zodResolver(emergencyContactSchema),
    defaultValues: {
      name: '',
      phone: '',
      relationship: '',
      email: ''
    }
  });

  useEffect(() => {
    if (profile) {
      personalForm.reset({
        full_name: profile.full_name || '',
        phone: profile.phone || '',
        nationality: profile.nationality || '',
        date_of_birth: profile.date_of_birth ? new Date(profile.date_of_birth) : undefined,
        medical_conditions: profile.medical_conditions || ''
      });
    }
  }, [profile, personalForm]);

  const onPersonalInfoSubmit = async (data: z.infer<typeof personalInfoSchema>) => {
    try {
      await updateProfile({
        full_name: data.full_name,
        phone: data.phone,
        nationality: data.nationality,
        date_of_birth: data.date_of_birth?.toISOString().split('T')[0],
        medical_conditions: data.medical_conditions || null
      });
      
      toast({
        title: "Profile Updated",
        description: "Your personal information has been updated successfully."
      });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive"
      });
    }
  };

  const onEmergencyContactSubmit = async (data: z.infer<typeof emergencyContactSchema>) => {
    try {
      await addEmergencyContact({
        name: data.name,
        phone: data.phone,
        relationship: data.relationship,
        email: data.email || undefined
      });
      
      emergencyForm.reset();
      toast({
        title: "Emergency Contact Added",
        description: "Emergency contact has been added successfully."
      });
    } catch (error) {
      toast({
        title: "Failed to Add Contact",
        description: "Failed to add emergency contact. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleDocumentUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    setIsUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('kyc-documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('kyc-documents')
        .getPublicUrl(filePath);

      await updateProfile({
        kyc_document_url: publicUrl
      });

      toast({
        title: "Document Uploaded",
        description: "Your document has been uploaded successfully."
      });
      
      refetch();
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload document. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const getCompletionPercentage = () => {
    if (!profile) return 0;
    let completed = 0;
    const fields = ['full_name', 'phone', 'nationality', 'date_of_birth', 'kyc_document_url'];
    
    fields.forEach(field => {
      if (profile[field as keyof typeof profile]) completed++;
    });
    
    if (emergencyContacts.length > 0) completed++;
    
    return Math.round((completed / (fields.length + 1)) * 100);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const completionPercentage = getCompletionPercentage();

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Profile Management
              </CardTitle>
              <CardDescription>
                Manage your personal information, documents, and emergency contacts
              </CardDescription>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-primary">{completionPercentage}%</div>
              <div className="text-sm text-muted-foreground">Complete</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="w-full bg-secondary rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300" 
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          {completionPercentage < 100 && (
            <p className="text-sm text-muted-foreground mt-2">
              Complete your profile to ensure full protection coverage
            </p>
          )}
        </CardContent>
      </Card>

      {/* Profile Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Shield className={`h-8 w-8 ${profile?.kyc_status === 'approved' ? 'text-green-500' : profile?.kyc_status === 'pending' ? 'text-yellow-500' : 'text-red-500'}`} />
              <div>
                <p className="font-medium">KYC Status</p>
                <Badge variant={profile?.kyc_status === 'approved' ? 'default' : 'secondary'} className="mt-1">
                  {profile?.kyc_status || 'Not Started'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Phone className="h-8 w-8 text-blue-500" />
              <div>
                <p className="font-medium">Emergency Contacts</p>
                <p className="text-2xl font-bold text-blue-500">{emergencyContacts.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <FileText className="h-8 w-8 text-purple-500" />
              <div>
                <p className="font-medium">Documents</p>
                <p className="text-sm text-muted-foreground">
                  {profile?.kyc_document_url ? 'Uploaded' : 'Not uploaded'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Blockchain ID Display */}
      {profile?.blockchain_id && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-4 w-4 text-primary" />
              <h3 className="font-medium">Secure Blockchain ID</h3>
            </div>
            <div className="font-mono text-sm bg-muted p-3 rounded border break-all">
              {profile.blockchain_id}
            </div>
            {profile.blockchain_id_expires && (
              <p className="text-xs text-muted-foreground mt-2">
                Valid until: {new Date(profile.blockchain_id_expires).toLocaleDateString()}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Main Profile Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="personal" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Personal
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="emergency" className="flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Emergency
          </TabsTrigger>
          <TabsTrigger value="medical" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            Medical
          </TabsTrigger>
        </TabsList>

        {/* Personal Information Tab */}
        <TabsContent value="personal" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Update your basic personal details</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...personalForm}>
                <form onSubmit={personalForm.handleSubmit(onPersonalInfoSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={personalForm.control}
                      name="full_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={personalForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={personalForm.control}
                      name="nationality"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nationality</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your nationality" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={personalForm.control}
                      name="date_of_birth"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Date of Birth</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant="outline"
                                  className={cn(
                                    "pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                                initialFocus
                                className="p-3 pointer-events-auto"
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button type="submit" className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    Update Personal Information
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Identity Documents</CardTitle>
              <CardDescription>Manage your KYC documents and verification status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {profile?.kyc_document_url ? (
                <div className="border rounded-lg p-4 bg-green-50 dark:bg-green-900/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Check className="h-5 w-5 text-green-600" />
                    <h4 className="font-medium text-green-800 dark:text-green-200">Document Uploaded</h4>
                  </div>
                  <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                    Your {profile.document_name || 'identity document'} has been uploaded and is being reviewed.
                  </p>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" asChild>
                      <a href={profile.kyc_document_url} target="_blank" rel="noopener noreferrer">
                        View Document
                      </a>
                    </Button>
                    <div className="relative">
                      <Button variant="outline" size="sm" disabled={isUploading}>
                        {isUploading ? 'Uploading...' : 'Replace Document'}
                      </Button>
                      <input
                        type="file"
                        className="absolute inset-0 opacity-0 cursor-pointer"
                        accept="image/*,.pdf"
                        onChange={handleDocumentUpload}
                        disabled={isUploading}
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                  <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h4 className="font-medium mb-2">Upload Identity Document</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Upload a clear photo of your passport, ID card, or other government-issued ID
                  </p>
                  <div className="relative">
                    <Button disabled={isUploading} className="flex items-center gap-2">
                      {isUploading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Camera className="h-4 w-4" />
                          Choose File
                        </>
                      )}
                    </Button>
                    <input
                      type="file"
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      accept="image/*,.pdf"
                      onChange={handleDocumentUpload}
                      disabled={isUploading}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">PNG, JPG, PDF up to 10MB</p>
                </div>
              )}
              
              {profile?.document_number && (
                <div className="bg-muted/50 rounded-lg p-4">
                  <h4 className="font-medium mb-2">Document Information</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Document Type</p>
                      <p className="font-medium capitalize">{profile.document_name?.replace('_', ' ')}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Document Number</p>
                      <p className="font-medium">{profile.document_number}</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Emergency Contacts Tab */}
        <TabsContent value="emergency" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Emergency Contacts</CardTitle>
              <CardDescription>Manage your emergency contact information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {emergencyContacts.length > 0 && (
                <div className="space-y-3">
                  {emergencyContacts.map((contact) => (
                    <div key={contact.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{contact.name}</h4>
                        <Badge variant="outline">{contact.relationship}</Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                        <div className="flex items-center gap-2">
                          <Phone className="h-3 w-3 text-muted-foreground" />
                          <span>{contact.phone}</span>
                        </div>
                        {contact.email && (
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground">✉</span>
                            <span>{contact.email}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Add Emergency Contact</CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...emergencyForm}>
                    <form onSubmit={emergencyForm.handleSubmit(onEmergencyContactSubmit)} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={emergencyForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Contact Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter contact name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={emergencyForm.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter phone number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={emergencyForm.control}
                          name="relationship"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Relationship</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select relationship" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="parent">Parent</SelectItem>
                                  <SelectItem value="spouse">Spouse</SelectItem>
                                  <SelectItem value="sibling">Sibling</SelectItem>
                                  <SelectItem value="friend">Friend</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={emergencyForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email (Optional)</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="Enter email address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <Button type="submit" className="flex items-center gap-2">
                        <Plus className="h-4 w-4" />
                        Add Emergency Contact
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Medical Information Tab */}
        <TabsContent value="medical" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Medical Information</CardTitle>
              <CardDescription>
                Share important medical conditions and allergies for emergency situations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    This information will be shared with emergency responders if you activate a panic alert.
                  </AlertDescription>
                </Alert>
                
                <div>
                  <Label htmlFor="medical_conditions">Medical Conditions & Allergies</Label>
                  <Textarea
                    id="medical_conditions"
                    value={personalForm.watch('medical_conditions') || ''}
                    onChange={(e) => personalForm.setValue('medical_conditions', e.target.value)}
                    placeholder="List any medical conditions, allergies, medications, or other important medical information..."
                    rows={6}
                    className="mt-2"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Include details like diabetes, heart conditions, allergies to medications or food, blood type, etc.
                  </p>
                </div>
                
                <Button 
                  onClick={() => onPersonalInfoSubmit(personalForm.getValues())}
                  className="flex items-center gap-2"
                >
                  <Save className="h-4 w-4" />
                  Save Medical Information
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};