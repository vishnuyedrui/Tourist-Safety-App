import { Shield, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer id="contact" className="bg-primary text-primary-foreground py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Shield className="w-8 h-8" />
              <h3 className="text-2xl font-heading font-bold">Tourist Shield</h3>
            </div>
            <p className="text-primary-foreground/80 mb-4">
              Your trusted partner for safe and secure travel experiences worldwide.
            </p>
          </div>
          
          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Travel Insurance</a></li>
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Emergency Assistance</a></li>
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Medical Coverage</a></li>
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Crisis Management</a></li>
            </ul>
          </div>
          
          {/* Company */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">About Us</a></li>
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Careers</a></li>
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Press</a></li>
              <li><a href="#" className="hover:text-primary-foreground transition-smooth">Partners</a></li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <div className="space-y-3 text-primary-foreground/80">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>help@touristshield.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4" />
                <span>24/7 Emergency Hotline</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center text-primary-foreground/60">
          <p>&copy; 2024 Tourist Shield. All rights reserved. Your safety is our commitment.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;