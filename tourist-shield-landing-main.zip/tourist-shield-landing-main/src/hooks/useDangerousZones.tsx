import { useState, useCallback, useEffect } from 'react';

interface DangerousZone {
  id: string;
  name: string;
  zone_type: string;
  risk_level: 'critical' | 'high' | 'medium' | 'low';
  geometry: {
    type: 'Polygon';
    coordinates: number[][][];
  };
  alert_message?: string;
  description?: string;
}

export interface GeofenceAlert {
  zone: DangerousZone;
  distance: number;
  isInside: boolean;
}

export const useDangerousZones = (
  currentLat?: number,
  currentLng?: number,
  onAlert?: (alert: GeofenceAlert) => void
) => {
  const [zones, setZones] = useState<DangerousZone[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Mock dangerous zones data
  const mockZones: DangerousZone[] = [
    {
      id: '1',
      name: 'High Crime Area',
      zone_type: 'crime',
      risk_level: 'high',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [77.5930, 12.9700],
          [77.5950, 12.9700],
          [77.5950, 12.9720],
          [77.5930, 12.9720],
          [77.5930, 12.9700]
        ]]
      },
      alert_message: 'Avoid this area, especially at night',
      description: 'Area with reported incidents of theft and harassment'
    },
    {
      id: '2',
      name: 'Construction Zone',
      zone_type: 'infrastructure',
      risk_level: 'medium',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [77.5910, 12.9710],
          [77.5920, 12.9710],
          [77.5920, 12.9715],
          [77.5910, 12.9715],
          [77.5910, 12.9710]
        ]]
      },
      alert_message: 'Active construction work - use alternate routes',
      description: 'Major construction project with heavy machinery'
    }
  ];

  useEffect(() => {
    setZones(mockZones);
  }, []);

  const checkGeofence = useCallback((lat: number, lng: number) => {
    zones.forEach(zone => {
      if (!zone.geometry?.coordinates?.[0]) return;

      // Simple point-in-polygon check (basic implementation)
      const coords = zone.geometry.coordinates[0];
      let inside = false;
      
      for (let i = 0, j = coords.length - 1; i < coords.length; j = i++) {
        if (((coords[i][1] > lng) !== (coords[j][1] > lng)) &&
            (lat < (coords[j][0] - coords[i][0]) * (lng - coords[i][1]) / (coords[j][1] - coords[i][1]) + coords[i][0])) {
          inside = !inside;
        }
      }

      if (inside && onAlert) {
        onAlert({
          zone,
          distance: 0,
          isInside: true
        });
      }
    });
  }, [zones, onAlert]);

  const fetchZones = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      setZones(mockZones);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch zones');
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    zones,
    loading,
    error,
    checkGeofence,
    fetchZones,
  };
};