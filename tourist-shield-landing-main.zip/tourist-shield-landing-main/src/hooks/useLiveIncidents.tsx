import { useState, useCallback } from 'react';

interface LiveIncident {
  id: string;
  latitude: number;
  longitude: number;
  title: string;
  description?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  incident_type: string;
  created_at: string;
}

export const useLiveIncidents = (autoFetch: boolean = false) => {
  const [incidents, setIncidents] = useState<LiveIncident[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchIncidents = useCallback(async (lat?: number, lng?: number) => {
    setLoading(true);
    setError(null);

    try {
      // Mock data for now - replace with actual API call
      const mockIncidents: LiveIncident[] = [
        {
          id: '1',
          latitude: 12.9720,
          longitude: 77.5940,
          title: 'Traffic Accident',
          description: 'Multi-vehicle collision reported',
          severity: 'high',
          incident_type: 'traffic',
          created_at: new Date().toISOString(),
        },
        {
          id: '2',
          latitude: 12.9700,
          longitude: 77.5955,
          title: 'Road Closure',
          description: 'Construction work in progress',
          severity: 'medium',
          incident_type: 'infrastructure',
          created_at: new Date().toISOString(),
        },
      ];

      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setIncidents(mockIncidents);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch incidents');
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    incidents,
    loading,
    error,
    fetchIncidents,
  };
};