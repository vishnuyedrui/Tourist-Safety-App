import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

export interface TouristProfile {
  id: string;
  user_id: string;
  full_name: string;
  phone?: string;
  date_of_birth?: string;
  nationality?: string;
  passport_number?: string;
  kyc_status: string;
  kyc_document_url?: string;
  blockchain_id?: string;
  blockchain_id_expires?: string;
  emergency_contact?: string;
  trip_itenary?: string;
  trip_itenary_url?: string;
  document_url?: string;
  document_name?: string;
  document_number?: string;
  medical_conditions?: string;
  registration_status?: string;
  created_at: string;
}

export interface EmergencyContact {
  id: string;
  tourist_id: string;
  name: string;
  relationship: string;
  phone: string;
  email?: string;
}

export interface Trip {
  id: string;
  tourist_id: string;
  destination: string;
  start_date: string;
  end_date: string;
  status: string;
  current_location_lat?: number;
  current_location_lng?: number;
  last_check_in?: string;
  itinerary?: any;
  budget?: number;
  accommodation?: string;
  transportation?: string;
  created_at: string;
  updated_at: string;
}

export const useTouristData = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<TouristProfile | null>(null);
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([]);
  const [trips, setTrips] = useState<Trip[]>([]);

  const fetchProfile = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('tourists')
        .select('*')
        .eq('user_id', user.id)
        .order('registration_status', { ascending: false }) // 'complete' comes before 'incomplete'
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) throw error;
      setProfile(data?.[0] || null);
    } catch (error: any) {
      console.error('Error fetching profile:', error);
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive",
      });
    }
  };

  const fetchEmergencyContacts = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('emergency_contacts')
        .select('*')
        .eq('tourist_id', profile.id);

      if (error) throw error;
      setEmergencyContacts(data || []);
    } catch (error: any) {
      console.error('Error fetching emergency contacts:', error);
    }
  };

  const fetchTrips = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('trips')
        .select('*')
        .eq('tourist_id', profile.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTrips(data || []);
    } catch (error: any) {
      console.error('Error fetching trips:', error);
    }
  };

  const createOrUpdateTouristProfile = async (profileData: any) => {
    if (!user) return null;

    try {
      // First check if an incomplete profile exists
      const { data: existingProfiles, error: fetchError } = await supabase
        .from('tourists')
        .select('*')
        .eq('user_id', user.id)
        .eq('registration_status', 'incomplete');

      if (fetchError) throw fetchError;

      let result;
      
      if (existingProfiles && existingProfiles.length > 0) {
        // Update existing incomplete profile
        const { data, error } = await supabase
          .from('tourists')
          .update({
            full_name: profileData.full_name || '',
            registration_status: 'complete',
            ...profileData
          })
          .eq('id', existingProfiles[0].id)
          .select()
          .single();

        if (error) throw error;
        result = data;
      } else {
        // Create new profile
        const { data, error } = await supabase
          .from('tourists')
          .insert({
            user_id: user.id,
            full_name: profileData.full_name || '',
            registration_status: 'complete',
            ...profileData
          })
          .select()
          .single();

        if (error) throw error;
        result = data;
      }

      setProfile(result as TouristProfile);
      return result;
    } catch (error: any) {
      console.error('Error creating/updating profile:', error);
      toast({
        title: "Error",
        description: "Failed to create profile",
        variant: "destructive",
      });
      return null;
    }
  };

  const createTouristProfile = createOrUpdateTouristProfile;

  const updateProfile = async (updates: Partial<TouristProfile>) => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('tourists')
        .update(updates)
        .eq('id', profile.id)
        .select()
        .single();

      if (error) throw error;
      setProfile(data as TouristProfile);
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
    } catch (error: any) {
      console.error('Error updating profile:', error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    }
  };

  const addEmergencyContact = async (contact: Omit<EmergencyContact, 'id' | 'tourist_id'>) => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('emergency_contacts')
        .insert({
          tourist_id: profile.id,
          ...contact
        })
        .select()
        .single();

      if (error) throw error;
      setEmergencyContacts(prev => [...prev, data]);
      toast({
        title: "Success",
        description: "Emergency contact added",
      });
    } catch (error: any) {
      console.error('Error adding emergency contact:', error);
      toast({
        title: "Error",
        description: "Failed to add emergency contact",
        variant: "destructive",
      });
    }
  };

  const createTrip = async (tripData: Omit<Trip, 'id' | 'tourist_id' | 'status'>) => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('trips')
        .insert({
          tourist_id: profile.id,
          status: 'planned',
          ...tripData
        })
        .select()
        .single();

      if (error) throw error;
      setTrips(prev => [data as Trip, ...prev]);
      toast({
        title: "Success",
        description: "Trip created successfully",
      });
      return data;
    } catch (error: any) {
      console.error('Error creating trip:', error);
      toast({
        title: "Error",
        description: "Failed to create trip",
        variant: "destructive",
      });
      return null;
    }
  };

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  useEffect(() => {
    if (profile) {
      fetchEmergencyContacts();
      fetchTrips();
    }
    setLoading(false);
  }, [profile]);

  return {
    loading,
    profile,
    emergencyContacts,
    trips,
    createTouristProfile,
    createOrUpdateTouristProfile,
    updateProfile,
    addEmergencyContact,
    createTrip,
    refetch: fetchProfile
  };
};