import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useTouristData } from '@/hooks/useTouristData';

interface Location {
  latitude: number;
  longitude: number;
  accuracy?: number;
}

interface PanicAlertData {
  location?: Location;
  message?: string;
  alertType?: string;
  touristProfile?: {
    id: string;
    full_name: string;
    phone?: string;
    nationality?: string;
    passport_number?: string;
    date_of_birth?: string;
    medical_conditions?: string;
    kyc_status?: string;
    document_url?: string;
  };
  emergencyContacts?: {
    name: string;
    phone: string;
    email?: string;
    relationship: string;
  }[];
  currentTrip?: {
    id: string;
    destination: string;
    start_date: string;
    end_date: string;
    accommodation?: string;
    transportation?: string;
    status: string;
    last_check_in?: string;
  };
}

export const usePanicAlert = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const { toast } = useToast();
  const { profile, emergencyContacts, trips } = useTouristData();

  const getCurrentLocation = (): Promise<Location> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      setIsGettingLocation(true);

      navigator.geolocation.getCurrentPosition(
        (position) => {
          setIsGettingLocation(false);
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
          });
        },
        (error) => {
          setIsGettingLocation(false);
          console.error('Error getting location:', error);
          reject(new Error(`Location error: ${error.message}`));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000, // 1 minute cache
        }
      );
    });
  };

  const sendPanicAlert = async (data?: Partial<PanicAlertData>) => {
    setIsLoading(true);

    try {
      // Try to get current location
      let location: Location | undefined;
      
      try {
        location = await getCurrentLocation();
        console.log('Location captured:', location);
      } catch (locationError) {
        console.warn('Could not get location:', locationError);
        // Continue without location - emergency is more important
      }

      // Get current active trip
      const currentTrip = trips?.find(trip => trip.status === 'active') || trips?.[0];

      // Prepare comprehensive alert data with full tourist profile
      const alertData: PanicAlertData = {
        location,
        message: data?.message || 'Emergency assistance required - panic button activated',
        alertType: data?.alertType || 'panic',
        // Include comprehensive tourist profile data
        touristProfile: profile ? {
          id: profile.id,
          full_name: profile.full_name,
          phone: profile.phone,
          nationality: profile.nationality,
          passport_number: profile.passport_number,
          date_of_birth: profile.date_of_birth,
          medical_conditions: profile.medical_conditions,
          kyc_status: profile.kyc_status,
          document_url: profile.document_url,
        } : undefined,
        // Include emergency contacts
        emergencyContacts: emergencyContacts?.map(contact => ({
          name: contact.name,
          phone: contact.phone,
          email: contact.email,
          relationship: contact.relationship,
        })) || [],
        // Include current trip information
        currentTrip: currentTrip ? {
          id: currentTrip.id,
          destination: currentTrip.destination,
          start_date: currentTrip.start_date,
          end_date: currentTrip.end_date,
          accommodation: currentTrip.accommodation,
          transportation: currentTrip.transportation,
          status: currentTrip.status,
          last_check_in: currentTrip.last_check_in,
        } : undefined,
        ...data,
      };

      console.log('Sending panic alert:', alertData);

      // Call panic alert edge function
      const { data: response, error } = await supabase.functions.invoke('panic-alert', {
        body: alertData,
      });

      if (error) {
        console.error('Panic alert error:', error);
        throw new Error(error.message || 'Failed to send panic alert');
      }

      console.log('Panic alert response:', response);

      // Show success message with enhanced details
      const profileIncluded = profile ? 'Profile data included.' : 'No profile data.';
      const contactsIncluded = emergencyContacts && emergencyContacts.length > 0 ? `${emergencyContacts.length} emergency contacts included.` : 'No emergency contacts.';
      const tripIncluded = currentTrip ? 'Current trip details included.' : 'No active trip.';
      
      toast({
        title: "🚨 EMERGENCY ALERT SENT",
        description: `Alert sent successfully! ${response?.authorities_notified || 0} authorities notified. ${location ? 'Location included.' : 'No location available.'} ${profileIncluded} ${contactsIncluded} ${tripIncluded}`,
        duration: 10000,
      });

      return {
        success: true,
        alertId: response?.alert_id,
        authoritiesNotified: response?.authorities_notified || 0,
        locationCaptured: !!location,
      };

    } catch (error: any) {
      console.error('Error sending panic alert:', error);
      
      toast({
        title: "Alert Error",
        description: `Failed to send emergency alert: ${error.message}. Please call local emergency services directly.`,
        variant: "destructive",
        duration: 10000,
      });

      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    sendPanicAlert,
    isLoading,
    isGettingLocation,
    getCurrentLocation,
  };
};