/**
 * Blockchain ID Generation Utility
 * Generates secure, time-bound blockchain IDs for tourist registration
 */

interface BlockchainIdData {
  id: string;
  timestamp: number;
  hash: string;
  validity: {
    startDate: string;
    endDate: string;
  };
}

/**
 * Generates a random secure token
 */
function generateSecureToken(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Generates a blockchain ID with embedded validity period
 */
export const generateBlockchainId = (
  startDate?: Date, 
  endDate?: Date
): string => {
  const timestamp = Date.now();
  const random1 = Math.random().toString(36).substring(2, 10).toUpperCase();
  const random2 = Math.random().toString(36).substring(2, 10).toUpperCase();
  
  return `TRIP-${random1}-${timestamp}-${random2}`;
};

/**
 * Validates blockchain ID format
 */
export const validateBlockchainId = (blockchainId: string): boolean => {
  const blockchainIdPattern = /^TRIP-[A-F0-9]{8}-\d{13}-[A-F0-9]{8}$/;
  return blockchainIdPattern.test(blockchainId);
};

/**
 * Extracts timestamp from blockchain ID
 */
export const extractTimestampFromBlockchainId = (blockchainId: string): number | null => {
  try {
    const parts = blockchainId.split('-');
    if (parts.length >= 3) {
      return parseInt(parts[2]);
    }
    return null;
  } catch (error) {
    return null;
  }
};

/**
 * Checks if blockchain ID is still valid based on current date and trip dates
 */
export const isBlockchainIdValid = (
  blockchainId: string, 
  startDate: Date, 
  endDate: Date
): boolean => {
  const now = new Date();
  const isInTripPeriod = now >= startDate && now <= endDate;
  const isValidFormat = validateBlockchainId(blockchainId);
  
  return isValidFormat && isInTripPeriod;
};