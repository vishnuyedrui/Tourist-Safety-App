import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface RegistrationConfirmationRequest {
  email: string;
  name: string;
  blockchain_id: string;
  trip_dates: {
    start: string;
    end: string;
  };
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, name, blockchain_id, trip_dates }: RegistrationConfirmationRequest = await req.json();

    console.log('Sending registration confirmation to:', email);

    const formatDate = (dateString: string) => {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    };

    const emailResponse = await resend.emails.send({
      from: "TripShield <noreply@resend.dev>",
      to: [email],
      subject: "🎉 Welcome to TripShield - Registration Complete!",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
          <div style="background-color: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            
            <!-- Header -->
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #1f2937; margin: 0; font-size: 28px;">🛡️ TripShield</h1>
              <p style="color: #6b7280; margin: 10px 0 0 0;">Your Safety, Our Priority</p>
            </div>

            <!-- Welcome Message -->
            <div style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); color: white; padding: 25px; border-radius: 8px; text-align: center; margin-bottom: 30px;">
              <h2 style="margin: 0 0 10px 0; font-size: 24px;">🎉 Registration Complete!</h2>
              <p style="margin: 0; font-size: 16px; opacity: 0.9;">Welcome to TripShield, ${name}!</p>
            </div>

            <!-- Blockchain ID Section -->
            <div style="background-color: #f0f9ff; border: 1px solid #0ea5e9; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
              <h3 style="color: #0c4a6e; margin: 0 0 15px 0; font-size: 18px;">🔐 Your Secure Blockchain ID</h3>
              <div style="background-color: white; padding: 15px; border-radius: 6px; border: 2px dashed #0ea5e9;">
                <code style="font-size: 16px; font-weight: bold; color: #1e40af; letter-spacing: 1px;">${blockchain_id}</code>
              </div>
              <p style="margin: 15px 0 0 0; font-size: 14px; color: #374151;">
                <strong>Validity Period:</strong> ${formatDate(trip_dates.start)} to ${formatDate(trip_dates.end)}
              </p>
            </div>

            <!-- Trip Details -->
            <div style="background-color: #f0fdf4; border: 1px solid #22c55e; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
              <h3 style="color: #15803d; margin: 0 0 15px 0; font-size: 18px;">✈️ Your Trip Details</h3>
              <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
                <div style="margin-bottom: 10px;">
                  <strong style="color: #374151;">Start Date:</strong><br>
                  <span style="color: #15803d; font-size: 16px;">${formatDate(trip_dates.start)}</span>
                </div>
                <div style="margin-bottom: 10px;">
                  <strong style="color: #374151;">End Date:</strong><br>
                  <span style="color: #15803d; font-size: 16px;">${formatDate(trip_dates.end)}</span>
                </div>
              </div>
            </div>

            <!-- What's Next -->
            <div style="background-color: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
              <h3 style="color: #92400e; margin: 0 0 15px 0; font-size: 18px;">🚀 What's Next?</h3>
              <ul style="margin: 0; padding-left: 20px; color: #374151;">
                <li style="margin-bottom: 8px;">Your KYC documents are being reviewed by our team</li>
                <li style="margin-bottom: 8px;">You'll receive an update within 24-48 hours</li>
                <li style="margin-bottom: 8px;">Start planning your trip with our itinerary builder</li>
                <li style="margin-bottom: 8px;">Set up your emergency contacts and safety preferences</li>
              </ul>
            </div>

            <!-- Security Features -->
            <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
              <h3 style="color: #374151; margin: 0 0 15px 0; font-size: 18px;">🛡️ Your Security Features</h3>
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <div>
                  <strong style="color: #1f2937;">📍 Real-time Tracking</strong>
                  <p style="margin: 5px 0 0 0; font-size: 14px; color: #6b7280;">GPS location monitoring for your safety</p>
                </div>
                <div>
                  <strong style="color: #1f2937;">🚨 Emergency Alerts</strong>
                  <p style="margin: 5px 0 0 0; font-size: 14px; color: #6b7280;">Instant notifications to authorities</p>
                </div>
                <div>
                  <strong style="color: #1f2937;">🔐 Blockchain Security</strong>
                  <p style="margin: 5px 0 0 0; font-size: 14px; color: #6b7280;">Tamper-proof identity verification</p>
                </div>
                <div>
                  <strong style="color: #1f2937;">👥 Emergency Contacts</strong>
                  <p style="margin: 5px 0 0 0; font-size: 14px; color: #6b7280;">Automated notifications to your contacts</p>
                </div>
              </div>
            </div>

            <!-- Support -->
            <div style="text-align: center; color: #6b7280; font-size: 14px;">
              <p style="margin: 0 0 10px 0;">Need help? Contact our support team</p>
              <p style="margin: 0;">
                📧 support@tripshield.com | 📞 1-800-TRIPSHIELD
              </p>
            </div>

            <!-- Footer -->
            <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
              <p style="color: #9ca3af; font-size: 12px; margin: 0;">
                © 2024 TripShield. All rights reserved.<br>
                Your safety is our priority. Travel smart, travel secure.
              </p>
            </div>
          </div>
        </div>
      `,
    });

    console.log("Registration confirmation email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-registration-confirmation function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);