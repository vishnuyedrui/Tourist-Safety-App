import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface LocationUpdate {
  latitude: number;
  longitude: number;
  timestamp?: string;
  accuracy?: number;
}

interface GeofenceCheck {
  id: string;
  name: string;
  geometry: any; // GeoJSON geometry
  risk_level: 'safe' | 'caution' | 'restricted';
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get user from auth header
    const authHeader = req.headers.get('Authorization')!;
    const supabaseUser = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!);
    const { data: { user }, error: authError } = await supabaseUser.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { latitude, longitude, timestamp, accuracy }: LocationUpdate = await req.json();

    console.log(`Location update from user ${user.id}: ${latitude}, ${longitude}`);

    // Get user's tourist profile
    const { data: touristProfile, error: profileError } = await supabase
      .from('tourists')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle();

    if (!touristProfile) {
      throw new Error('Tourist profile not found');
    }

    // Update current location in active trip
    const { data: activeTrip, error: tripError } = await supabase
      .from('trips')
      .select('id')
      .eq('tourist_id', touristProfile.id)
      .eq('status', 'active')
      .maybeSingle();

    if (activeTrip) {
      await supabase
        .from('trips')
        .update({
          current_location_lat: latitude,
          current_location_lng: longitude,
          last_check_in: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', activeTrip.id);
    }

    // Check geofences
    const { data: geofences, error: geofenceError } = await supabase
      .from('geofences')
      .select('*')
      .eq('active', true);

    const violations = [];
    
    if (geofences) {
      for (const geofence of geofences) {
        const isInside = checkPointInGeofence(latitude, longitude, geofence.geometry);
        
        if (isInside && geofence.risk_level === 'restricted') {
          // Log violation
          const { error: violationError } = await supabase
            .from('geofence_violations')
            .insert({
              tourist_id: touristProfile.id,
              geofence_id: geofence.id,
              location_lat: latitude,
              location_lng: longitude,
              violation_type: 'entry_restricted'
            });

          if (!violationError) {
            violations.push({
              type: 'restricted_area',
              geofence_name: geofence.name,
              risk_level: geofence.risk_level
            });

            // Create alert
            await supabase
              .from('alerts')
              .insert({
                tourist_id: touristProfile.id,
                alert_type: 'geofence_violation',
                title: `Restricted Area Entry`,
                description: `Tourist entered restricted area: ${geofence.name}`,
                location_lat: latitude,
                location_lng: longitude,
                priority: 'high',
                status: 'active'
              });

            console.log(`Geofence violation detected: ${geofence.name}`);
          }
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Location updated successfully',
        violations: violations,
        location: { latitude, longitude, timestamp }
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    );

  } catch (error) {
    console.error('Location tracking error:', error);
    return new Response(
      JSON.stringify({
        error: error.message,
        success: false
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    );
  }
});

// Simple point-in-polygon check for GeoJSON geometry
function checkPointInGeofence(lat: number, lng: number, geometry: any): boolean {
  if (geometry.type === 'Polygon') {
    return pointInPolygon([lng, lat], geometry.coordinates[0]);
  } else if (geometry.type === 'Circle') {
    // Handle circle geometry (custom format)
    const center = geometry.center; // [lng, lat]
    const radius = geometry.radius; // in meters
    const distance = calculateDistance(lat, lng, center[1], center[0]);
    return distance <= radius;
  }
  return false;
}

// Ray casting algorithm for point-in-polygon
function pointInPolygon(point: number[], polygon: number[][]): boolean {
  const x = point[0], y = point[1];
  let inside = false;
  
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i][0], yi = polygon[i][1];
    const xj = polygon[j][0], yj = polygon[j][1];
    
    if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) {
      inside = !inside;
    }
  }
  
  return inside;
}

// Haversine formula for distance calculation
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c;
}