import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PanicAlertRequest {
  location?: {
    latitude: number;
    longitude: number;
    accuracy?: number;
  };
  message?: string;
  alertType?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Create Supabase client with service role key for admin operations
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    // Create client with user's JWT for user operations
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header provided');
    }

    const supabaseUser = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      },
      global: {
        headers: {
          Authorization: authHeader,
        },
      },
    });

    // Get user from JWT
    const { data: { user }, error: userError } = await supabaseUser.auth.getUser();
    if (userError || !user) {
      console.error('Error getting user:', userError);
      throw new Error('Unauthorized: Invalid user token');
    }

    console.log('Panic alert received from user:', user.id);

    // Get request data
    const { location, message, alertType = 'panic' }: PanicAlertRequest = await req.json();

    // Get user's tourist profile
    // Get user's tourist profile (robust to duplicates)
    const { data: touristProfileMaybe, error: profileError } = await supabaseUser
      .from('tourists')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    let touristProfile = touristProfileMaybe;
    if (!touristProfile) {
      // Fallback: if multiple or none, pick most recent via admin client
      const { data: fallbackProfiles, error: fallbackErr } = await supabaseAdmin
        .from('tourists')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1);
      if (fallbackErr) {
        console.error('Error fetching tourist profile (fallback):', fallbackErr);
      }
      touristProfile = (fallbackProfiles && fallbackProfiles[0]) || null;
    }

    if (!touristProfile) {
      console.error('No tourist profile found for user:', user.id, 'original error:', profileError);
      throw new Error('No tourist profile found. Please complete registration before sending alerts.');
    }

    console.log('Tourist profile found:', touristProfile.full_name);

    // Prepare alert data
    const alertData = {
      tourist_id: touristProfile.id,
      title: `EMERGENCY: Panic Alert from ${touristProfile.full_name}`,
      description: message || `Emergency panic button pressed by ${touristProfile.full_name}. Immediate assistance required.`,
      alert_type: alertType,
      priority: 'critical',
      status: 'active',
      location_lat: location?.latitude || null,
      location_lng: location?.longitude || null,
      location_address: null, // Will be resolved by geocoding if needed
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    console.log('Creating alert with data:', alertData);

    // Create alert using admin client to bypass RLS
    const { data: alert, error: alertError } = await supabaseAdmin
      .from('alerts')
      .insert(alertData)
      .select()
      .single();

    if (alertError) {
      console.error('Error creating alert:', alertError);
      throw new Error(`Failed to create alert: ${alertError.message}`);
    }

    console.log('Alert created successfully:', alert.id);

    // Get emergency contacts for comprehensive alert data
    const { data: emergencyContacts } = await supabaseUser
      .from('emergency_contacts')
      .select('*')
      .eq('tourist_id', touristProfile.id);

    // Prepare comprehensive alert data for TripShield Authority Nexus
    const externalAlertData = {
      alertId: alert.id,
      touristInfo: {
        id: touristProfile.id,
        name: touristProfile.full_name,
        phone: touristProfile.phone,
        nationality: touristProfile.nationality,
        userId: touristProfile.user_id,
        kycStatus: touristProfile.kyc_status
      },
      alert: {
        type: alertType,
        priority: 'critical',
        message: message || `Emergency panic button pressed by ${touristProfile.full_name}. Immediate assistance required.`,
        timestamp: new Date().toISOString()
      },
      location: location ? {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy
      } : null,
      emergencyContacts: emergencyContacts || []
    };

    // Send alert to TripShield Authority Nexus website
    try {
      console.log('Sending alert to Authority Nexus website...');
      const nexusResponse = await fetch('https://lovable.dev/projects/bd60aae2-091c-4e6d-8a0b-446121b1b2fd/api/external-alerts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Alert-Source': 'tripshield-tourist-app',
          'X-Alert-ID': alert.id
        },
        body: JSON.stringify(externalAlertData)
      });

      if (nexusResponse.ok) {
        const nexusResult = await nexusResponse.json();
        console.log('Successfully sent alert to Authority Nexus:', nexusResult);
      } else {
        console.warn('Authority Nexus notification failed:', nexusResponse.status, await nexusResponse.text());
      }
    } catch (nexusError) {
      console.error('Failed to notify Authority Nexus:', nexusError);
      // Continue execution - local alert is still created and authorities will be notified locally
    }

    // Update user's current trip location if available
    if (location && touristProfile.id) {
      const { error: tripUpdateError } = await supabaseUser
        .from('trips')
        .update({
          current_location_lat: location.latitude,
          current_location_lng: location.longitude,
          last_check_in: new Date().toISOString()
        })
        .eq('tourist_id', touristProfile.id)
        .eq('status', 'active');

      if (tripUpdateError) {
        console.warn('Could not update trip location:', tripUpdateError);
        // Don't fail the alert for this
      }
    }

    // Get all active authorities for notification
    const { data: authorities, error: authError } = await supabaseAdmin
      .from('authorities')
      .select('id, full_name, organization, user_id')
      .eq('status', 'active');

    if (authError) {
      console.warn('Could not fetch authorities:', authError);
    } else {
      console.log(`Found ${authorities?.length || 0} active authorities to notify`);
    }

    // Log the emergency alert for authorities
    if (authorities && authorities.length > 0) {
      const alertLogs = authorities.map(authority => ({
        alert_id: alert.id,
        authority_id: authority.id,
        action: 'alert_received',
        notes: `Emergency alert received from ${touristProfile.full_name}. Location: ${location ? `${location.latitude}, ${location.longitude}` : 'Unknown'}`,
        created_at: new Date().toISOString()
      }));

      const { error: logError } = await supabaseAdmin
        .from('alert_logs')
        .insert(alertLogs);

      if (logError) {
        console.warn('Could not create alert logs:', logError);
      } else {
        console.log('Alert logs created for authorities');
      }
    }

    // Prepare response
    const response = {
      success: true,
      alert_id: alert.id,
      message: 'Emergency alert sent successfully',
      authorities_notified: authorities?.length || 0,
      location_captured: !!location,
      timestamp: new Date().toISOString()
    };

    console.log('Panic alert processed successfully:', response);

    return new Response(JSON.stringify(response), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error('Error in panic-alert function:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error.message || 'Internal server error',
        timestamp: new Date().toISOString()
      }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }
};

serve(handler);