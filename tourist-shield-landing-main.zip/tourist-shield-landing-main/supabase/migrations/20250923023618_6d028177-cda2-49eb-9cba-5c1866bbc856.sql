-- Fix RLS policies for geofence_violations table to ensure proper access control
-- while allowing the system to insert violations and authorities to manage them

-- Add INSERT policy for authorities and system operations
CREATE POLICY "Authorities and system can insert geofence violations" 
ON public.geofence_violations 
FOR INSERT 
WITH CHECK (
  -- Allow authorities to insert violations
  EXISTS (
    SELECT 1 FROM authorities 
    WHERE authorities.user_id = auth.uid()
  )
  OR
  -- Allow service role (for edge functions) to insert violations
  auth.role() = 'service_role'
);

-- Add UPDATE policy for authorities
CREATE POLICY "Authorities can update geofence violations" 
ON public.geofence_violations 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM authorities 
    WHERE authorities.user_id = auth.uid()
  )
);

-- Add DELETE policy for authorities (for data cleanup)
CREATE POLICY "Authorities can delete geofence violations" 
ON public.geofence_violations 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM authorities 
    WHERE authorities.user_id = auth.uid()
  )
);