-- Add missing medical_conditions field to tourists table
ALTER TABLE public.tourists 
ADD COLUMN IF NOT EXISTS medical_conditions TEXT;

-- Add blockchain_id_expires field for time-bound validity
ALTER TABLE public.tourists 
ADD COLUMN IF NOT EXISTS blockchain_id_expires TIMESTAMP WITH TIME ZONE;

-- Add registration_status field to track completion
ALTER TABLE public.tourists 
ADD COLUMN IF NOT EXISTS registration_status TEXT DEFAULT 'incomplete';

-- Add document_name and document_number fields for KYC
ALTER TABLE public.tourists 
ADD COLUMN IF NOT EXISTS document_name TEXT,
ADD COLUMN IF NOT EXISTS document_number TEXT;