-- Extend tourists table for enhanced registration
ALTER TABLE public.tourists 
ADD COLUMN IF NOT EXISTS phone TEXT,
ADD COLUMN IF NOT EXISTS date_of_birth DATE,
ADD COLUMN IF NOT EXISTS nationality TEXT,
ADD COLUMN IF NOT EXISTS passport_number TEXT,
ADD COLUMN IF NOT EXISTS kyc_status TEXT DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS kyc_document_url TEXT,
ADD COLUMN IF NOT EXISTS blockchain_id TEXT,
ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id);

-- Create emergency_contacts table
CREATE TABLE IF NOT EXISTS public.emergency_contacts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tourist_id UUID NOT NULL REFERENCES public.tourists(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  relationship TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create trips table extensions
ALTER TABLE public.trips 
ADD COLUMN IF NOT EXISTS itinerary JSONB DEFAULT '[]',
ADD COLUMN IF NOT EXISTS budget NUMERIC,
ADD COLUMN IF NOT EXISTS accommodation TEXT,
ADD COLUMN IF NOT EXISTS transportation TEXT;

-- Create itinerary_items table for detailed trip planning
CREATE TABLE IF NOT EXISTS public.itinerary_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  day_number INTEGER NOT NULL,
  location TEXT NOT NULL,
  activity TEXT NOT NULL,
  time_start TIME,
  time_end TIME,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on new tables
ALTER TABLE public.emergency_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_items ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for emergency_contacts
CREATE POLICY "Users can view their own emergency contacts" 
ON public.emergency_contacts 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.tourists 
  WHERE tourists.id = emergency_contacts.tourist_id 
  AND tourists.user_id = auth.uid()
));

CREATE POLICY "Users can insert their own emergency contacts" 
ON public.emergency_contacts 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM public.tourists 
  WHERE tourists.id = emergency_contacts.tourist_id 
  AND tourists.user_id = auth.uid()
));

CREATE POLICY "Users can update their own emergency contacts" 
ON public.emergency_contacts 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM public.tourists 
  WHERE tourists.id = emergency_contacts.tourist_id 
  AND tourists.user_id = auth.uid()
));

-- Create RLS policies for itinerary_items
CREATE POLICY "Users can view their own itinerary items" 
ON public.itinerary_items 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.trips 
  JOIN public.tourists ON trips.tourist_id = tourists.id
  WHERE trips.id = itinerary_items.trip_id 
  AND tourists.user_id = auth.uid()
));

CREATE POLICY "Users can insert their own itinerary items" 
ON public.itinerary_items 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM public.trips 
  JOIN public.tourists ON trips.tourist_id = tourists.id
  WHERE trips.id = itinerary_items.trip_id 
  AND tourists.user_id = auth.uid()
));

CREATE POLICY "Users can update their own itinerary items" 
ON public.itinerary_items 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM public.trips 
  JOIN public.tourists ON trips.tourist_id = tourists.id
  WHERE trips.id = itinerary_items.trip_id 
  AND tourists.user_id = auth.uid()
));

-- Add RLS policy for tourists to allow users to insert their own profile
CREATE POLICY "Users can insert their own tourist profile" 
ON public.tourists 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view their own tourist profile" 
ON public.tourists 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Users can update their own tourist profile" 
ON public.tourists 
FOR UPDATE 
USING (user_id = auth.uid());

-- Add RLS policy for trips
CREATE POLICY "Users can view their own trips" 
ON public.trips 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.tourists 
  WHERE tourists.id = trips.tourist_id 
  AND tourists.user_id = auth.uid()
));

CREATE POLICY "Users can insert their own trips" 
ON public.trips 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM public.tourists 
  WHERE tourists.id = trips.tourist_id 
  AND tourists.user_id = auth.uid()
));

CREATE POLICY "Users can update their own trips" 
ON public.trips 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM public.tourists 
  WHERE tourists.id = trips.tourist_id 
  AND tourists.user_id = auth.uid()
));

-- Create triggers for updated_at timestamps
CREATE TRIGGER update_emergency_contacts_updated_at
  BEFORE UPDATE ON public.emergency_contacts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for KYC documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('kyc-documents', 'kyc-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for KYC documents
CREATE POLICY "Users can upload their own KYC documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'kyc-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own KYC documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'kyc-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own KYC documents" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'kyc-documents' AND auth.uid()::text = (storage.foldername(name))[1]);