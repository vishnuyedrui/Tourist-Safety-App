-- First, let's check for duplicates and clean them up
-- Keep only the most recent tourist profile for each user_id
DELETE FROM tourists 
WHERE id NOT IN (
  SELECT DISTINCT ON (user_id) id
  FROM tourists
  WHERE user_id IS NOT NULL
  ORDER BY user_id, created_at DESC
);

-- Add unique constraint to prevent future duplicates
ALTER TABLE tourists 
ADD CONSTRAINT tourists_user_id_unique UNIQUE (user_id);