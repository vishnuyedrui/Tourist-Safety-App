-- Create a tourist profile for the current user (who is currently an authority)
-- This allows testing the panic alert functionality
INSERT INTO public.tourists (
  user_id,
  full_name,
  phone,
  nationality,
  kyc_status
) VALUES (
  '0dac3e60-86ae-46ea-a903-797573f89f51',
  'Revanth',
  '+1234567890',
  'India',
  'verified'
) ON CONFLICT (user_id) DO NOTHING;

-- Create a test trip for the user
INSERT INTO public.trips (
  tourist_id,
  destination,
  start_date,
  end_date,
  status,
  current_location_lat,
  current_location_lng
) VALUES (
  (SELECT id FROM public.tourists WHERE user_id = '0dac3e60-86ae-46ea-a903-797573f89f51'),
  'Dubai, UAE',
  CURRENT_DATE,
  CURRENT_DATE + INTERVAL '7 days',
  'active',
  25.2048,
  55.2708
) ON CONFLICT DO NOTHING;