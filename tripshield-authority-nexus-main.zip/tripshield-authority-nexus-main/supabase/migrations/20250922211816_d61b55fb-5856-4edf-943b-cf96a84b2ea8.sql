-- Create a table to store notification settings for authorities
CREATE TABLE public.notification_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  authority_id UUID NOT NULL,
  email_alerts BOOLEAN NOT NULL DEFAULT true,
  sms_alerts BOOLEAN NOT NULL DEFAULT false,
  push_notifications BOOLEAN NOT NULL DEFAULT true,
  weekly_reports BOOLEAN NOT NULL DEFAULT true,
  emergency_only BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for notification settings
CREATE POLICY "Authorities can view their own notification settings" 
ON public.notification_settings 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM authorities 
    WHERE authorities.user_id = auth.uid() 
    AND authorities.id = notification_settings.authority_id
  )
);

CREATE POLICY "Authorities can insert their own notification settings" 
ON public.notification_settings 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM authorities 
    WHERE authorities.user_id = auth.uid() 
    AND authorities.id = notification_settings.authority_id
  )
);

CREATE POLICY "Authorities can update their own notification settings" 
ON public.notification_settings 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM authorities 
    WHERE authorities.user_id = auth.uid() 
    AND authorities.id = notification_settings.authority_id
  )
);

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_notification_settings_updated_at
BEFORE UPDATE ON public.notification_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();