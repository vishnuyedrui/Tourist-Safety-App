-- Create authorities table for authority user accounts
CREATE TABLE public.authorities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  organization TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'operator' CHECK (role IN ('admin', 'operator', 'viewer')),
  jurisdiction TEXT,
  phone TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create alerts table for panic alerts and emergency incidents
CREATE TABLE public.alerts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tourist_id UUID NOT NULL REFERENCES public.tourists(id) ON DELETE CASCADE,
  alert_type TEXT NOT NULL CHECK (alert_type IN ('panic', 'medical', 'security', 'geofence_violation', 'emergency')),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'acknowledged', 'resolved', 'false_alarm')),
  title TEXT NOT NULL,
  description TEXT,
  location_lat DECIMAL(10, 8),
  location_lng DECIMAL(11, 8),
  location_address TEXT,
  handled_by UUID REFERENCES public.authorities(id),
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create geofences table for safe/risk zones
CREATE TABLE public.geofences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  risk_level TEXT NOT NULL CHECK (risk_level IN ('safe', 'caution', 'danger', 'restricted')),
  geometry JSONB NOT NULL, -- GeoJSON polygon
  color TEXT NOT NULL DEFAULT '#00FF00',
  active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL REFERENCES public.authorities(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create trips table for tracking tourist trips
CREATE TABLE public.trips (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tourist_id UUID NOT NULL REFERENCES public.tourists(id) ON DELETE CASCADE,
  destination TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'active', 'completed', 'cancelled')),
  current_location_lat DECIMAL(10, 8),
  current_location_lng DECIMAL(11, 8),
  last_check_in TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create alert_logs table for audit trail
CREATE TABLE public.alert_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  alert_id UUID NOT NULL REFERENCES public.alerts(id) ON DELETE CASCADE,
  authority_id UUID NOT NULL REFERENCES public.authorities(id),
  action TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create geofence_violations table
CREATE TABLE public.geofence_violations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tourist_id UUID NOT NULL REFERENCES public.tourists(id) ON DELETE CASCADE,
  geofence_id UUID NOT NULL REFERENCES public.geofences(id) ON DELETE CASCADE,
  violation_type TEXT NOT NULL CHECK (violation_type IN ('entry', 'exit')),
  location_lat DECIMAL(10, 8) NOT NULL,
  location_lng DECIMAL(11, 8) NOT NULL,
  alert_generated BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.authorities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.geofences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alert_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.geofence_violations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for authorities table
CREATE POLICY "Authorities can view their own profile" 
ON public.authorities 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Authorities can update their own profile" 
ON public.authorities 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Authorities can insert their own profile" 
ON public.authorities 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- RLS Policies for alerts table
CREATE POLICY "Authorities can view all alerts" 
ON public.alerts 
FOR SELECT 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

CREATE POLICY "Authorities can update alerts" 
ON public.alerts 
FOR UPDATE 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

CREATE POLICY "Authorities can insert alerts" 
ON public.alerts 
FOR INSERT 
TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

-- RLS Policies for geofences table
CREATE POLICY "Authorities can view all geofences" 
ON public.geofences 
FOR SELECT 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

CREATE POLICY "Authorities can manage geofences" 
ON public.geofences 
FOR ALL 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

-- RLS Policies for trips table
CREATE POLICY "Authorities can view all trips" 
ON public.trips 
FOR SELECT 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

CREATE POLICY "Authorities can update trips" 
ON public.trips 
FOR UPDATE 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

-- RLS Policies for alert_logs table
CREATE POLICY "Authorities can view alert logs" 
ON public.alert_logs 
FOR SELECT 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

CREATE POLICY "Authorities can insert alert logs" 
ON public.alert_logs 
FOR INSERT 
TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid() AND id = authority_id));

-- RLS Policies for geofence_violations table
CREATE POLICY "Authorities can view geofence violations" 
ON public.geofence_violations 
FOR SELECT 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

-- Enable RLS on tourists table
ALTER TABLE public.tourists ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authorities can view all tourists" 
ON public.tourists 
FOR SELECT 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

CREATE POLICY "Authorities can update tourist data" 
ON public.tourists 
FOR UPDATE 
TO authenticated
USING (EXISTS (SELECT 1 FROM public.authorities WHERE user_id = auth.uid()));

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_authorities_updated_at
  BEFORE UPDATE ON public.authorities
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_alerts_updated_at
  BEFORE UPDATE ON public.alerts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_geofences_updated_at
  BEFORE UPDATE ON public.geofences
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_trips_updated_at
  BEFORE UPDATE ON public.trips
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to auto-populate authority profile
CREATE OR REPLACE FUNCTION public.handle_new_authority()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.authorities (user_id, full_name, organization)
  VALUES (
    NEW.id, 
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'Authority User'),
    COALESCE(NEW.raw_user_meta_data ->> 'organization', 'TripShield Authority')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for authority profile creation
CREATE TRIGGER on_auth_authority_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_authority();