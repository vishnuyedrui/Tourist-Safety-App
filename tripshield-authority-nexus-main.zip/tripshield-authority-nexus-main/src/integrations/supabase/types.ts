export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      alert_logs: {
        Row: {
          action: string
          alert_id: string
          authority_id: string
          created_at: string
          id: string
          notes: string | null
        }
        Insert: {
          action: string
          alert_id: string
          authority_id: string
          created_at?: string
          id?: string
          notes?: string | null
        }
        Update: {
          action?: string
          alert_id?: string
          authority_id?: string
          created_at?: string
          id?: string
          notes?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "alert_logs_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "alerts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alert_logs_authority_id_fkey"
            columns: ["authority_id"]
            isOneToOne: false
            referencedRelation: "authorities"
            referencedColumns: ["id"]
          },
        ]
      }
      alerts: {
        Row: {
          alert_type: string
          created_at: string
          description: string | null
          handled_by: string | null
          id: string
          location_address: string | null
          location_lat: number | null
          location_lng: number | null
          priority: string
          resolved_at: string | null
          status: string
          title: string
          tourist_id: string
          updated_at: string
        }
        Insert: {
          alert_type: string
          created_at?: string
          description?: string | null
          handled_by?: string | null
          id?: string
          location_address?: string | null
          location_lat?: number | null
          location_lng?: number | null
          priority?: string
          resolved_at?: string | null
          status?: string
          title: string
          tourist_id: string
          updated_at?: string
        }
        Update: {
          alert_type?: string
          created_at?: string
          description?: string | null
          handled_by?: string | null
          id?: string
          location_address?: string | null
          location_lat?: number | null
          location_lng?: number | null
          priority?: string
          resolved_at?: string | null
          status?: string
          title?: string
          tourist_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "alerts_handled_by_fkey"
            columns: ["handled_by"]
            isOneToOne: false
            referencedRelation: "authorities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alerts_tourist_id_fkey"
            columns: ["tourist_id"]
            isOneToOne: false
            referencedRelation: "tourists"
            referencedColumns: ["id"]
          },
        ]
      }
      authorities: {
        Row: {
          created_at: string
          full_name: string
          id: string
          jurisdiction: string | null
          organization: string
          phone: string | null
          role: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          full_name: string
          id?: string
          jurisdiction?: string | null
          organization: string
          phone?: string | null
          role?: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          jurisdiction?: string | null
          organization?: string
          phone?: string | null
          role?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      geofence_violations: {
        Row: {
          alert_generated: boolean
          created_at: string
          geofence_id: string
          id: string
          location_lat: number
          location_lng: number
          tourist_id: string
          violation_type: string
        }
        Insert: {
          alert_generated?: boolean
          created_at?: string
          geofence_id: string
          id?: string
          location_lat: number
          location_lng: number
          tourist_id: string
          violation_type: string
        }
        Update: {
          alert_generated?: boolean
          created_at?: string
          geofence_id?: string
          id?: string
          location_lat?: number
          location_lng?: number
          tourist_id?: string
          violation_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "geofence_violations_geofence_id_fkey"
            columns: ["geofence_id"]
            isOneToOne: false
            referencedRelation: "geofences"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "geofence_violations_tourist_id_fkey"
            columns: ["tourist_id"]
            isOneToOne: false
            referencedRelation: "tourists"
            referencedColumns: ["id"]
          },
        ]
      }
      geofences: {
        Row: {
          active: boolean
          color: string
          created_at: string
          created_by: string
          description: string | null
          geometry: Json
          id: string
          name: string
          risk_level: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          color?: string
          created_at?: string
          created_by: string
          description?: string | null
          geometry: Json
          id?: string
          name: string
          risk_level: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          color?: string
          created_at?: string
          created_by?: string
          description?: string | null
          geometry?: Json
          id?: string
          name?: string
          risk_level?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "geofences_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "authorities"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_settings: {
        Row: {
          authority_id: string
          created_at: string
          email_alerts: boolean
          emergency_only: boolean
          id: string
          push_notifications: boolean
          sms_alerts: boolean
          updated_at: string
          weekly_reports: boolean
        }
        Insert: {
          authority_id: string
          created_at?: string
          email_alerts?: boolean
          emergency_only?: boolean
          id?: string
          push_notifications?: boolean
          sms_alerts?: boolean
          updated_at?: string
          weekly_reports?: boolean
        }
        Update: {
          authority_id?: string
          created_at?: string
          email_alerts?: boolean
          emergency_only?: boolean
          id?: string
          push_notifications?: boolean
          sms_alerts?: boolean
          updated_at?: string
          weekly_reports?: boolean
        }
        Relationships: []
      }
      tourists: {
        Row: {
          created_at: string
          document_url: string | null
          emergency_contact: string | null
          full_name: string
          id: string
          trip_itenary: string | null
          trip_itenary_url: string | null
        }
        Insert: {
          created_at?: string
          document_url?: string | null
          emergency_contact?: string | null
          full_name: string
          id?: string
          trip_itenary?: string | null
          trip_itenary_url?: string | null
        }
        Update: {
          created_at?: string
          document_url?: string | null
          emergency_contact?: string | null
          full_name?: string
          id?: string
          trip_itenary?: string | null
          trip_itenary_url?: string | null
        }
        Relationships: []
      }
      trips: {
        Row: {
          created_at: string
          current_location_lat: number | null
          current_location_lng: number | null
          destination: string
          end_date: string
          id: string
          last_check_in: string | null
          start_date: string
          status: string
          tourist_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_location_lat?: number | null
          current_location_lng?: number | null
          destination: string
          end_date: string
          id?: string
          last_check_in?: string | null
          start_date: string
          status?: string
          tourist_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_location_lat?: number | null
          current_location_lng?: number | null
          destination?: string
          end_date?: string
          id?: string
          last_check_in?: string | null
          start_date?: string
          status?: string
          tourist_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "trips_tourist_id_fkey"
            columns: ["tourist_id"]
            isOneToOne: false
            referencedRelation: "tourists"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
