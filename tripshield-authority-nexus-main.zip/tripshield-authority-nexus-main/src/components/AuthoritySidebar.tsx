import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  LayoutDashboard, 
  Users, 
  AlertTriangle, 
  MapPin, 
  FileText, 
  Settings, 
  LogOut 
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Tourist Management", href: "/tourists", icon: Users },
  { name: "Alerts & Incidents", href: "/alerts", icon: AlertTriangle },
  { name: "Geofencing", href: "/geofencing", icon: MapPin },
  { name: "Reports", href: "/reports", icon: FileText },
  { name: "Settings", href: "/settings", icon: Settings },
];

export const AuthoritySidebar: React.FC = () => {
  const { authority, signOut } = useAuth();
  const location = useLocation();

  const handleSignOut = () => {
    signOut();
  };

  return (
    <div className="flex h-full w-64 flex-col bg-sidebar border-r border-sidebar-border">
      {/* Header */}
      <div className="flex items-center px-6 py-4 border-b border-sidebar-border">
        <div className="flex items-center space-x-2">
          <Shield className="h-8 w-8 text-sidebar-primary" />
          <div>
            <h1 className="text-lg font-bold text-sidebar-foreground">TripShield</h1>
            <p className="text-xs text-sidebar-foreground/70">Authority Portal</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-4">
        {navigation.map((item) => {
          const isActive = location.pathname === item.href;
          return (
            <NavLink
              key={item.name}
              to={item.href}
              className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                isActive
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.name}
            </NavLink>
          );
        })}
      </nav>

      {/* User Profile & Sign Out */}
      <div className="border-t border-sidebar-border p-4">
        <div className="mb-3">
          <p className="text-sm font-medium text-sidebar-foreground">
            {authority?.full_name || "Authority User"}
          </p>
          <p className="text-xs text-sidebar-foreground/70">
            {authority?.organization || "TripShield Authority"}
          </p>
          <div className="mt-1">
            <span className={cn(
              "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
              authority?.role === 'admin' 
                ? "bg-sidebar-primary/20 text-sidebar-primary" 
                : "bg-sidebar-accent text-sidebar-accent-foreground"
            )}>
              {authority?.role || "operator"}
            </span>
          </div>
        </div>
        <Button
          onClick={handleSignOut}
          variant="outline"
          size="sm"
          className="w-full justify-start"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};