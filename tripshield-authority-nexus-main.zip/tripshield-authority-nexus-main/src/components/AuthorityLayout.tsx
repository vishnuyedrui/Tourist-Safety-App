import React from "react";
import { AuthoritySidebar } from "./AuthoritySidebar";

interface AuthorityLayoutProps {
  children: React.ReactNode;
}

export const AuthorityLayout: React.FC<AuthorityLayoutProps> = ({ children }) => {
  return (
    <div className="flex h-screen bg-background">
      <AuthoritySidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
};