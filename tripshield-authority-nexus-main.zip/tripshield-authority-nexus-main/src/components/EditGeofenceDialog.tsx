import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Edit } from "lucide-react";

interface Geofence {
  id: string;
  name: string;
  description: string | null;
  risk_level: string;
  color: string;
  active: boolean;
  geometry: any;
}

interface EditGeofenceDialogProps {
  geofence: Geofence;
  onGeofenceUpdated: () => void;
}

export const EditGeofenceDialog: React.FC<EditGeofenceDialogProps> = ({
  geofence,
  onGeofenceUpdated,
}) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: geofence.name,
    description: geofence.description || "",
    risk_level: geofence.risk_level,
    color: geofence.color,
  });
  const { toast } = useToast();

  useEffect(() => {
    const riskColors = {
      low: "#00FF00",
      medium: "#FFAA00", 
      high: "#FF0000",
      critical: "#800000"
    };
    setFormData(prev => ({
      ...prev,
      color: riskColors[formData.risk_level as keyof typeof riskColors] || prev.color
    }));
  }, [formData.risk_level]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from("geofences")
        .update({
          name: formData.name,
          description: formData.description,
          risk_level: formData.risk_level,
          color: formData.color,
          updated_at: new Date().toISOString(),
        })
        .eq("id", geofence.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Geofence updated successfully",
      });

      setOpen(false);
      onGeofenceUpdated();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update geofence",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Edit className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Geofence Zone</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Zone Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              placeholder="Enter zone name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder="Enter zone description"
              className="min-h-[80px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="risk_level">Risk Level</Label>
            <Select value={formData.risk_level} onValueChange={(value) => handleInputChange("risk_level", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select risk level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low Risk</SelectItem>
                <SelectItem value="medium">Medium Risk</SelectItem>
                <SelectItem value="high">High Risk</SelectItem>
                <SelectItem value="critical">Critical Risk</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="color">Zone Color</Label>
            <div className="flex gap-2 items-center">
              <Input
                id="color"
                type="color"
                value={formData.color}
                onChange={(e) => handleInputChange("color", e.target.value)}
                className="w-20 h-10 p-1 border rounded"
              />
              <div 
                className="w-10 h-10 rounded border"
                style={{ backgroundColor: formData.color }}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Updating..." : "Update Zone"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};