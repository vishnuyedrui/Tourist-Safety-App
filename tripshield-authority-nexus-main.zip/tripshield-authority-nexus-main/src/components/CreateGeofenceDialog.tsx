import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getRiskLevelColor } from "@/lib/mapUtils";

interface CreateGeofenceDialogProps {
  onGeofenceCreated: () => void;
}

const CreateGeofenceDialog: React.FC<CreateGeofenceDialogProps> = ({ onGeofenceCreated }) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    risk_level: "caution",
    color: getRiskLevelColor("caution"),
  });
  const { toast } = useToast();

  // Update color when risk level changes
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      color: getRiskLevelColor(prev.risk_level)
    }));
  }, [formData.risk_level]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Get authority record
      const { data: authority } = await supabase
        .from("authorities")
        .select("id")
        .eq("user_id", user.id)
        .single();

      if (!authority) throw new Error("Authority not found");

      // Create a default circular geofence centered on India
      const defaultGeometry = {
        type: "Circle",
        coordinates: [78.9629, 20.5937], // India center [lng, lat]
        radius: 50000 // 50km radius
      };

      const { error } = await supabase
        .from("geofences")
        .insert({
          name: formData.name,
          description: formData.description || null,
          risk_level: formData.risk_level,
          color: formData.color,
          geometry: defaultGeometry,
          created_by: authority.id,
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Geofence created successfully",
      });

      setFormData({
        name: "",
        description: "",
        risk_level: "caution",
        color: getRiskLevelColor("caution"),
      });
      setOpen(false);
      onGeofenceCreated();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create geofence",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Create Zone
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] z-[60] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Geofence</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Zone Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              placeholder="Enter zone name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder="Enter zone description (optional)"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="risk_level">Risk Level</Label>
            <Select value={formData.risk_level} onValueChange={(value) => handleInputChange("risk_level", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select risk level" />
              </SelectTrigger>
              <SelectContent className="z-[70] bg-background border shadow-lg">
                <SelectItem value="safe">Safe Zone</SelectItem>
                <SelectItem value="caution">Caution Zone</SelectItem>
                <SelectItem value="danger">Danger Zone</SelectItem>
                <SelectItem value="restricted">Restricted Zone</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="color">Zone Color</Label>
            <div className="flex items-center space-x-2">
              <Input
                id="color"
                type="color"
                value={formData.color}
                onChange={(e) => handleInputChange("color", e.target.value)}
                className="w-16 h-10"
              />
              <Input
                value={formData.color}
                onChange={(e) => handleInputChange("color", e.target.value)}
                placeholder="#3B82F6"
                className="flex-1"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Creating..." : "Create Zone"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateGeofenceDialog;