import React, { useEffect, useRef, useState } from 'react';
import * as L from 'leaflet';
import { supabase } from '@/integrations/supabase/client';
import { INDIA_CENTER, DEFAULT_ZOOM, getRiskLevelColor, parseGeofenceGeometry, isValidCoordinate } from '@/lib/mapUtils';

interface Geofence {
  id: string;
  name: string;
  description: string | null;
  risk_level: string;
  color: string;
  active: boolean;
  geometry: any;
}

interface GeofenceViolation {
  id: string;
  tourist_id: string;
  geofence_id: string;
  violation_type: string;
  location_lat: number;
  location_lng: number;
  alert_generated: boolean;
  created_at: string;
}

interface GeofencingMapProps {
  geofences: Geofence[];
  violations: GeofenceViolation[];
}

const createDivIcon = (options: { bg: string; size: number; inner?: string }) =>
  L.divIcon({
    html: `
      <div style="display:flex;align-items:center;justify-content:center;width:${options.size}px;height:${options.size}px;background:${options.bg};border-radius:50%;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.25)">
        ${options.inner || ''}
      </div>
    `,
    className: 'leaflet-custom-icon',
    iconSize: [options.size, options.size],
    iconAnchor: [options.size / 2, options.size],
    popupAnchor: [0, -options.size / 2],
  });

const HQ_ICON = createDivIcon({
  bg: '#3b82f6',
  size: 32,
  inner:
    '<svg style="width:14px;height:14px;color:#fff" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2L3 7v11h4v-6h6v6h4V7l-7-5z"/></svg>',
});
const VIOLATION_ICON = createDivIcon({
  bg: '#dc2626',
  size: 24,
  inner:
    '<svg style="width:10px;height:10px;color:#fff" viewBox="0 0 20 20" fill="currentColor"><circle cx="10" cy="10" r="8"/></svg>',
});
const touristIcon = (color: string) =>
  createDivIcon({
    bg: color,
    size: 20,
    inner:
      '<svg style="width:8px;height:8px;color:#fff" viewBox="0 0 20 20" fill="currentColor"><circle cx="10" cy="10" r="8"/></svg>',
  });

const GeofencingMap: React.FC<GeofencingMapProps> = ({ geofences, violations }) => {
  const mapEl = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const geofencesLayer = useRef<L.LayerGroup | null>(null);
  const violationsLayer = useRef<L.LayerGroup | null>(null);
  const touristsLayer = useRef<L.LayerGroup | null>(null);
  const resizeObserverRef = useRef<ResizeObserver | null>(null);
  const [tourists, setTourists] = useState<any[]>([]);

  // Initialize map once
  useEffect(() => {
    if (!mapEl.current || mapRef.current) return;

    const map = L.map(mapEl.current, {
      center: [INDIA_CENTER.lat, INDIA_CENTER.lng],
      zoom: DEFAULT_ZOOM,
      zoomControl: true,
      attributionControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      detectRetina: true,
    }).addTo(map);

    // Layer groups
    geofencesLayer.current = L.layerGroup().addTo(map);
    violationsLayer.current = L.layerGroup().addTo(map);
    touristsLayer.current = L.layerGroup().addTo(map);

    // HQ marker
    const hqMarker = L.marker([INDIA_CENTER.lat, INDIA_CENTER.lng], { icon: HQ_ICON });
    hqMarker
      .bindPopup(
        `<div style="font-size:14px">
          <h3 style="margin:0 0 4px 0;font-weight:600">Authority Headquarters</h3>
          <p style="margin:0 0 8px 0;color:#6b7280">Central monitoring station</p>
          <span style="padding:2px 8px;border-radius:4px;background:#dbeafe;color:#1e40af;font-size:12px;font-weight:500">COMMAND CENTER</span>
        </div>`
      )
      .addTo(map);

    mapRef.current = map;

    const invalidate = () => {
      map.invalidateSize();
    };

    map.whenReady(() => {
      invalidate();
      requestAnimationFrame(invalidate);
      setTimeout(invalidate, 0);
      setTimeout(invalidate, 300);
    });

    if (mapEl.current) {
      const ro = new ResizeObserver(() => {
        map.invalidateSize();
      });
      ro.observe(mapEl.current);
      resizeObserverRef.current = ro;
    }

    window.addEventListener('resize', invalidate);

    return () => {
      window.removeEventListener('resize', invalidate);
      if (resizeObserverRef.current) {
        resizeObserverRef.current.disconnect();
        resizeObserverRef.current = null;
      }
      map.remove();
      mapRef.current = null;
      geofencesLayer.current = null;
      violationsLayer.current = null;
      touristsLayer.current = null;
    };
  }, []);

  // Draw geofences when data changes
  useEffect(() => {
    if (!geofencesLayer.current || !mapRef.current) return;
    geofencesLayer.current.clearLayers();

    console.log('Drawing geofences:', geofences);

    const activeGeofences = geofences.filter((g) => g.active);
    console.log('Active geofences:', activeGeofences);

    activeGeofences.forEach((geofence) => {
      console.log('Processing geofence:', geofence.name, geofence.geometry);
      const parsed = parseGeofenceGeometry(geofence.geometry);
      console.log('Parsed geometry:', parsed);
      
      if (!parsed) return;

      const color = geofence.color || getRiskLevelColor(geofence.risk_level);
      const opacity = geofence.risk_level === 'danger' || geofence.risk_level === 'restricted' ? 0.7 : 
                     geofence.risk_level === 'caution' ? 0.5 : 0.3;

      if (Array.isArray(parsed)) {
        // Polygon expects [lat, lng] tuples
        const polygon = L.polygon(parsed as L.LatLngExpression[], {
          color,
          fillColor: color,
          fillOpacity: opacity,
          weight: 2,
        });
        polygon
          .bindPopup(
            `<div style="font-size:14px">
              <h3 style="margin:0 0 4px 0;font-weight:600">${geofence.name}</h3>
              ${geofence.description ? `<p style=\"margin:0 0 8px 0;color:#6b7280\">${geofence.description}</p>` : ''}
              <div style="display:flex;gap:8px">
                <span style="padding:2px 8px;border-radius:4px;font-size:12px;font-weight:500;background:${
                  geofence.risk_level === 'danger' || geofence.risk_level === 'restricted' ? '#fef2f2' : 
                  geofence.risk_level === 'caution' ? '#fffbeb' : '#f0fdf4'
                };color:${
                  geofence.risk_level === 'danger' || geofence.risk_level === 'restricted' ? '#991b1b' : 
                  geofence.risk_level === 'caution' ? '#92400e' : '#166534'
                }">${geofence.risk_level.toUpperCase()}</span>
                <span style="padding:2px 8px;border-radius:4px;font-size:12px;font-weight:500;background:#dbeafe;color:#1e40af">ACTIVE</span>
              </div>
            </div>`
          )
          .addTo(geofencesLayer.current as L.LayerGroup);
      } else if ((parsed as any).center && (parsed as any).radius) {
        const { center, radius } = parsed as { center: [number, number]; radius: number };
        console.log('Creating circle at:', center, 'with radius:', radius);
        
        const circle = L.circle(center as L.LatLngExpression, {
          radius,
          color,
          fillColor: color,
          fillOpacity: opacity,
          weight: 2,
        });
        circle
          .bindPopup(
            `<div style="font-size:14px">
              <h3 style="margin:0 0 4px 0;font-weight:600">${geofence.name}</h3>
              ${geofence.description ? `<p style=\"margin:0 0 8px 0;color:#6b7280\">${geofence.description}</p>` : ''}
              <span style="padding:2px 8px;border-radius:4px;font-size:12px;font-weight:500;background:${
                geofence.risk_level === 'danger' || geofence.risk_level === 'restricted' ? '#fef2f2' : 
                geofence.risk_level === 'caution' ? '#fffbeb' : '#f0fdf4'
              };color:${
                geofence.risk_level === 'danger' || geofence.risk_level === 'restricted' ? '#991b1b' : 
                geofence.risk_level === 'caution' ? '#92400e' : '#166534'
              }">${geofence.risk_level.toUpperCase()}</span>
            </div>`
          )
          .addTo(geofencesLayer.current as L.LayerGroup);
      }
    });

    // Fit map bounds to show all geofences if they exist
    if (activeGeofences.length > 0 && mapRef.current) {
      const group = new L.FeatureGroup();
      geofencesLayer.current.eachLayer((layer) => {
        group.addLayer(layer);
      });
      
      if (group.getBounds().isValid()) {
        mapRef.current.fitBounds(group.getBounds(), { padding: [20, 20] });
      }
    }

    // Ensure Leaflet recalculates size after drawing
    if (mapRef.current) {
      requestAnimationFrame(() => mapRef.current?.invalidateSize());
      setTimeout(() => mapRef.current?.invalidateSize(), 0);
    }
  }, [geofences]);

  // Draw violations
  useEffect(() => {
    if (!violationsLayer.current) return;
    violationsLayer.current.clearLayers();

    violations.forEach((v) => {
      if (!isValidCoordinate(v.location_lat, v.location_lng)) return;
      const m = L.marker([v.location_lat, v.location_lng], { icon: VIOLATION_ICON });
      m.bindPopup(
        `<div style="font-size:14px">
          <h3 style="margin:0 0 4px 0;font-weight:600">Geofence Violation</h3>
          <p style="margin:0 0 8px 0;color:#6b7280">${v.violation_type}</p>
          <div style="font-size:12px;line-height:1.4">
            <p style="margin:0 0 4px 0"><strong>Location:</strong> ${v.location_lat.toFixed(6)}, ${v.location_lng.toFixed(6)}</p>
            <p style="margin:0 0 8px 0"><strong>Time:</strong> ${new Date(v.created_at).toLocaleString()}</p>
            <span style="padding:2px 8px;border-radius:4px;font-size:12px;font-weight:500;background:${
              v.alert_generated ? '#fef2f2' : '#f3f4f6'
            };color:${v.alert_generated ? '#991b1b' : '#374151'}">${
          v.alert_generated ? 'Alert Sent' : 'No Alert'
        }</span>
          </div>
        </div>`
      ).addTo(violationsLayer.current as L.LayerGroup);
    });
    // Ensure size recalculation after markers update
    if (mapRef.current) {
      requestAnimationFrame(() => mapRef.current?.invalidateSize());
    }
  }, [violations]);

  // Fetch tourists and realtime updates
  useEffect(() => {
    const fetchTourists = async () => {
      try {
        const { data, error } = await supabase
          .from('trips')
          .select('*, tourists(*)')
          .eq('status', 'active')
          .not('current_location_lat', 'is', null)
          .not('current_location_lng', 'is', null);
        if (error) throw error;
        setTourists(data || []);
      } catch (e) {
        console.error('Error fetching tourists:', e);
      }
    };

    fetchTourists();

    const violationsChannel = supabase
      .channel('geofence-violations')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'geofence_violations' }, () => {
        // Parent already refreshes; safe to ignore or could refetch if needed
      })
      .subscribe();

    const tripsChannel = supabase
      .channel('trips-updates')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'trips' }, () => {
        fetchTourists();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(violationsChannel);
      supabase.removeChannel(tripsChannel);
    };
  }, []);

  // Draw tourists
  useEffect(() => {
    if (!touristsLayer.current) return;
    touristsLayer.current.clearLayers();

    tourists.forEach((t) => {
      if (!t.current_location_lat || !t.current_location_lng) return;
      if (!isValidCoordinate(t.current_location_lat, t.current_location_lng)) return;
      const icon = touristIcon('#16a34a');
      const m = L.marker([t.current_location_lat, t.current_location_lng], { icon });
      m.bindPopup(
        `<div style="font-size:14px">
          <h3 style="margin:0 0 4px 0;font-weight:600">Tourist Location</h3>
          ${t.tourists ? `<p style=\"margin:0 0 8px 0;color:#6b7280\">${t.tourists.full_name}</p>` : ''}
          <div style="font-size:12px;line-height:1.4">
            <p style="margin:0 0 4px 0"><strong>Destination:</strong> ${t.destination}</p>
            <p style="margin:0 0 4px 0"><strong>Status:</strong> ${t.status}</p>
            ${t.last_check_in ? `<p style=\"margin:0 0 8px 0\"><strong>Last Check-in:</strong> ${new Date(
              t.last_check_in
            ).toLocaleString()}</p>` : ''}
            <span style="padding:2px 8px;border-radius:4px;font-size:12px;font-weight:500;background:#f0fdf4;color:#166534">ACTIVE TRIP</span>
          </div>
        </div>`
      ).addTo(touristsLayer.current as L.LayerGroup);
    });
    // Ensure size recalculation after tourists update
    if (mapRef.current) {
      requestAnimationFrame(() => mapRef.current?.invalidateSize());
    }
  }, [tourists]);

  return <div ref={mapEl} className="w-full rounded-b-lg overflow-hidden border-0 h-[60vh] min-h-[380px] relative z-10" />;
};

export default GeofencingMap;
