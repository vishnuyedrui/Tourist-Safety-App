import React, { useState, useEffect } from "react";
import { AuthorityLayout } from "@/components/AuthorityLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Map, MapPin, AlertTriangle, Plus, Edit, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import GeofencingMap from "@/components/GeofencingMap";
import CreateGeofenceDialog from "@/components/CreateGeofenceDialog";
import { EditGeofenceDialog } from "@/components/EditGeofenceDialog";

interface Geofence {
  id: string;
  name: string;
  description: string | null;
  risk_level: string;
  color: string;
  active: boolean;
  geometry: any;
  created_at: string;
  updated_at: string;
}

interface GeofenceViolation {
  id: string;
  tourist_id: string;
  geofence_id: string;
  violation_type: string;
  location_lat: number;
  location_lng: number;
  alert_generated: boolean;
  created_at: string;
}

const Geofencing: React.FC = () => {
  const [geofences, setGeofences] = useState<Geofence[]>([]);
  const [violations, setViolations] = useState<GeofenceViolation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [riskFilter, setRiskFilter] = useState("all");
  const { toast } = useToast();

  useEffect(() => {
    fetchGeofences();
    fetchViolations();
    setupRealtimeSubscriptions();
  }, []);

  const setupRealtimeSubscriptions = () => {
    // Subscribe to geofence violations
    const violationsChannel = supabase
      .channel('violations-updates')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'geofence_violations'
        },
        (payload) => {
          console.log('New violation detected:', payload);
          fetchViolations();
          toast({
            title: "New Violation",
            description: "A geofence boundary has been violated",
            variant: "destructive",
          });
        }
      )
      .subscribe();

    // Subscribe to geofence updates
    const geofencesChannel = supabase
      .channel('geofences-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'geofences'
        },
        (payload) => {
          console.log('Geofence updated:', payload);
          fetchGeofences();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(violationsChannel);
      supabase.removeChannel(geofencesChannel);
    };
  };

  const fetchGeofences = async () => {
    try {
      const { data, error } = await supabase
        .from("geofences")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setGeofences(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch geofences",
        variant: "destructive",
      });
    }
  };

  const fetchViolations = async () => {
    try {
      const { data, error } = await supabase
        .from("geofence_violations")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      setViolations(data || []);
      setLoading(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch violations",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const toggleGeofence = async (geofenceId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("geofences")
        .update({ active: !currentStatus })
        .eq("id", geofenceId);

      if (error) throw error;
      
      toast({
        title: "Success",
        description: `Geofence ${!currentStatus ? "activated" : "deactivated"} successfully`,
      });
      
      fetchGeofences();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update geofence",
        variant: "destructive",
      });
    }
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low":
        return "bg-green-100 text-green-800 border-green-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const filteredGeofences = geofences.filter((geofence) => {
    const matchesSearch = geofence.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = riskFilter === "all" || geofence.risk_level === riskFilter;
    
    return matchesSearch && matchesRisk;
  });

  if (loading) {
    return (
      <AuthorityLayout>
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-center">
            <Map className="h-12 w-12 mx-auto mb-4 text-primary" />
            <p className="text-muted-foreground">Loading geofences...</p>
          </div>
        </div>
      </AuthorityLayout>
    );
  }

  return (
    <AuthorityLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Geofencing</h1>
            <p className="text-muted-foreground">Manage geographic boundaries and safety zones</p>
          </div>
          <CreateGeofenceDialog onGeofenceCreated={fetchGeofences} />
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Zones</CardTitle>
              <Map className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{geofences.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Zones</CardTitle>
              <MapPin className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {geofences.filter(g => g.active).length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
               <CardTitle className="text-sm font-medium">High Risk Zones</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {geofences.filter(g => g.risk_level === "danger" || g.risk_level === "restricted").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Recent Violations</CardTitle>
              <AlertTriangle className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {violations.filter(v => 
                  new Date(v.created_at).getTime() > Date.now() - 24 * 60 * 60 * 1000
                ).length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map */}
        <Card className="relative">
          <CardHeader>
            <CardTitle>Interactive Map</CardTitle>
            <CardDescription>View and manage geofenced areas</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative w-full">
              <GeofencingMap 
                geofences={geofences} 
                violations={violations} 
              />
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Search & Filter Zones</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <Input
                placeholder="Search geofences..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1"
              />
              <Select value={riskFilter} onValueChange={setRiskFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by risk level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Risk Levels</SelectItem>
                  <SelectItem value="danger">Danger Zone</SelectItem>
                  <SelectItem value="restricted">Restricted Zone</SelectItem>
                  <SelectItem value="caution">Caution Zone</SelectItem>
                  <SelectItem value="safe">Safe Zone</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Geofences List */}
        <Card>
          <CardHeader>
            <CardTitle>Geofenced Zones</CardTitle>
            <CardDescription>
              {filteredGeofences.length} of {geofences.length} zones
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredGeofences.map((geofence) => (
                <div key={geofence.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg">{geofence.name}</h3>
                        <div 
                          className="w-4 h-4 rounded-full border"
                          style={{ backgroundColor: geofence.color }}
                        />
                        <Badge className={getRiskLevelColor(geofence.risk_level)}>
                          {geofence.risk_level.toUpperCase()}
                        </Badge>
                        <Badge variant={geofence.active ? "default" : "secondary"}>
                          {geofence.active ? "ACTIVE" : "INACTIVE"}
                        </Badge>
                      </div>
                      {geofence.description && (
                        <p className="text-sm text-muted-foreground">{geofence.description}</p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <EditGeofenceDialog 
                        geofence={geofence} 
                        onGeofenceUpdated={fetchGeofences}
                      />
                      <Button 
                        variant={geofence.active ? "secondary" : "default"}
                        size="sm"
                        onClick={() => toggleGeofence(geofence.id, geofence.active)}
                      >
                        {geofence.active ? "Deactivate" : "Activate"}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    Created: {new Date(geofence.created_at).toLocaleDateString()} | 
                    Last updated: {new Date(geofence.updated_at).toLocaleDateString()}
                  </div>
                </div>
              ))}

              {filteredGeofences.length === 0 && (
                <div className="text-center py-8">
                  <Map className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No geofences found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Violations */}
        {violations.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Violations</CardTitle>
              <CardDescription>Latest geofence boundary violations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {violations.slice(0, 5).map((violation) => (
                  <div key={violation.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <p className="font-medium">{violation.violation_type}</p>
                      <p className="text-sm text-muted-foreground">
                        Location: {violation.location_lat.toFixed(6)}, {violation.location_lng.toFixed(6)}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant={violation.alert_generated ? "destructive" : "secondary"}>
                        {violation.alert_generated ? "Alert Sent" : "No Alert"}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(violation.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AuthorityLayout>
  );
};

export default Geofencing;