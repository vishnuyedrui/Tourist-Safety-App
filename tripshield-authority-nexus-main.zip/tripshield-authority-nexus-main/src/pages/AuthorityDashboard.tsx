import React, { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { AuthorityLayout } from "@/components/AuthorityLayout";
import { 
  Users, 
  AlertTriangle, 
  MapPin, 
  Activity,
  Search,
  Clock,
  Shield,
  TrendingUp
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AuthorityDashboard() {
  const { authority } = useAuth();
  const { toast } = useToast();
  const [stats, setStats] = useState({
    totalTourists: 0,
    activeTrips: 0,
    activeAlerts: 0,
    resolvedAlerts: 0,
  });
  const [recentAlerts, setRecentAlerts] = useState([]);
  const [tourists, setTourists] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch statistics
      const [touristsResponse, tripsResponse, alertsResponse] = await Promise.all([
        supabase.from("tourists").select("id", { count: "exact" }),
        supabase.from("trips").select("id", { count: "exact" }).eq("status", "active"),
        supabase.from("alerts").select("id, status", { count: "exact" }),
      ]);

      const activeAlerts = alertsResponse.data?.filter(alert => alert.status === "active").length || 0;
      const resolvedAlerts = alertsResponse.data?.filter(alert => alert.status === "resolved").length || 0;

      setStats({
        totalTourists: touristsResponse.count || 0,
        activeTrips: tripsResponse.count || 0,
        activeAlerts,
        resolvedAlerts,
      });

      // Fetch recent alerts
      const { data: alerts } = await supabase
        .from("alerts")
        .select(`
          *,
          tourists (full_name)
        `)
        .order("created_at", { ascending: false })
        .limit(5);

      setRecentAlerts(alerts || []);

      // Fetch tourists for search
      const { data: touristsData } = await supabase
        .from("tourists")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10);

      setTourists(touristsData || []);

    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      toast({
        title: "Error",
        description: "Failed to load dashboard data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getAlertPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical": return "bg-destructive text-destructive-foreground";
      case "high": return "bg-orange-500 text-white";
      case "medium": return "bg-warning text-warning-foreground";
      case "low": return "bg-accent text-accent-foreground";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  const filteredTourists = tourists.filter((tourist: any) =>
    tourist.full_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <AuthorityLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <Shield className="mx-auto h-12 w-12 text-primary animate-pulse" />
            <p className="mt-2 text-muted-foreground">Loading Dashboard...</p>
          </div>
        </div>
      </AuthorityLayout>
    );
  }

  return (
    <AuthorityLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Authority Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {authority?.full_name}. Monitor tourist safety operations.
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tourists</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalTourists}</div>
              <p className="text-xs text-muted-foreground">
                Registered in system
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Trips</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeTrips}</div>
              <p className="text-xs text-muted-foreground">
                Currently ongoing
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{stats.activeAlerts}</div>
              <p className="text-xs text-muted-foreground">
                Require attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolved Today</CardTitle>
              <TrendingUp className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">{stats.resolvedAlerts}</div>
              <p className="text-xs text-muted-foreground">
                Incidents handled
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5" />
                Recent Alerts
              </CardTitle>
              <CardDescription>Latest security incidents and alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentAlerts.length > 0 ? (
                  recentAlerts.map((alert: any) => (
                    <div key={alert.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <Badge className={getAlertPriorityColor(alert.priority)}>
                            {alert.priority}
                          </Badge>
                          <span className="font-medium">{alert.title}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Tourist: {alert.tourists?.full_name || "Unknown"}
                        </p>
                        <div className="flex items-center mt-1 text-xs text-muted-foreground">
                          <Clock className="mr-1 h-3 w-3" />
                          {new Date(alert.created_at).toLocaleString()}
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-4">
                    No recent alerts
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Tourist Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="mr-2 h-5 w-5" />
                Tourist Search
              </CardTitle>
              <CardDescription>Quick search and access to tourist records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tourists by name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="space-y-2">
                  {filteredTourists.slice(0, 5).map((tourist: any) => (
                    <div key={tourist.id} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <p className="font-medium">{tourist.full_name}</p>
                        <p className="text-sm text-muted-foreground">{tourist.emergency_contact}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        View Profile
                      </Button>
                    </div>
                  ))}
                  {filteredTourists.length === 0 && searchTerm && (
                    <p className="text-center text-muted-foreground py-4">
                      No tourists found
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AuthorityLayout>
  );
}