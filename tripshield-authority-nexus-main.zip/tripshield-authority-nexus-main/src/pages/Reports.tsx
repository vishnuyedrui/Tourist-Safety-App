import React, { useState, useEffect } from "react";
import { AuthorityLayout } from "@/components/AuthorityLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Download, FileText, TrendingUp, Users, AlertTriangle, Calendar } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ReportData {
  tourists: any[];
  alerts: any[];
  trips: any[];
  geofences: any[];
}

const Reports: React.FC = () => {
  const [data, setData] = useState<ReportData>({ tourists: [], alerts: [], trips: [], geofences: [] });
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState("30");
  const { toast } = useToast();

  useEffect(() => {
    fetchReportData();
  }, [timeRange]);

  const fetchReportData = async () => {
    try {
      setLoading(true);
      
      const dateFilter = new Date();
      dateFilter.setDate(dateFilter.getDate() - parseInt(timeRange));
      
      const [touristsRes, alertsRes, tripsRes, geofencesRes] = await Promise.all([
        supabase.from("tourists").select("*"),
        supabase.from("alerts").select("*").gte("created_at", dateFilter.toISOString()),
        supabase.from("trips").select("*"),
        supabase.from("geofences").select("*")
      ]);

      if (touristsRes.error) throw touristsRes.error;
      if (alertsRes.error) throw alertsRes.error;
      if (tripsRes.error) throw tripsRes.error;
      if (geofencesRes.error) throw geofencesRes.error;

      setData({
        tourists: touristsRes.data || [],
        alerts: alertsRes.data || [],
        trips: tripsRes.data || [],
        geofences: geofencesRes.data || []
      });
      
      setLoading(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch report data",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const exportReport = () => {
    try {
      // Prepare CSV content
      const csvContent = generateCSVReport();
      
      // Create blob and download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `tourist-safety-report-${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Export Complete",
        description: "Your report has been downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to generate report",
        variant: "destructive",
      });
    }
  };

  const generateCSVReport = () => {
    const headers = [
      'Report Type', 'Date', 'Tourist Count', 'Active Trips', 
      'Total Alerts', 'High Priority Alerts', 'Resolved Alerts', 
      'Active Geofences', 'Completed Trips'
    ];
    
    const reportDate = new Date().toISOString().split('T')[0];
    const highPriorityAlerts = data.alerts.filter(a => a.priority === 'high' || a.priority === 'critical').length;
    const resolvedAlerts = data.alerts.filter(a => a.status === 'resolved').length;
    const activeGeofences = data.geofences.filter(g => g.active).length;
    const completedTrips = data.trips.filter(t => t.status === 'completed').length;
    const activeTrips = data.trips.filter(t => t.status === 'active').length;
    
    const rows = [
      [
        'Summary Report',
        reportDate,
        data.tourists.length,
        activeTrips,
        data.alerts.length,
        highPriorityAlerts,
        resolvedAlerts,
        activeGeofences,
        completedTrips
      ]
    ];
    
    // Add detailed alerts section
    if (data.alerts.length > 0) {
      rows.push(['', '', '', '', '', '', '', '', '']); // Empty row
      rows.push(['DETAILED ALERTS', '', '', '', '', '', '', '', '']);
      rows.push(['Alert ID', 'Title', 'Type', 'Priority', 'Status', 'Created Date', 'Location', '', '']);
      
      data.alerts.forEach(alert => {
        rows.push([
          alert.id,
          alert.title || 'N/A',
          alert.alert_type,
          alert.priority,
          alert.status,
          new Date(alert.created_at).toLocaleDateString(),
          alert.location_address || 'N/A',
          '',
          ''
        ]);
      });
    }
    
    // Convert to CSV format
    return [headers, ...rows]
      .map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
      .join('\n');
  };

  // Prepare chart data
  const alertsByDay = data.alerts.reduce((acc: any, alert) => {
    const date = new Date(alert.created_at).toLocaleDateString();
    acc[date] = (acc[date] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(alertsByDay).map(([date, count]) => ({
    date,
    alerts: count
  })).slice(-7); // Last 7 days

  const alertsByPriority = data.alerts.reduce((acc: any, alert) => {
    acc[alert.priority] = (acc[alert.priority] || 0) + 1;
    return acc;
  }, {});

  const priorityData = Object.entries(alertsByPriority).map(([priority, count]) => ({
    name: priority,
    value: count
  }));

  const tripsByStatus = data.trips.reduce((acc: any, trip) => {
    acc[trip.status] = (acc[trip.status] || 0) + 1;
    return acc;
  }, {});

  const statusData = Object.entries(tripsByStatus).map(([status, count]) => ({
    name: status,
    value: count
  }));

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  if (loading) {
    return (
      <AuthorityLayout>
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-center">
            <FileText className="h-12 w-12 mx-auto mb-4 text-primary" />
            <p className="text-muted-foreground">Loading reports...</p>
          </div>
        </div>
      </AuthorityLayout>
    );
  }

  return (
    <AuthorityLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Reports & Analytics</h1>
            <p className="text-muted-foreground">Comprehensive insights into tourist safety operations</p>
          </div>
          <div className="flex gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={exportReport}>
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tourists</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{data.tourists.length}</div>
              <p className="text-xs text-muted-foreground">
                +12% from last period
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Trips</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {data.trips.filter(t => t.status === "active").length}
              </div>
              <p className="text-xs text-muted-foreground">
                +5% from last period
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Safety Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{data.alerts.length}</div>
              <p className="text-xs text-muted-foreground">
                -8% from last period
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Response Time</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12m</div>
              <p className="text-xs text-muted-foreground">
                -3m from last period
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Alert Trends */}
          <Card>
            <CardHeader>
              <CardTitle>Alert Trends</CardTitle>
              <CardDescription>Daily alert volume over the last 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="alerts" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Alert Priority Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Alert Priority Distribution</CardTitle>
              <CardDescription>Breakdown of alerts by priority level</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={priorityData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {priorityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Trip Status Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Trip Status Overview</CardTitle>
              <CardDescription>Current status of all registered trips</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Safety Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Safety Metrics</CardTitle>
              <CardDescription>Key performance indicators for tourist safety</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Average Response Time</span>
                <span className="text-2xl font-bold">12 minutes</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Resolution Rate</span>
                <span className="text-2xl font-bold">94%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Incident Prevention</span>
                <span className="text-2xl font-bold">87%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Tourist Satisfaction</span>
                <span className="text-2xl font-bold">4.8/5</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Activity Summary</CardTitle>
            <CardDescription>Recent operational highlights and statistics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {data.alerts.filter(a => a.status === "resolved").length}
                </div>
                <p className="text-sm text-muted-foreground">Alerts Resolved</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {data.geofences.filter(g => g.active).length}
                </div>
                <p className="text-sm text-muted-foreground">Active Geofences</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">
                  {data.trips.filter(t => t.status === "completed").length}
                </div>
                <p className="text-sm text-muted-foreground">Completed Trips</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AuthorityLayout>
  );
};

export default Reports;