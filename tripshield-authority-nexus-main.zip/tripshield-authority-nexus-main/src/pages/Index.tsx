import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Shield, ArrowRight } from "lucide-react";

const Index = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !loading) {
      navigate("/dashboard");
    }
  }, [user, loading, navigate]);

  const handleGetStarted = () => {
    navigate("/auth");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center space-y-6 max-w-2xl px-4">
        {/* Logo */}
        <div className="flex justify-center">
          <div className="flex items-center space-x-3 text-primary">
            <Shield className="h-16 w-16" />
            <div className="text-left">
              <h1 className="text-4xl font-bold">TripShield</h1>
              <p className="text-lg text-muted-foreground">Authority Portal</p>
            </div>
          </div>
        </div>

        {/* Hero Text */}
        <div className="space-y-4">
          <h2 className="text-3xl font-bold text-foreground">
            Comprehensive Tourist Safety Management
          </h2>
          <p className="text-xl text-muted-foreground">
            Advanced monitoring, alert systems, and emergency response coordination 
            for government agencies and tourism authorities.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold text-foreground mb-2">Real-time Monitoring</h3>
            <p className="text-sm text-muted-foreground">
              Track tourist locations and safety status in real-time
            </p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold text-foreground mb-2">Alert Management</h3>
            <p className="text-sm text-muted-foreground">
              Instant emergency response and incident coordination
            </p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold text-foreground mb-2">Geofencing</h3>
            <p className="text-sm text-muted-foreground">
              Define and monitor safe zones and restricted areas
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="pt-6">
          <Button onClick={handleGetStarted} size="lg" className="px-8">
            Access Authority Portal
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>

        {/* Footer */}
        <div className="pt-8 text-sm text-muted-foreground">
          <p>Secure • Government Grade • ISO 27001 Compliant</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
