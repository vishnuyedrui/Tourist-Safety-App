import React, { useState, useEffect } from "react";
import { AuthorityLayout } from "@/components/AuthorityLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Users, Eye, FileText, Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Tourist {
  id: string;
  full_name: string;
  emergency_contact: string | null;
  trip_itenary: string | null;
  created_at: string;
}

interface Trip {
  id: string;
  destination: string;
  status: string;
  start_date: string;
  end_date: string;
}

const TouristManagement: React.FC = () => {
  const [tourists, setTourists] = useState<Tourist[]>([]);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchTourists();
    fetchTrips();
  }, []);

  const fetchTourists = async () => {
    try {
      const { data, error } = await supabase
        .from("tourists")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setTourists(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch tourists",
        variant: "destructive",
      });
    }
  };

  const fetchTrips = async () => {
    try {
      const { data, error } = await supabase
        .from("trips")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setTrips(data || []);
      setLoading(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch trips",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const filteredTourists = tourists.filter((tourist) =>
    tourist.full_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 border-green-200";
      case "planned":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "completed":
        return "bg-gray-100 text-gray-800 border-gray-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  if (loading) {
    return (
      <AuthorityLayout>
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-center">
            <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
            <p className="text-muted-foreground">Loading tourists...</p>
          </div>
        </div>
      </AuthorityLayout>
    );
  }

  return (
    <AuthorityLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Tourist Management</h1>
          <p className="text-muted-foreground">Monitor and manage tourist registrations and trips</p>
        </div>

        {/* Search Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Tourists
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Search by tourist name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </CardContent>
        </Card>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tourists</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{tourists.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Trips</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {trips.filter(trip => trip.status === "active").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Planned Trips</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {trips.filter(trip => trip.status === "planned").length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tourists List */}
        <Card>
          <CardHeader>
            <CardTitle>Registered Tourists</CardTitle>
            <CardDescription>
              {filteredTourists.length} of {tourists.length} tourists
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredTourists.map((tourist) => {
                const touristTrips = trips.filter(trip => (trip as any).tourist_id === tourist.id);
                return (
                  <div key={tourist.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{tourist.full_name}</h3>
                        <p className="text-sm text-muted-foreground">
                          Registered: {new Date(tourist.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                    </div>
                    
                    {tourist.emergency_contact && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>Emergency: {tourist.emergency_contact}</span>
                      </div>
                    )}

                    {touristTrips.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Active Trips:</p>
                        <div className="flex flex-wrap gap-2">
                          {touristTrips.map((trip) => (
                            <Badge key={trip.id} className={getStatusColor(trip.status)}>
                              {trip.destination} - {trip.status}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}

              {filteredTourists.length === 0 && (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No tourists found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AuthorityLayout>
  );
};

export default TouristManagement;