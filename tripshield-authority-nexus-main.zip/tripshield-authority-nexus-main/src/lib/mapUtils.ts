import { LatLngBounds } from 'leaflet';

// Indian coordinates for centering the map
export const INDIA_CENTER = {
  lat: 20.5937,
  lng: 78.9629
};

export const DEFAULT_ZOOM = 5;

// Risk level color mapping
export const getRiskLevelColor = (riskLevel: string): string => {
  switch (riskLevel) {
    case "danger":
      return "#dc2626"; // red-600
    case "restricted":
      return "#7c2d12"; // red-900
    case "caution":
      return "#ea580c"; // orange-600
    case "safe":
      return "#16a34a"; // green-600
    default:
      return "#6b7280"; // gray-500
  }
};

// Parse GeoJSON geometry for geofences
export const parseGeofenceGeometry = (geometry: any) => {
  if (!geometry || !geometry.coordinates) {
    return null;
  }

  try {
    // Handle different GeoJSON types
    switch (geometry.type) {
      case 'Polygon':
        return geometry.coordinates[0].map((coord: number[]) => [coord[1], coord[0]]);
      case 'Circle':
        // Handle both old and new circle formats
        if (geometry.center) {
          // Old format: {center: [lat, lng], radius: number}
          let lat = geometry.center[0];
          let lng = geometry.center[1];
          if (lat === 0 && lng === 0) {
            // Fallback for invalid default center
            lat = INDIA_CENTER.lat;
            lng = INDIA_CENTER.lng;
          }
          return {
            center: [lat, lng],
            radius: geometry.radius || 1000
          };
        } else if (geometry.coordinates) {
          // New format: {coordinates: [lng, lat], radius: number}
          const lng = geometry.coordinates[0];
          const lat = geometry.coordinates[1];
          return {
            center: [lat, lng], // Convert to [lat, lng]
            radius: geometry.radius || 1000
          };
        }
        return null;
      default:
        return null;
    }
  } catch (error) {
    console.error('Error parsing geofence geometry:', error);
    return null;
  }
};

// Calculate bounds for multiple geofences
export const calculateBounds = (geofences: any[]): LatLngBounds | null => {
  if (geofences.length === 0) return null;

  const bounds = new LatLngBounds([0, 0], [0, 0]);
  
  geofences.forEach(geofence => {
    const geometry = parseGeofenceGeometry(geofence.geometry);
    if (geometry && Array.isArray(geometry)) {
      geometry.forEach((coord: number[]) => {
        bounds.extend([coord[0], coord[1]]);
      });
    }
  });

  return bounds.isValid() ? bounds : null;
};

// Validate coordinates
export const isValidCoordinate = (lat: number, lng: number): boolean => {
  return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
};